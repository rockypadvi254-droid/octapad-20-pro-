package com.example

import android.content.Context
import android.content.pm.ActivityInfo
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w840dp-h390dp-land")
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun `app name and forced landscape orientation are configured`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("Octapad 20 Pro", context.getString(R.string.app_name))
        assertEquals(
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE,
            composeRule.activity.requestedOrientation
        )
    }

    @Test
    fun `main screen renders header, 8 pads, bank switching, and non-zero-padded patch numbers`() {
        composeRule.waitForIdle()
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodes(androidx.compose.ui.test.hasText("Salpuri"))
                .fetchSemanticsNodes().isNotEmpty()
        }

        composeRule.onNodeWithText("OCTAPAD 20 PRO").assertIsDisplayed()
        composeRule.onNodeWithText("PROFESSIONAL MOBILE OCTAPAD").assertIsDisplayed()

        // Verify all 8 pads are displayed simultaneously
        for (pad in 1..8) {
            composeRule.onNodeWithTag("pad_$pad").assertIsDisplayed()
            composeRule.onNodeWithText("PAD $pad").assertIsDisplayed()
        }

        // Verify MIDI never fakes connected on emulator/JVM without hardware
        composeRule.onNodeWithText("MIDI OFF").assertIsDisplayed()

        // Verify initial patch A-1 (never 001)
        composeRule.onNodeWithTag("current_patch_number").assertIsDisplayed()
        composeRule.onNodeWithText("A-1").assertIsDisplayed()
        composeRule.onAllNodes(androidx.compose.ui.test.hasText("Salpuri")).get(0).assertIsDisplayed()

        // Switch to Patch 2 -> Timli Special
        composeRule.onNodeWithTag("patch_chip_2").performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodes(androidx.compose.ui.test.hasText("A-2"))
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("A-2").assertIsDisplayed()
        composeRule.onAllNodes(androidx.compose.ui.test.hasText("Timli Special")).get(0).assertIsDisplayed()

        // Switch to Bank B -> B-1 Studio Acoustic
        composeRule.onNodeWithTag("bank_b_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodes(androidx.compose.ui.test.hasText("B-1"))
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("B-1").assertIsDisplayed()
        composeRule.onAllNodes(androidx.compose.ui.test.hasText("Studio Acoustic")).get(0).assertIsDisplayed()

        // Switch back to Bank A -> preserves Patch 2
        composeRule.onNodeWithTag("bank_a_button").performClick()
        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodes(androidx.compose.ui.test.hasText("A-2"))
                .fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithText("A-2").assertIsDisplayed()
    }

    @Test
    fun `patch editor and settings screens open and return cleanly`() {
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("edit_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("editor_save_button").assertIsDisplayed()
        composeRule.onNodeWithTag("editor_cancel_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("settings_button").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("settings_tab_legacy_import").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("legacy_select_folder_button").assertIsDisplayed()
        composeRule.onNodeWithTag("settings_back_button").performClick()
        composeRule.waitForIdle()

        composeRule.onNodeWithTag("pad_1").assertIsDisplayed()
    }
}
