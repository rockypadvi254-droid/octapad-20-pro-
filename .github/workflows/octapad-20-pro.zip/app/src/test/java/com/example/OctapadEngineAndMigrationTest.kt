package com.example

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.audio.AudioEffectProcessor
import com.example.audio.FactorySampleGenerator
import com.example.data.AudioFxState
import com.example.data.Bank
import com.example.data.PatchRepository
import com.example.data.db.PatchDatabase
import com.example.data.formatPatchKey
import com.example.io.BackupManager
import com.example.legacy.LegacyDataMigration
import com.example.legacy.LegacyPatchImporter
import com.example.legacy.LegacySampleManager
import com.example.legacy.LegacySampleRegistry
import com.example.midi.MidiManager
import com.example.samples.SampleRegistry
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OctapadEngineAndMigrationTest {

    private lateinit var context: Context
    private lateinit var db: PatchDatabase
    private lateinit var sampleRegistry: SampleRegistry
    private lateinit var repository: PatchRepository
    private lateinit var legacyMigration: LegacyDataMigration
    private lateinit var backupManager: BackupManager

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(context, PatchDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        val dao = db.patchDao()
        sampleRegistry = SampleRegistry(context, dao)
        repository = PatchRepository(dao, sampleRegistry)
        val legacyReg = LegacySampleRegistry(sampleRegistry)
        val legacySampleMgr = LegacySampleManager(context, sampleRegistry, legacyReg)
        val legacyPatchImp = LegacyPatchImporter()
        legacyMigration = LegacyDataMigration(dao, legacySampleMgr, legacyPatchImp, legacyReg)
        backupManager = BackupManager(context, dao, sampleRegistry, legacyMigration)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `factory samples synthesize valid wavs and 200 independent patches seed correctly`(): Unit = runBlocking {
        repository.initializeDatabaseIfNeeded()

        val bankA = repository.observePatchesForBank(Bank.A).first()
        val bankB = repository.observePatchesForBank(Bank.B).first()
        assertEquals(100, bankA.size)
        assertEquals(100, bankB.size)
        assertEquals("Salpuri", bankA.first().name)
        assertEquals("Timli Special", bankA[1].name)

        val samples = sampleRegistry.getAllSamples()
        assertEquals(16, samples.size)
        assertTrue(samples.all { it.decodingVerified && it.durationMs > 50L && File(it.storedPath).exists() })

        // Editing Bank A Patch 1 does not alter Bank A Patch 2 or Bank B Patch 1
        val key1 = formatPatchKey(Bank.A, 1)
        val pads1 = repository.getPadAssignments(key1)
        val editedPads1 = pads1.map { if (it.padIndex == 1) it.copy(volume = 0.42f, pitch = 1.25f) else it }
        repository.savePatch(Bank.A, 1, "My Custom Salpuri", true, editedPads1)

        assertEquals("My Custom Salpuri", repository.getPatch(key1)?.name)
        assertEquals("Timli Special", repository.getPatch(formatPatchKey(Bank.A, 2))?.name)
        assertEquals("Studio Acoustic", repository.getPatch(formatPatchKey(Bank.B, 1))?.name)

        // Copy & Clear verification
        repository.copyPatch(Bank.A, 1, Bank.B, 50)
        assertEquals("My Custom Salpuri", repository.getPatch(formatPatchKey(Bank.B, 50))?.name)
        repository.clearPatch(Bank.B, 50)
        val clearedPads = repository.getPadAssignments(formatPatchKey(Bank.B, 50))
        assertTrue(clearedPads.all { it.sampleId == null })
        assertEquals("My Custom Salpuri", repository.getPatch(key1)?.name)
    }

    @Test
    fun `audio effect processor applies reverb and 3-band eq into valid stereo wav`() {
        val factorySamples = FactorySampleGenerator.ensureFactorySamplesExist(context)
        val src = File(factorySamples.first().storedPath)
        val out = File(context.cacheDir, "test_fx_out.wav")
        if (out.exists()) out.delete()

        val fx = AudioFxState(
            reverbEnabled = true,
            reverbMix = 0.5f,
            eqEnabled = true,
            bassGainDb = 6f,
            midGainDb = -3f,
            trebleGainDb = 4f
        )
        val ok = AudioEffectProcessor.processSampleWithFx(src, out, fx)
        assertTrue(ok)
        assertTrue(out.exists())
        val info = AudioEffectProcessor.verifyAndInspectAudio(out, "WAV")
        assertTrue(info.valid)
        assertEquals(2, info.channels)
        assertTrue(info.durationMs > factorySamples.first().durationMs)
    }

    @Test
    fun `legacy migration imports json xml sqlite patches, relinks samples, and flags missing without faking`(): Unit = runBlocking {
        repository.initializeDatabaseIfNeeded()
        val legacyDir = File(context.cacheDir, "mock_legacy_octapad_${System.currentTimeMillis()}").apply { mkdirs() }
        val factorySamples = FactorySampleGenerator.ensureFactorySamplesExist(context)
        val srcWav = File(factorySamples.first().storedPath)

        // Create two distinct legacy wavs
        val legWav1 = File(legacyDir, "old_dhol_hit.wav")
        srcWav.copyTo(legWav1, overwrite = true)
        val legWav2 = File(legacyDir, "old_timli_rim.wav")
        File(factorySamples[2].storedPath).copyTo(legWav2, overwrite = true)

        // JSON patch referencing one valid sample and one MISSING sample
        File(legacyDir, "patches_old.json").writeText(
            """
            {
              "patches": [
                {
                  "bank": "A",
                  "patchNumber": 12,
                  "name": "Old Garba Kit",
                  "pads": [
                    {"padIndex": 1, "sample": "old_dhol_hit.wav", "volume": 90, "pitch": 1.1},
                    {"padIndex": 2, "sample": "missing_rare_bell.wav", "volume": 75}
                  ]
                }
              ]
            }
            """.trimIndent()
        )

        // XML patch
        File(legacyDir, "legacy_kit.xml").writeText(
            """
            <octapad>
              <patch bank="B" number="15" name="Old XML Timli">
                <pad index="1" sample="old_timli_rim.wav" volume="0.8" />
              </patch>
            </octapad>
            """.trimIndent()
        )

        // SQLite legacy DB
        val sqliteFile = File(legacyDir, "old_octapad.db")
        SQLiteDatabase.openOrCreateDatabase(sqliteFile, null).use { sql ->
            sql.execSQL("CREATE TABLE patches (id INTEGER PRIMARY KEY, bank TEXT, patch_number INTEGER, name TEXT, pad1 TEXT)")
            sql.execSQL("INSERT INTO patches (id, bank, patch_number, name, pad1) VALUES (1, 'B', 20, 'SQLite Dhol', 'old_dhol_hit.wav')")
        }

        // Unsupported file
        File(legacyDir, "readme_unknown.xyz").writeText("unknown")

        val report = legacyMigration.migrateFromDirectory(legacyDir, preserveOriginalSlots = true)

        assertEquals(3, report.totalPatchesDetected)
        assertEquals(3, report.importedPatchesCount)
        assertEquals(0, report.failedPatchesCount)
        assertEquals(2, report.totalSamplesDetected)
        assertTrue(report.missingSamples.contains("missing_rare_bell.wav"))
        assertTrue(report.unsupportedFiles.any { it.contains("readme_unknown.xyz") })

        // Verify relinked PAD 1 and preserved missing PAD 2 (NOT replaced with random sound!)
        val a12Pads = repository.getPadAssignments(formatPatchKey(Bank.A, 12))
        val pad1 = a12Pads.first { it.padIndex == 1 }
        val pad2 = a12Pads.first { it.padIndex == 2 }
        assertNotNull(pad1.sampleId)
        assertNull(pad2.sampleId)
        assertEquals("missing_rare_bell.wav", pad2.missingSampleName)

        // Relink PAD 2 manually
        repository.relinkMissingPadSample(Bank.A, 12, 2, pad1.sampleId!!)
        val relinkedPad2 = repository.getPadAssignments(formatPatchKey(Bank.A, 12)).first { it.padIndex == 2 }
        assertEquals(pad1.sampleId, relinkedPad2.sampleId)
        assertNull(relinkedPad2.missingSampleName)

        legacyDir.deleteRecursively()
        Unit
    }

    @Test
    fun `versioned backup export and restore preserves patches and rejects proprietary binary dumps`(): Unit = runBlocking {
        repository.initializeDatabaseIfNeeded()
        repository.savePatch(
            Bank.A,
            77,
            "Festival Backup Test",
            true,
            repository.getPadAssignments(formatPatchKey(Bank.A, 77))
        )

        val backupFile = File(context.cacheDir, "test_backup.o20pro.zip")
        val exportReport = backupManager.exportBackup(Uri.fromFile(backupFile))
        assertTrue(exportReport.success)
        assertEquals(200, exportReport.patchCount)

        // Clear patch 77 then restore
        repository.clearPatch(Bank.A, 77)
        assertEquals("Empty Patch 77", repository.getPatch(formatPatchKey(Bank.A, 77))?.name)

        val importReport = backupManager.importBackupOrInspectExternal(Uri.fromFile(backupFile), overwriteExistingPatches = true)
        assertTrue(importReport.success)
        assertEquals("Festival Backup Test", repository.getPatch(formatPatchKey(Bank.A, 77))?.name)

        // Proprietary binary dump must be honestly rejected
        val spdFake = File(context.cacheDir, "roland_dump.spd").apply {
            writeBytes(byteArrayOf(0x00, 0x1A, 0x7F, 0x52, 0x4F, 0x4C, 0x00, 0x01))
        }
        val rejectReport = backupManager.importBackupOrInspectExternal(Uri.fromFile(spdFake), false)
        assertFalse(rejectReport.success)
        assertTrue(rejectReport.message.contains("Unsupported", ignoreCase = true))
    }

    @Test
    fun `midi manager parses note-on byte streams and triggers mapped pads`() {
        val triggered = mutableListOf<Pair<Int, Float>>()
        val midi = MidiManager(context) { padIdx, vel ->
            triggered.add(padIdx to vel)
        }
        assertFalse(midi.midiStatus.value.isConnected)

        // Note On ch 0, note 36 (PAD 1), vel 127 + note 38 (PAD 2), vel 64
        val packet = byteArrayOf(
            0x90.toByte(), 36, 127,
            0x90.toByte(), 38, 64
        )
        midi.processRawMidiBytes(packet, 0, packet.size)
        assertEquals(2, triggered.size)
        assertEquals(1, triggered[0].first)
        assertEquals(2, triggered[1].first)
        assertTrue(triggered[0].second > 0.99f)
        assertTrue(triggered[1].second in 0.45f..0.55f)
    }
}
