package com.example.data

enum class Bank(val code: String, val label: String) {
    A("A", "BANK A"),
    B("B", "BANK B");

    companion object {
        fun fromCode(code: String): Bank = if (code.equals("B", ignoreCase = true)) B else A
    }
}

enum class SampleLoadingStatus {
    UNLOADED,
    LOADING,
    READY,
    MISSING,
    ERROR
}

data class AudioFxState(
    val reverbEnabled: Boolean = false,
    val reverbMix: Float = 0.30f,
    val delayEnabled: Boolean = false,
    val delayTimeMs: Int = 220,
    val delayFeedback: Float = 0.35f,
    val eqEnabled: Boolean = false,
    val bassGainDb: Float = 0f,
    val midGainDb: Float = 0f,
    val trebleGainDb: Float = 0f
)

data class PadUiModel(
    val padIndex: Int, // 1..8
    val sampleId: String?,
    val sampleName: String,
    val missingSampleName: String? = null,
    val sampleStatus: SampleLoadingStatus = SampleLoadingStatus.UNLOADED,
    val sampleError: String? = null,
    val volume: Float = 0.85f,
    val pitch: Float = 1.0f,
    val pan: Float = 0.0f,
    val enabled: Boolean = true
)

data class PatchSummary(
    val patchKey: String,
    val bank: Bank,
    val patchNumber: Int, // 1..100
    val name: String,
    val isFavorite: Boolean
)

data class MidiStatus(
    val isHardwareSupported: Boolean = false,
    val connectedDeviceCount: Int = 0,
    val connectedDeviceNames: List<String> = emptyList(),
    val lastReceivedNote: Int? = null,
    val lastTriggeredPad: Int? = null,
    val lastActivityMs: Long = 0L
) {
    val isConnected: Boolean get() = connectedDeviceCount > 0
}

data class MidiPadMapping(
    val padIndex: Int,
    val midiNote: Int,
    val channel: Int = -1 // -1 = Omni
)

data class LegacyMigrationReport(
    val sourceDescription: String,
    val detectedFormat: String,
    val totalPatchesDetected: Int,
    val importedPatchesCount: Int,
    val failedPatchesCount: Int,
    val totalSamplesDetected: Int,
    val importedSamplesCount: Int,
    val skippedDuplicateSamplesCount: Int,
    val missingSamples: List<String>,
    val unsupportedFiles: List<String>,
    val restoredPadAssignmentsCount: Int,
    val warnings: List<String>
)

data class BackupOperationReport(
    val success: Boolean,
    val message: String,
    val patchCount: Int = 0,
    val sampleCount: Int = 0,
    val missingSamples: List<String> = emptyList(),
    val formatDetected: String = ""
)

fun formatPatchKey(bank: Bank, patchNumber: Int): String = "${bank.code}_$patchNumber"
