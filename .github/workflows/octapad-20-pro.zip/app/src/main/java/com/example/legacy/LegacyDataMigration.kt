package com.example.legacy

import android.net.Uri
import com.example.data.Bank
import com.example.data.LegacyMigrationReport
import com.example.data.db.PadAssignmentEntity
import com.example.data.db.PatchDao
import com.example.data.db.PatchEntity
import com.example.data.formatPatchKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class LegacyDataMigration(
    private val dao: PatchDao,
    private val sampleManager: LegacySampleManager,
    private val patchImporter: LegacyPatchImporter,
    private val legacySampleRegistry: LegacySampleRegistry
) {
    suspend fun migrateFromFolderUri(
        folderUri: Uri,
        preserveOriginalSlots: Boolean = true
    ): LegacyMigrationReport = withContext(Dispatchers.IO) {
        val scan = sampleManager.scanAndImportFolderUri(folderUri)
        executeMigrationPipeline(
            sourceDescription = "Folder (${folderUri.lastPathSegment ?: "SAF"})",
            scanResult = scan,
            preserveOriginalSlots = preserveOriginalSlots
        )
    }

    suspend fun migrateFromZipUri(
        zipUri: Uri,
        preserveOriginalSlots: Boolean = true
    ): LegacyMigrationReport = withContext(Dispatchers.IO) {
        val scan = sampleManager.scanAndImportZipUri(zipUri)
        executeMigrationPipeline(
            sourceDescription = "ZIP/Backup (${zipUri.lastPathSegment ?: "Archive"})",
            scanResult = scan,
            preserveOriginalSlots = preserveOriginalSlots
        )
    }

    suspend fun migrateFromDirectory(
        dir: File,
        preserveOriginalSlots: Boolean = true
    ): LegacyMigrationReport = withContext(Dispatchers.IO) {
        val scan = sampleManager.scanAndImportDirectory(dir)
        executeMigrationPipeline(
            sourceDescription = "Directory (${dir.name})",
            scanResult = scan,
            preserveOriginalSlots = preserveOriginalSlots,
            cleanupConfigs = false
        )
    }

    private suspend fun executeMigrationPipeline(
        sourceDescription: String,
        scanResult: LegacySampleScanResult,
        preserveOriginalSlots: Boolean,
        cleanupConfigs: Boolean = true
    ): LegacyMigrationReport {
        val inspection = patchImporter.inspectAndParseCandidates(scanResult.configCandidates)
        if (cleanupConfigs) {
            scanResult.configCandidates.forEach { runCatching { it.cachedFile.delete() } }
        }

        val missingSamples = LinkedHashSet<String>()
        var importedPatchesCount = 0
        var failedPatchesCount = inspection.failedFiles.size
        var restoredPadsCount = 0

        // Track next free slot when user chooses non-overwriting slot allocation
        var nextSafeSlotA = findFirstDefaultOrEmptySlot(Bank.A)
        var nextSafeSlotB = findFirstDefaultOrEmptySlot(Bank.B)

        for (spec in inspection.parsedPatches) {
            try {
                val targetBank = spec.bank
                val targetNum = if (preserveOriginalSlots) {
                    spec.patchNumber.coerceIn(1, 100)
                } else {
                    if (targetBank == Bank.A) {
                        val s = nextSafeSlotA.coerceIn(1, 100)
                        nextSafeSlotA = (s + 1).coerceAtMost(100)
                        s
                    } else {
                        val s = nextSafeSlotB.coerceIn(1, 100)
                        nextSafeSlotB = (s + 1).coerceAtMost(100)
                        s
                    }
                }
                val patchKey = formatPatchKey(targetBank, targetNum)
                val patchEntity = PatchEntity(
                    patchKey = patchKey,
                    bank = targetBank.code,
                    patchNumber = targetNum,
                    name = spec.patchName.take(40),
                    isFavorite = spec.isFavorite,
                    updatedAt = System.currentTimeMillis()
                )

                val padEntities = spec.pads.map { padSpec ->
                    val rawRef = padSpec.sampleRef
                    if (rawRef.isNullOrBlank()) {
                        PadAssignmentEntity(
                            patchKey = patchKey,
                            padIndex = padSpec.padIndex,
                            sampleId = null,
                            missingSampleName = null,
                            volume = padSpec.volume,
                            pitch = padSpec.pitch,
                            pan = padSpec.pan,
                            enabled = padSpec.enabled
                        )
                    } else {
                        val resolved = legacySampleRegistry.resolveReference(rawRef)
                        if (resolved != null) {
                            restoredPadsCount++
                            PadAssignmentEntity(
                                patchKey = patchKey,
                                padIndex = padSpec.padIndex,
                                sampleId = resolved.sampleId,
                                missingSampleName = null,
                                volume = padSpec.volume,
                                pitch = padSpec.pitch,
                                pan = padSpec.pan,
                                enabled = padSpec.enabled
                            )
                        } else {
                            // CRITICAL: Never silently replace missing samples with random sounds!
                            missingSamples.add(rawRef)
                            PadAssignmentEntity(
                                patchKey = patchKey,
                                padIndex = padSpec.padIndex,
                                sampleId = null,
                                missingSampleName = rawRef,
                                volume = padSpec.volume,
                                pitch = padSpec.pitch,
                                pan = padSpec.pan,
                                enabled = padSpec.enabled
                            )
                        }
                    }
                }

                dao.savePatchWithPads(patchEntity, padEntities)
                importedPatchesCount++
            } catch (_: Throwable) {
                failedPatchesCount++
            }
        }

        val formatSummary = if (inspection.detectedFormats.isEmpty()) {
            scanResult.detectedFormatHint
        } else {
            "${scanResult.detectedFormatHint} | Patches: ${inspection.detectedFormats.joinToString()}"
        }

        return LegacyMigrationReport(
            sourceDescription = sourceDescription,
            detectedFormat = formatSummary,
            totalPatchesDetected = inspection.parsedPatches.size + inspection.failedFiles.size,
            importedPatchesCount = importedPatchesCount,
            failedPatchesCount = failedPatchesCount,
            totalSamplesDetected = scanResult.totalSamplesDetected,
            importedSamplesCount = scanResult.importedSamples.size,
            skippedDuplicateSamplesCount = scanResult.skippedDuplicateCount,
            missingSamples = missingSamples.toList(),
            unsupportedFiles = scanResult.unsupportedFiles + scanResult.failedSamples + inspection.failedFiles,
            restoredPadAssignmentsCount = restoredPadsCount,
            warnings = inspection.warnings
        )
    }

    private suspend fun findFirstDefaultOrEmptySlot(bank: Bank): Int {
        val patches = dao.getAllPatchesSync().filter { it.bank == bank.code }
        val candidate = patches.firstOrNull {
            it.name.startsWith("Empty Patch", true) ||
                it.name.startsWith("Patch ", true) ||
                it.name.startsWith("Bank B ", true)
        }
        return candidate?.patchNumber ?: 80
    }
}
