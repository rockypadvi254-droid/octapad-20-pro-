package com.example.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import com.example.data.AudioFxState
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class DecodedAudioInfo(
    val valid: Boolean,
    val durationMs: Long,
    val sampleRate: Int = 44100,
    val channels: Int = 1,
    val errorMessage: String? = null
)

data class PcmBuffer(
    val samples: ShortArray,
    val sampleRate: Int,
    val channels: Int
)

object AudioEffectProcessor {

    private const val MAX_FX_DECODE_DURATION_MS = 12_000L

    fun verifyAndInspectAudio(file: File, formatHint: String): DecodedAudioInfo {
        if (!file.exists() || file.length() < 44) {
            return DecodedAudioInfo(false, 0L, errorMessage = "Audio file is missing or empty")
        }
        if (formatHint.equals("WAV", ignoreCase = true) || isWavHeader(file)) {
            val wavInfo = inspectWavHeader(file)
            if (wavInfo != null) return wavInfo
        }
        // Fallback / MP3 / OGG inspection via MediaExtractor
        val extractor = MediaExtractor()
        return try {
            extractor.setDataSource(file.absolutePath)
            var audioTrackIndex = -1
            var trackFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val fmt = extractor.getTrackFormat(i)
                val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    trackFormat = fmt
                    break
                }
            }
            if (audioTrackIndex < 0 || trackFormat == null) {
                DecodedAudioInfo(false, 0L, errorMessage = "No valid audio stream found in file")
            } else {
                val durationUs = if (trackFormat.containsKey(MediaFormat.KEY_DURATION)) {
                    trackFormat.getLong(MediaFormat.KEY_DURATION)
                } else 0L
                val sampleRate = if (trackFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                    trackFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                } else 44100
                val channels = if (trackFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                    trackFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                } else 1
                // Verify at least one packet can be read
                extractor.selectTrack(audioTrackIndex)
                val sampleSize = extractor.sampleSize
                if (sampleSize <= 0 && durationUs <= 0L) {
                    DecodedAudioInfo(false, 0L, errorMessage = "Audio stream appears corrupted or unreadable")
                } else {
                    DecodedAudioInfo(
                        valid = true,
                        durationMs = max(1L, durationUs / 1000L),
                        sampleRate = sampleRate,
                        channels = channels
                    )
                }
            }
        } catch (t: Throwable) {
            DecodedAudioInfo(false, 0L, errorMessage = t.message ?: "Failed to decode audio file")
        } finally {
            runCatching { extractor.release() }
        }
    }

    fun isWavHeader(file: File): Boolean {
        if (!file.exists() || file.length() < 12) return false
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                val header = ByteArray(12)
                raf.readFully(header)
                val riff = String(header, 0, 4, Charsets.US_ASCII)
                val wave = String(header, 8, 4, Charsets.US_ASCII)
                riff == "RIFF" && wave == "WAVE"
            }
        }.getOrDefault(false)
    }

    fun inspectWavHeader(file: File): DecodedAudioInfo? {
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 44) return null
                val riff = ByteArray(12)
                raf.readFully(riff)
                if (String(riff, 0, 4, Charsets.US_ASCII) != "RIFF" ||
                    String(riff, 8, 4, Charsets.US_ASCII) != "WAVE"
                ) {
                    return null
                }
                var channels = 1
                var sampleRate = 44100
                var bitsPerSample = 16
                var audioFormat = 1
                var dataSize = 0L
                while (raf.filePointer + 8 <= raf.length()) {
                    val chunkHeader = ByteArray(8)
                    raf.readFully(chunkHeader)
                    val chunkId = String(chunkHeader, 0, 4, Charsets.US_ASCII)
                    val chunkSize = ByteBuffer.wrap(chunkHeader, 4, 4)
                        .order(ByteOrder.LITTLE_ENDIAN)
                        .int.toLong() and 0xFFFFFFFFL
                    if (chunkId == "fmt ") {
                        val fmtBytes = ByteArray(min(chunkSize, 40L).toInt())
                        raf.readFully(fmtBytes)
                        val bb = ByteBuffer.wrap(fmtBytes).order(ByteOrder.LITTLE_ENDIAN)
                        audioFormat = bb.short.toInt() and 0xFFFF
                        channels = bb.short.toInt() and 0xFFFF
                        sampleRate = bb.int
                        bb.int // byteRate
                        bb.short // blockAlign
                        bitsPerSample = bb.short.toInt() and 0xFFFF
                        if (chunkSize > fmtBytes.size) {
                            raf.seek(raf.filePointer + (chunkSize - fmtBytes.size))
                        }
                    } else if (chunkId == "data") {
                        dataSize = chunkSize
                        break
                    } else {
                        val skip = if (chunkSize % 2L == 1L) chunkSize + 1L else chunkSize
                        raf.seek(min(raf.length(), raf.filePointer + skip))
                    }
                }
                if (channels <= 0 || sampleRate <= 0 || bitsPerSample <= 0 || dataSize <= 0L) {
                    return DecodedAudioInfo(false, 0L, errorMessage = "Invalid WAV format chunk")
                }
                val bytesPerSec = sampleRate.toLong() * channels * (bitsPerSample / 8)
                val durationMs = if (bytesPerSec > 0) (dataSize * 1000L) / bytesPerSec else 0L
                val isPcmSupported = (audioFormat == 1 && (bitsPerSample == 8 || bitsPerSample == 16 || bitsPerSample == 24)) ||
                    (audioFormat == 3 && bitsPerSample == 32)
                DecodedAudioInfo(
                    valid = true,
                    durationMs = max(1L, durationMs),
                    sampleRate = sampleRate,
                    channels = channels,
                    errorMessage = if (isPcmSupported) null else null
                )
            }
        }.getOrNull()
    }

    /**
     * Generates a DSP-processed WAV file for EQ (Bass/Mid/Treble) and/or Schroeder Reverb
     * so SoundPool can trigger processed audio with zero hit-time CPU cost.
     */
    fun processSampleWithFx(
        sourceFile: File,
        destFile: File,
        fx: AudioFxState
    ): Boolean {
        val pcm = decodeToMonoOrStereoPcm(sourceFile) ?: return false
        val ch = pcm.channels.coerceIn(1, 2)
        val sr = pcm.sampleRate.coerceIn(8000, 96000)

        // Convert to float buffer per channel
        val frameCount = pcm.samples.size / ch
        if (frameCount <= 0) return false

        val extraReverbTailFrames = if (fx.reverbEnabled && fx.reverbMix > 0.01f) {
            (sr * 0.45f).toInt()
        } else 0
        val totalFrames = frameCount + extraReverbTailFrames

        val left = FloatArray(totalFrames)
        val right = FloatArray(totalFrames)
        for (i in 0 until frameCount) {
            val l = pcm.samples[i * ch] / 32768f
            val r = if (ch == 2) pcm.samples[i * ch + 1] / 32768f else l
            left[i] = l
            right[i] = r
        }

        // Apply 3-band Biquad EQ if enabled
        if (fx.eqEnabled) {
            if (kotlin.math.abs(fx.bassGainDb) > 0.25f) {
                val bassFilter = BiquadFilter.lowShelf(sr.toDouble(), 120.0, fx.bassGainDb.toDouble())
                bassFilter.processInPlace(left)
                if (ch == 2) {
                    val bassR = BiquadFilter.lowShelf(sr.toDouble(), 120.0, fx.bassGainDb.toDouble())
                    bassR.processInPlace(right)
                } else {
                    System.arraycopy(left, 0, right, 0, totalFrames)
                }
            }
            if (kotlin.math.abs(fx.midGainDb) > 0.25f) {
                val midFilter = BiquadFilter.peakingEq(sr.toDouble(), 1000.0, 1.0, fx.midGainDb.toDouble())
                midFilter.processInPlace(left)
                if (ch == 2) {
                    val midR = BiquadFilter.peakingEq(sr.toDouble(), 1000.0, 1.0, fx.midGainDb.toDouble())
                    midR.processInPlace(right)
                } else {
                    System.arraycopy(left, 0, right, 0, totalFrames)
                }
            }
            if (kotlin.math.abs(fx.trebleGainDb) > 0.25f) {
                val trebFilter = BiquadFilter.highShelf(sr.toDouble(), 5500.0, fx.trebleGainDb.toDouble())
                trebFilter.processInPlace(left)
                if (ch == 2) {
                    val trebR = BiquadFilter.highShelf(sr.toDouble(), 5500.0, fx.trebleGainDb.toDouble())
                    trebR.processInPlace(right)
                } else {
                    System.arraycopy(left, 0, right, 0, totalFrames)
                }
            }
        }

        // Apply Schroeder Reverb if enabled
        if (fx.reverbEnabled && fx.reverbMix > 0.01f) {
            applySchroederReverb(left, right, sr, fx.reverbMix.coerceIn(0f, 1f))
        }

        // Soft clip & write 16-bit stereo/mono WAV
        val outChannels = 2
        val outShorts = ShortArray(totalFrames * outChannels)
        for (i in 0 until totalFrames) {
            outShorts[i * 2] = softClipToShort(left[i])
            outShorts[i * 2 + 1] = softClipToShort(right[i])
        }
        destFile.parentFile?.mkdirs()
        writeWav16Bit(destFile, outShorts, sr, outChannels)
        return true
    }

    private fun softClipToShort(v: Float): Short {
        val clipped = when {
            v > 1.0f -> 1.0f - (1.0f / (1.0f + (v - 1.0f) * 2.5f)) * 0.1f
            v < -1.0f -> -1.0f + (1.0f / (1.0f + (-v - 1.0f) * 2.5f)) * 0.1f
            else -> v
        }.coerceIn(-1.0f, 1.0f)
        return (clipped * 32767f).toInt().toShort()
    }

    private fun applySchroederReverb(left: FloatArray, right: FloatArray, sr: Int, mix: Float) {
        val scale = sr / 44100.0
        val combDelaysL = intArrayOf(
            (1116 * scale).toInt().coerceAtLeast(16),
            (1188 * scale).toInt().coerceAtLeast(16),
            (1277 * scale).toInt().coerceAtLeast(16),
            (1356 * scale).toInt().coerceAtLeast(16)
        )
        val combDelaysR = intArrayOf(
            (1139 * scale).toInt().coerceAtLeast(16),
            (1211 * scale).toInt().coerceAtLeast(16),
            (1300 * scale).toInt().coerceAtLeast(16),
            (1379 * scale).toInt().coerceAtLeast(16)
        )
        val feedback = 0.72f + (mix * 0.14f)
        val wetL = runCombBank(left, combDelaysL, feedback)
        val wetR = runCombBank(right, combDelaysR, feedback)

        val allpassDelays = intArrayOf(
            (556 * scale).toInt().coerceAtLeast(8),
            (441 * scale).toInt().coerceAtLeast(8)
        )
        runAllpassInPlace(wetL, allpassDelays[0], 0.5f)
        runAllpassInPlace(wetL, allpassDelays[1], 0.5f)
        runAllpassInPlace(wetR, allpassDelays[0] + 13, 0.5f)
        runAllpassInPlace(wetR, allpassDelays[1] + 13, 0.5f)

        val dryGain = 1.0f - (mix * 0.35f)
        val wetGain = mix * 0.65f
        for (i in left.indices) {
            left[i] = left[i] * dryGain + wetL[i] * wetGain
            right[i] = right[i] * dryGain + wetR[i] * wetGain
        }
    }

    private fun runCombBank(input: FloatArray, delays: IntArray, feedback: Float): FloatArray {
        val out = FloatArray(input.size)
        val invCount = 1.0f / delays.size
        for (delay in delays) {
            val buf = FloatArray(delay)
            var idx = 0
            var damp = 0f
            for (i in input.indices) {
                val delayed = buf[idx]
                damp = delayed * 0.7f + damp * 0.3f
                buf[idx] = input[i] + damp * feedback
                out[i] += delayed * invCount
                idx = (idx + 1) % delay
            }
        }
        return out
    }

    private fun runAllpassInPlace(buffer: FloatArray, delay: Int, gain: Float) {
        val ring = FloatArray(delay)
        var idx = 0
        for (i in buffer.indices) {
            val inp = buffer[i]
            val bufOut = ring[idx]
            val y = -inp + bufOut
            ring[idx] = inp + bufOut * gain
            buffer[i] = y
            idx = (idx + 1) % delay
        }
    }

    private fun decodeToMonoOrStereoPcm(file: File): PcmBuffer? {
        if (isWavHeader(file)) {
            val wav = readWavPcm(file)
            if (wav != null) return wav
        }
        return decodeCompressedWithMediaCodec(file)
    }

    private fun readWavPcm(file: File): PcmBuffer? {
        return runCatching {
            RandomAccessFile(file, "r").use { raf ->
                raf.seek(12)
                var channels = 1
                var sampleRate = 44100
                var bitsPerSample = 16
                var audioFormat = 1
                var dataOffset = -1L
                var dataSize = 0L
                while (raf.filePointer + 8 <= raf.length()) {
                    val hdr = ByteArray(8)
                    raf.readFully(hdr)
                    val id = String(hdr, 0, 4, Charsets.US_ASCII)
                    val size = ByteBuffer.wrap(hdr, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                    if (id == "fmt ") {
                        val fmt = ByteArray(min(size, 40L).toInt())
                        raf.readFully(fmt)
                        val bb = ByteBuffer.wrap(fmt).order(ByteOrder.LITTLE_ENDIAN)
                        audioFormat = bb.short.toInt() and 0xFFFF
                        channels = bb.short.toInt() and 0xFFFF
                        sampleRate = bb.int
                        bb.int
                        bb.short
                        bitsPerSample = bb.short.toInt() and 0xFFFF
                        if (size > fmt.size) raf.seek(raf.filePointer + (size - fmt.size))
                    } else if (id == "data") {
                        dataOffset = raf.filePointer
                        dataSize = min(size, raf.length() - dataOffset)
                        break
                    } else {
                        val skip = if (size % 2L == 1L) size + 1L else size
                        raf.seek(min(raf.length(), raf.filePointer + skip))
                    }
                }
                if (dataOffset < 0 || dataSize <= 0 || audioFormat != 1 || bitsPerSample != 16) {
                    return null
                }
                val maxBytes = min(dataSize, (sampleRate * channels * 2L * MAX_FX_DECODE_DURATION_MS) / 1000L).toInt()
                val raw = ByteArray(maxBytes)
                raf.seek(dataOffset)
                raf.readFully(raw)
                val shorts = ShortArray(raw.size / 2)
                ByteBuffer.wrap(raw).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(shorts)
                PcmBuffer(shorts, sampleRate, channels.coerceIn(1, 2))
            }
        }.getOrNull()
    }

    private fun decodeCompressedWithMediaCodec(file: File): PcmBuffer? {
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        return try {
            extractor.setDataSource(file.absolutePath)
            var trackIndex = -1
            var format: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val f = extractor.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    trackIndex = i
                    format = f
                    break
                }
            }
            if (trackIndex < 0 || format == null) return null
            val mime = format.getString(MediaFormat.KEY_MIME) ?: return null
            extractor.selectTrack(trackIndex)
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(format, null, null, 0)
            codec.start()

            var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 1
            val maxShorts = (sampleRate * channels * (MAX_FX_DECODE_DURATION_MS / 1000.0)).toInt()
            val outChunks = ArrayList<ShortArray>()
            var totalShorts = 0
            var inputDone = false
            var outputDone = false
            val info = MediaCodec.BufferInfo()

            while (!outputDone && totalShorts < maxShorts) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(5000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx) ?: continue
                        val read = extractor.readSampleData(inBuf, 0)
                        if (read < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, read, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = codec.dequeueOutputBuffer(info, 5000)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)
                    if (outBuf != null && info.size > 0) {
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val shortCount = info.size / 2
                        val arr = ShortArray(shortCount)
                        outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(arr)
                        outChunks.add(arr)
                        totalShorts += shortCount
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        outputDone = true
                    }
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val outFmt = codec.outputFormat
                    if (outFmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = outFmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (outFmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = outFmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }

            val merged = ShortArray(min(totalShorts, maxShorts))
            var pos = 0
            for (c in outChunks) {
                val toCopy = min(c.size, merged.size - pos)
                if (toCopy <= 0) break
                System.arraycopy(c, 0, merged, pos, toCopy)
                pos += toCopy
            }
            if (merged.isEmpty()) null else PcmBuffer(merged, sampleRate, channels.coerceIn(1, 2))
        } catch (_: Throwable) {
            null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    fun writeWav16Bit(file: File, samples: ShortArray, sampleRate: Int, channels: Int) {
        val dataSize = samples.size * 2
        val byteRate = sampleRate * channels * 2
        val blockAlign = channels * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(36 + dataSize)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16) // PCM chunk size
        header.putShort(1) // PCM format
        header.putShort(channels.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(blockAlign.toShort())
        header.putShort(16) // Bits per sample
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(dataSize)

        val pcmBytes = ByteArray(dataSize)
        ByteBuffer.wrap(pcmBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().put(samples)

        FileOutputStream(file).use { fos ->
            fos.write(header.array())
            fos.write(pcmBytes)
        }
    }

    private class BiquadFilter(
        private val b0: Double,
        private val b1: Double,
        private val b2: Double,
        private val a1: Double,
        private val a2: Double
    ) {
        private var z1 = 0.0
        private var z2 = 0.0

        fun processInPlace(samples: FloatArray) {
            for (i in samples.indices) {
                val x = samples[i].toDouble()
                val y = b0 * x + z1
                z1 = b1 * x - a1 * y + z2
                z2 = b2 * x - a2 * y
                samples[i] = y.toFloat()
            }
        }

        companion object {
            fun lowShelf(sr: Double, freq: Double, gainDb: Double): BiquadFilter {
                val a = 10.0.pow(gainDb / 40.0)
                val w0 = 2.0 * PI * freq / sr
                val cosW0 = cos(w0)
                val sinW0 = sin(w0)
                val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.707 - 1.0) + 2.0)
                val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
                val b0 = a * ((a + 1) - (a - 1) * cosW0 + twoSqrtAAlpha)
                val b1 = 2 * a * ((a - 1) - (a + 1) * cosW0)
                val b2 = a * ((a + 1) - (a - 1) * cosW0 - twoSqrtAAlpha)
                val a0 = (a + 1) + (a - 1) * cosW0 + twoSqrtAAlpha
                val a1 = -2 * ((a - 1) + (a + 1) * cosW0)
                val a2 = (a + 1) + (a - 1) * cosW0 - twoSqrtAAlpha
                return BiquadFilter(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }

            fun highShelf(sr: Double, freq: Double, gainDb: Double): BiquadFilter {
                val a = 10.0.pow(gainDb / 40.0)
                val w0 = 2.0 * PI * freq / sr
                val cosW0 = cos(w0)
                val sinW0 = sin(w0)
                val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.707 - 1.0) + 2.0)
                val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
                val b0 = a * ((a + 1) + (a - 1) * cosW0 + twoSqrtAAlpha)
                val b1 = -2 * a * ((a - 1) + (a + 1) * cosW0)
                val b2 = a * ((a + 1) + (a - 1) * cosW0 - twoSqrtAAlpha)
                val a0 = (a + 1) - (a - 1) * cosW0 + twoSqrtAAlpha
                val a1 = 2 * ((a - 1) - (a + 1) * cosW0)
                val a2 = (a + 1) - (a - 1) * cosW0 - twoSqrtAAlpha
                return BiquadFilter(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }

            fun peakingEq(sr: Double, freq: Double, q: Double, gainDb: Double): BiquadFilter {
                val a = 10.0.pow(gainDb / 40.0)
                val w0 = 2.0 * PI * freq / sr
                val cosW0 = cos(w0)
                val alpha = sin(w0) / (2.0 * q)
                val b0 = 1.0 + alpha * a
                val b1 = -2.0 * cosW0
                val b2 = 1.0 - alpha * a
                val a0 = 1.0 + alpha / a
                val a1 = -2.0 * cosW0
                val a2 = 1.0 - alpha / a
                return BiquadFilter(b0 / a0, b1 / a0, b2 / a0, a1 / a0, a2 / a0)
            }
        }
    }
}
