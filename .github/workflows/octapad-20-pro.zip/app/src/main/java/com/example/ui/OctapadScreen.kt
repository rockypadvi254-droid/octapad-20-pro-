package com.example.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Bank
import com.example.data.PadUiModel
import com.example.data.PatchSummary
import com.example.data.db.SampleEntity
import com.example.samples.SampleImporter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ChassisCharcoal
import com.example.ui.theme.ControlBorder
import com.example.ui.theme.CoralRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.PatchViewModel
import kotlinx.coroutines.delay

private enum class ActiveOverlay {
    NONE,
    EDITOR,
    SETTINGS
}

@Composable
fun OctapadScreen(
    viewModel: PatchViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val bankPatches by viewModel.bankPatches.collectAsStateWithLifecycle()
    val favoritePatches by viewModel.favoritePatches.collectAsStateWithLifecycle()
    val allSamples by viewModel.allSamples.collectAsStateWithLifecycle()
    val fxState by viewModel.fxState.collectAsStateWithLifecycle()
    val audioStatus by viewModel.audioEngineStatus.collectAsStateWithLifecycle()
    val midiStatus by viewModel.midiStatus.collectAsStateWithLifecycle()
    val midiMappings by viewModel.midiMappings.collectAsStateWithLifecycle()
    val migrationReport by viewModel.migrationReport.collectAsStateWithLifecycle()
    val backupReport by viewModel.backupReport.collectAsStateWithLifecycle()
    val isBusy by viewModel.isBusy.collectAsStateWithLifecycle()

    var activeOverlay by remember { mutableStateOf(ActiveOverlay.NONE) }
    var showLoadDialog by remember { mutableStateOf(false) }
    var showCopyDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }
    var relinkPadTarget by remember { mutableStateOf<PadUiModel?>(null) }

    // Auto-dismiss transient status banner after 3.2s
    LaunchedEffect(uiState.statusBanner) {
        if (uiState.statusBanner != null) {
            delay(3200L)
            viewModel.dismissBanner()
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(ChassisBlack)
            .windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        when (activeOverlay) {
            ActiveOverlay.EDITOR -> {
                PatchEditor(
                    bank = uiState.selectedBank,
                    patchNumber = uiState.selectedPatchNumber,
                    initialPatchName = uiState.currentPatchName,
                    initialPads = uiState.pads,
                    samples = allSamples,
                    onPreviewSample = { sid, vol, pitch -> viewModel.previewSample(sid, vol, pitch) },
                    onImportCustomSample = { uri, cb -> viewModel.importCustomSample(uri, cb) },
                    onSave = { name, editedPads ->
                        viewModel.saveEditedPatch(name, editedPads)
                        activeOverlay = ActiveOverlay.NONE
                    },
                    onCancel = { activeOverlay = ActiveOverlay.NONE }
                )
            }
            ActiveOverlay.SETTINGS -> {
                SettingsScreen(
                    masterVolume = uiState.masterVolume,
                    pads = uiState.pads,
                    fxState = fxState,
                    audioStatus = audioStatus,
                    midiStatus = midiStatus,
                    midiMappings = midiMappings,
                    samples = allSamples,
                    migrationReport = migrationReport,
                    backupReport = backupReport,
                    isBusy = isBusy,
                    onMasterVolumeChange = { viewModel.setMasterVolume(it) },
                    onPadVolumeChange = { padIdx, vol -> viewModel.setPadVolumeQuick(padIdx, vol) },
                    onFxChange = { viewModel.updateAudioFx(it) },
                    onLegacyFolderSelected = { uri, preserve -> viewModel.runLegacyFolderMigration(uri, preserve) },
                    onLegacyZipSelected = { uri, preserve -> viewModel.runLegacyZipMigration(uri, preserve) },
                    onExportBackup = { uri -> viewModel.exportBackup(uri) },
                    onImportBackup = { uri, overwrite -> viewModel.importBackup(uri, overwrite) },
                    onSaveMidiMappings = { viewModel.updateMidiMappings(it) },
                    onAddSample = { uri -> viewModel.importCustomSample(uri) },
                    onPreviewSample = { sid -> viewModel.previewSample(sid) },
                    onVerifySample = { sid -> viewModel.verifySampleHealth(sid) },
                    onDeleteSample = { sid -> viewModel.deleteUserSample(sid) },
                    onClose = { activeOverlay = ActiveOverlay.NONE }
                )
            }
            ActiveOverlay.NONE -> {
                // Main Landscape Octapad Performance View
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    HeaderBar(
                        selectedBank = uiState.selectedBank,
                        patchNumber = uiState.selectedPatchNumber,
                        patchName = uiState.currentPatchName,
                        isFavorite = uiState.isCurrentFavorite,
                        masterVolume = uiState.masterVolume,
                        midiStatus = midiStatus,
                        onSelectBank = { viewModel.selectBank(it) },
                        onToggleFavorite = { viewModel.toggleFavorite() },
                        onSaveClick = { viewModel.saveCurrentPatchExplicit() },
                        onLoadClick = { showLoadDialog = true },
                        onEditClick = { activeOverlay = ActiveOverlay.EDITOR },
                        onCopyClick = { showCopyDialog = true },
                        onClearClick = { showClearDialog = true },
                        onSettingsClick = { activeOverlay = ActiveOverlay.SETTINGS },
                        onMasterVolumeChange = { viewModel.setMasterVolume(it) }
                    )

                    PatchNumberBar(
                        selectedBank = uiState.selectedBank,
                        selectedPatchNumber = uiState.selectedPatchNumber,
                        patches = bankPatches,
                        onSelectPatch = { viewModel.selectPatch(it) }
                    )

                    // Performance Area: Strictly 8 Pads in 4 columns x 2 rows
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Row 1: PAD 1..4
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (i in 0..3) {
                                val pad = uiState.pads.getOrNull(i) ?: PadUiModel(i + 1, null, "EMPTY")
                                PadView(
                                    pad = pad,
                                    hitSignalFlow = viewModel.padHitSignals[i],
                                    onPadTrigger = { idx, vel -> viewModel.triggerPadHit(idx, vel) },
                                    onRelinkMissingSample = { idx ->
                                        relinkPadTarget = uiState.pads.firstOrNull { it.padIndex == idx }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                )
                            }
                        }

                        // Row 2: PAD 5..8
                        Row(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            for (i in 4..7) {
                                val pad = uiState.pads.getOrNull(i) ?: PadUiModel(i + 1, null, "EMPTY")
                                PadView(
                                    pad = pad,
                                    hitSignalFlow = viewModel.padHitSignals[i],
                                    onPadTrigger = { idx, vel -> viewModel.triggerPadHit(idx, vel) },
                                    onRelinkMissingSample = { idx ->
                                        relinkPadTarget = uiState.pads.firstOrNull { it.padIndex == idx }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxHeight()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Transient Toast / Status Banner
        AnimatedVisibility(
            visible = uiState.statusBanner != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
        ) {
            Surface(
                color = PanelElevated,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ElectricCyan),
                shadowElevation = 8.dp
            ) {
                Text(
                    text = uiState.statusBanner ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextPrimary,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }
    }

    // LOAD Patch Browser Dialog
    if (showLoadDialog) {
        LoadPatchDialog(
            currentBank = uiState.selectedBank,
            currentPatchNumber = uiState.selectedPatchNumber,
            bankPatches = bankPatches,
            favoritePatches = favoritePatches,
            onReloadActive = {
                viewModel.reloadCurrentPatch()
                showLoadDialog = false
            },
            onLoadPatch = { bank, num ->
                viewModel.selectBankAndPatch(bank, num)
                viewModel.reloadCurrentPatch()
                showLoadDialog = false
            },
            onDismiss = { showLoadDialog = false }
        )
    }

    // COPY Patch Dialog
    if (showCopyDialog) {
        CopyPatchDialog(
            sourceBank = uiState.selectedBank,
            sourceNumber = uiState.selectedPatchNumber,
            sourceName = uiState.currentPatchName,
            onConfirmCopy = { targetBank, targetNum ->
                viewModel.copyCurrentPatchTo(targetBank, targetNum)
                showCopyDialog = false
            },
            onDismiss = { showCopyDialog = false }
        )
    }

    // CLEAR Patch Confirmation Dialog
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = ChassisCharcoal,
            title = {
                Text(
                    "Clear ${uiState.selectedBank.label} Patch ${uiState.selectedPatchNumber}?",
                    color = CoralRed
                )
            },
            text = {
                Text(
                    "This clears only \"${uiState.currentPatchName}\" (${uiState.selectedBank.code}-${uiState.selectedPatchNumber}). Other patches in Bank A and Bank B are not affected.",
                    color = TextPrimary
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearCurrentPatch()
                        showClearDialog = false
                    },
                    modifier = Modifier.testTag("confirm_clear_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = CoralRed, contentColor = TextPrimary)
                ) {
                    Text("CLEAR PATCH")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("CANCEL", color = TextSecondary)
                }
            }
        )
    }

    // RELINK Missing Sample Dialog
    relinkPadTarget?.let { pad ->
        RelinkSampleDialog(
            pad = pad,
            samples = allSamples,
            onRelink = { sampleId ->
                viewModel.relinkMissingPadSample(pad.padIndex, sampleId)
                relinkPadTarget = null
            },
            onImportAndRelink = { uri ->
                viewModel.importCustomSample(uri) { imported ->
                    viewModel.relinkMissingPadSample(pad.padIndex, imported.sampleId)
                    relinkPadTarget = null
                }
            },
            onDismiss = { relinkPadTarget = null }
        )
    }
}

@Composable
private fun LoadPatchDialog(
    currentBank: Bank,
    currentPatchNumber: Int,
    bankPatches: List<PatchSummary>,
    favoritePatches: List<PatchSummary>,
    onReloadActive: () -> Unit,
    onLoadPatch: (Bank, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var showFavoritesTab by remember { mutableStateOf(false) }
    val items = if (showFavoritesTab) favoritePatches else bankPatches

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ChassisCharcoal,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("LOAD PATCH (${currentBank.label})", color = ElectricCyan)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { showFavoritesTab = false },
                        border = BorderStroke(1.dp, if (!showFavoritesTab) ElectricCyan else ControlBorder)
                    ) { Text("${currentBank.label} 1–100", color = TextPrimary) }
                    OutlinedButton(
                        onClick = { showFavoritesTab = true },
                        border = BorderStroke(1.dp, if (showFavoritesTab) AmberGold else ControlBorder)
                    ) { Text("FAVORITES (${favoritePatches.size})", color = AmberGold) }
                }
            }
        },
        text = {
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(220.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(items, key = { it.patchKey }) { patch ->
                    val active = patch.bank == currentBank && patch.patchNumber == currentPatchNumber
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (active) ElectricCyan.copy(alpha = 0.2f) else PanelSurface)
                            .border(1.dp, if (active) ElectricCyan else ControlBorder, RoundedCornerShape(6.dp))
                            .clickable { onLoadPatch(patch.bank, patch.patchNumber) }
                            .padding(6.dp)
                    ) {
                        Text(
                            text = "${patch.bank.code}-${patch.patchNumber}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (patch.bank == Bank.A) ElectricCyan else AmberGold
                        )
                        Text(
                            text = patch.name,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onReloadActive,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ChassisBlack)
            ) {
                Text("RELOAD CURRENT")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun CopyPatchDialog(
    sourceBank: Bank,
    sourceNumber: Int,
    sourceName: String,
    onConfirmCopy: (Bank, Int) -> Unit,
    onDismiss: () -> Unit
) {
    var targetBank by remember { mutableStateOf(sourceBank) }
    var targetNumber by remember { mutableIntStateOf(if (sourceNumber < 100) sourceNumber + 1 else 1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ChassisCharcoal,
        title = {
            Text("COPY ${sourceBank.code}-$sourceNumber ($sourceName)", color = ElectricCyan)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select destination bank & patch number (1–100):", color = TextSecondary)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = { targetBank = Bank.A },
                        border = BorderStroke(1.dp, if (targetBank == Bank.A) ElectricCyan else ControlBorder)
                    ) { Text("BANK A", color = if (targetBank == Bank.A) ElectricCyan else TextPrimary) }
                    OutlinedButton(
                        onClick = { targetBank = Bank.B },
                        border = BorderStroke(1.dp, if (targetBank == Bank.B) AmberGold else ControlBorder)
                    ) { Text("BANK B", color = if (targetBank == Bank.B) AmberGold else TextPrimary) }
                }
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(onClick = { targetNumber = (targetNumber - 10).coerceAtLeast(1) }) { Text("-10") }
                    OutlinedButton(onClick = { targetNumber = (targetNumber - 1).coerceAtLeast(1) }) { Text("-1") }
                    Text(
                        text = "${targetBank.code}-$targetNumber",
                        style = MaterialTheme.typography.titleLarge,
                        color = ElectricCyan,
                        modifier = Modifier.testTag("copy_target_label")
                    )
                    OutlinedButton(onClick = { targetNumber = (targetNumber + 1).coerceAtMost(100) }) { Text("+1") }
                    OutlinedButton(onClick = { targetNumber = (targetNumber + 10).coerceAtMost(100) }) { Text("+10") }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmCopy(targetBank, targetNumber) },
                modifier = Modifier.testTag("confirm_copy_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = ChassisBlack)
            ) {
                Text("COPY PATCH", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CANCEL", color = TextSecondary)
            }
        }
    )
}

@Composable
private fun RelinkSampleDialog(
    pad: PadUiModel,
    samples: List<SampleEntity>,
    onRelink: (String) -> Unit,
    onImportAndRelink: (android.net.Uri) -> Unit,
    onDismiss: () -> Unit
) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onImportAndRelink(uri)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ChassisCharcoal,
        title = {
            Text("RELINK MISSING SAMPLE • PAD ${pad.padIndex}", color = CoralRed)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "Original missing file: ${pad.missingSampleName ?: pad.sampleName}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AmberGold
                )
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(samples.filter { it.decodingVerified }, key = { it.sampleId }) { sample ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(PanelSurface)
                                .border(1.dp, ControlBorder, RoundedCornerShape(6.dp))
                                .clickable { onRelink(sample.sampleId) }
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(sample.originalFilename, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(sample.format, color = ElectricCyan, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { picker.launch(SampleImporter.SUPPORTED_MIME_TYPES) },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ChassisBlack)
            ) {
                Text("BROWSE & IMPORT FILE")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("CLOSE", color = TextSecondary)
            }
        }
    )
}
