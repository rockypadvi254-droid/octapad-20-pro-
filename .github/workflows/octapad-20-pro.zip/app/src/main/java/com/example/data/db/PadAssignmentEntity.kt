package com.example.data.db

import androidx.room.Entity

@Entity(
    tableName = "pad_assignments",
    primaryKeys = ["patchKey", "padIndex"]
)
data class PadAssignmentEntity(
    val patchKey: String,             // "A_1" .. "B_100"
    val padIndex: Int,                // 1..8
    val sampleId: String?,            // Reference to SampleEntity.sampleId (null if empty or missing)
    val missingSampleName: String? = null, // Original filename if legacy/backup sample couldn't be linked
    val volume: Float = 0.85f,
    val pitch: Float = 1.0f,          // Playback rate 0.5f..2.0f
    val pan: Float = 0.0f,            // Stereo pan -1.0f..1.0f
    val enabled: Boolean = true
)
