package com.example.legacy

import com.example.data.db.SampleEntity
import com.example.samples.SampleRegistry
import java.io.File

class LegacySampleRegistry(
    private val sampleRegistry: SampleRegistry
) {
    private val byRelativePath = HashMap<String, SampleEntity>()
    private val byFilenameLower = HashMap<String, MutableList<SampleEntity>>()
    private val byBaseNameLower = HashMap<String, MutableList<SampleEntity>>()
    private val bySampleId = HashMap<String, SampleEntity>()

    suspend fun rebuildIndex() {
        byRelativePath.clear()
        byFilenameLower.clear()
        byBaseNameLower.clear()
        bySampleId.clear()

        for (s in sampleRegistry.getAllSamples()) {
            indexSample(s, relativePath = null)
        }
    }

    fun indexSample(sample: SampleEntity, relativePath: String?) {
        bySampleId[sample.sampleId] = sample
        if (!relativePath.isNullOrBlank()) {
            byRelativePath[normalizePath(relativePath)] = sample
        }
        val origName = File(sample.originalFilename).name.lowercase()
        if (origName.isNotEmpty()) {
            byFilenameLower.getOrPut(origName) { mutableListOf() }.add(sample)
            val base = origName.substringBeforeLast('.')
            if (base.isNotEmpty()) {
                byBaseNameLower.getOrPut(base) { mutableListOf() }.add(sample)
            }
        }
    }

    /**
     * Resolves a legacy sample reference against verified imported samples.
     * Returns null if missing; callers MUST NOT replace missing samples with random sounds.
     */
    fun resolveReference(rawReference: String?): SampleEntity? {
        if (rawReference.isNullOrBlank()) return null
        val trimmed = rawReference.trim()

        // 1. Direct sampleId match
        bySampleId[trimmed]?.let { if (isVerifiedFile(it)) return it }

        // 2. Normalized relative path match
        val normPath = normalizePath(trimmed)
        byRelativePath[normPath]?.let { if (isVerifiedFile(it)) return it }

        // 3. Exact filename match (case-insensitive)
        val fileNameOnly = trimmed.replace('\\', '/').substringAfterLast('/').lowercase()
        byFilenameLower[fileNameOnly]?.firstOrNull { isVerifiedFile(it) }?.let { return it }

        // 4. Base filename without extension (case-insensitive)
        val baseOnly = fileNameOnly.substringBeforeLast('.')
        if (baseOnly.isNotEmpty()) {
            byBaseNameLower[baseOnly]?.firstOrNull { isVerifiedFile(it) }?.let { return it }
        }

        return null
    }

    private fun isVerifiedFile(sample: SampleEntity): Boolean {
        val f = File(sample.storedPath)
        return f.exists() && f.length() > 0L && sample.decodingVerified
    }

    private fun normalizePath(path: String): String {
        return path.replace('\\', '/').trimStart('/').lowercase()
    }
}
