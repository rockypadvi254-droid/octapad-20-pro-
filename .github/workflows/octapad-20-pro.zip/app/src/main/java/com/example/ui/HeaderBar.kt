package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Bank
import com.example.data.MidiStatus
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ChassisCharcoal
import com.example.ui.theme.ControlBorder
import com.example.ui.theme.CoralRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.LcdBackground
import com.example.ui.theme.LcdBorder
import com.example.ui.theme.LcdTextAmber
import com.example.ui.theme.LcdTextCyan
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun HeaderBar(
    selectedBank: Bank,
    patchNumber: Int,
    patchName: String,
    isFavorite: Boolean,
    masterVolume: Float,
    midiStatus: MidiStatus,
    onSelectBank: (Bank) -> Unit,
    onToggleFavorite: () -> Unit,
    onSaveClick: () -> Unit,
    onLoadClick: () -> Unit,
    onEditClick: () -> Unit,
    onCopyClick: () -> Unit,
    onClearClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onMasterVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = ChassisCharcoal,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, ControlBorder)
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(PanelSurface, ChassisCharcoal)))
                .padding(horizontal = 8.dp, vertical = 5.dp)
        ) {
            val isWide = maxWidth >= 860.dp

            if (isWide) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    BrandBlock()
                    BankToggleGroup(selectedBank, onSelectBank)
                    LcdPatchDisplay(
                        selectedBank = selectedBank,
                        patchNumber = patchNumber,
                        patchName = patchName,
                        isFavorite = isFavorite,
                        onToggleFavorite = onToggleFavorite,
                        modifier = Modifier.weight(1f)
                    )
                    ActionButtonsRow(
                        onSaveClick = onSaveClick,
                        onLoadClick = onLoadClick,
                        onEditClick = onEditClick,
                        onCopyClick = onCopyClick,
                        onClearClick = onClearClick,
                        onSettingsClick = onSettingsClick
                    )
                    MasterVolumeWidget(masterVolume, onMasterVolumeChange, Modifier.width(120.dp))
                    MidiStatusBadge(midiStatus)
                }
            } else {
                // Compact 2-row hardware layout for standard landscape phones (< 860dp wide)
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        BrandBlock()
                        BankToggleGroup(selectedBank, onSelectBank)
                        LcdPatchDisplay(
                            selectedBank = selectedBank,
                            patchNumber = patchNumber,
                            patchName = patchName,
                            isFavorite = isFavorite,
                            onToggleFavorite = onToggleFavorite,
                            modifier = Modifier.weight(1f)
                        )
                        MidiStatusBadge(midiStatus)
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ActionButtonsRow(
                            onSaveClick = onSaveClick,
                            onLoadClick = onLoadClick,
                            onEditClick = onEditClick,
                            onCopyClick = onCopyClick,
                            onClearClick = onClearClick,
                            onSettingsClick = onSettingsClick,
                            modifier = Modifier.weight(1f)
                        )
                        MasterVolumeWidget(masterVolume, onMasterVolumeChange, Modifier.width(128.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun BrandBlock() {
    Column(verticalArrangement = Arrangement.Center) {
        Text(
            text = "OCTAPAD 20 PRO",
            style = MaterialTheme.typography.titleLarge.copy(
                fontSize = 13.5.sp,
                letterSpacing = 1.0.sp
            ),
            color = ElectricCyan,
            maxLines = 1
        )
        Text(
            text = "PROFESSIONAL MOBILE OCTAPAD",
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp),
            color = TextSecondary,
            maxLines = 1
        )
    }
}

@Composable
private fun BankToggleGroup(
    selectedBank: Bank,
    onSelectBank: (Bank) -> Unit
) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(ChassisBlack)
            .border(1.dp, ControlBorder, RoundedCornerShape(8.dp))
            .padding(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        BankToggleChip(
            label = "BANK A",
            selected = selectedBank == Bank.A,
            accent = ElectricCyan,
            testTag = "bank_a_button",
            onClick = { onSelectBank(Bank.A) }
        )
        BankToggleChip(
            label = "BANK B",
            selected = selectedBank == Bank.B,
            accent = AmberGold,
            testTag = "bank_b_button",
            onClick = { onSelectBank(Bank.B) }
        )
    }
}

@Composable
private fun LcdPatchDisplay(
    selectedBank: Bank,
    patchNumber: Int,
    patchName: String,
    isFavorite: Boolean,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .height(36.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(LcdBackground)
            .border(1.dp, LcdBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(5.dp))
                .background(if (selectedBank == Bank.A) ElectricCyan.copy(alpha = 0.16f) else AmberGold.copy(alpha = 0.16f))
                .padding(horizontal = 7.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${selectedBank.code}-$patchNumber",
                style = MaterialTheme.typography.titleLarge.copy(fontSize = 12.5.sp),
                color = if (selectedBank == Bank.A) LcdTextCyan else LcdTextAmber,
                modifier = Modifier.testTag("current_patch_number")
            )
        }
        Text(
            text = patchName,
            style = MaterialTheme.typography.titleMedium.copy(fontSize = 13.sp),
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .weight(1f)
                .testTag("current_patch_name")
        )
        IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier
                .size(30.dp)
                .testTag("favorite_toggle_button")
        ) {
            Icon(
                imageVector = if (isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
                contentDescription = if (isFavorite) "Remove favorite" else "Add favorite",
                tint = if (isFavorite) AmberGold else TextMuted,
                modifier = Modifier.size(17.dp)
            )
        }
    }
}

@Composable
private fun ActionButtonsRow(
    onSaveClick: () -> Unit,
    onLoadClick: () -> Unit,
    onEditClick: () -> Unit,
    onCopyClick: () -> Unit,
    onClearClick: () -> Unit,
    onSettingsClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderActionButton("SAVE", EmeraldGreen, "save_button", onSaveClick)
        HeaderActionButton("LOAD", ElectricCyan, "load_button", onLoadClick)
        HeaderActionButton("EDIT", AmberGold, "edit_button", onEditClick)
        HeaderActionButton("COPY", TextPrimary, "copy_button", onCopyClick)
        HeaderActionButton("CLEAR", CoralRed, "clear_button", onClearClick)
        OutlinedButton(
            onClick = onSettingsClick,
            modifier = Modifier
                .height(34.dp)
                .testTag("settings_button"),
            shape = RoundedCornerShape(6.dp),
            border = BorderStroke(1.dp, ControlBorder),
            colors = ButtonDefaults.outlinedButtonColors(
                containerColor = PanelElevated,
                contentColor = TextPrimary
            ),
            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Settings,
                contentDescription = "Settings",
                modifier = Modifier.size(13.dp),
                tint = ElectricCyan
            )
            Spacer(modifier = Modifier.width(3.dp))
            Text(
                text = "SETTINGS",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun MasterVolumeWidget(
    masterVolume: Float,
    onMasterVolumeChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .height(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(PanelElevated)
            .border(1.dp, ControlBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
            contentDescription = "Master volume",
            tint = ElectricCyan,
            modifier = Modifier.size(14.dp)
        )
        Slider(
            value = masterVolume,
            onValueChange = onMasterVolumeChange,
            valueRange = 0f..1f,
            modifier = Modifier
                .weight(1f)
                .testTag("master_volume_slider"),
            colors = SliderDefaults.colors(
                thumbColor = ElectricCyan,
                activeTrackColor = ElectricCyan,
                inactiveTrackColor = ControlBorder
            )
        )
        Text(
            text = "${(masterVolume * 100).roundToInt()}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
    }
}

@Composable
private fun MidiStatusBadge(midiStatus: MidiStatus) {
    Row(
        modifier = Modifier
            .height(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(
                if (midiStatus.isConnected) EmeraldGreen.copy(alpha = 0.14f) else ChassisBlack
            )
            .border(
                1.dp,
                if (midiStatus.isConnected) EmeraldGreen else ControlBorder,
                RoundedCornerShape(6.dp)
            )
            .padding(horizontal = 7.dp)
            .testTag("midi_status_badge"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(if (midiStatus.isConnected) EmeraldGreen else TextMuted)
        )
        Text(
            text = if (midiStatus.isConnected) "MIDI ON" else "MIDI OFF",
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = if (midiStatus.isConnected) EmeraldGreen else TextMuted,
            maxLines = 1
        )
    }
}

@Composable
private fun BankToggleChip(
    label: String,
    selected: Boolean,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .height(30.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(if (selected) accent.copy(alpha = 0.22f) else Color.Transparent)
            .border(
                width = if (selected) 1.dp else 0.dp,
                color = if (selected) accent else Color.Transparent,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 9.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge.copy(fontSize = 10.5.sp),
            color = if (selected) accent else TextSecondary,
            maxLines = 1
        )
    }
}

@Composable
private fun HeaderActionButton(
    label: String,
    accent: Color,
    testTag: String,
    onClick: () -> Unit
) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier
            .height(34.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = PanelElevated,
            contentColor = accent
        ),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = accent,
            maxLines = 1
        )
    }
}
