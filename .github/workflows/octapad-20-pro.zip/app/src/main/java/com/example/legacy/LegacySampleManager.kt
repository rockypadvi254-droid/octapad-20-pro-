package com.example.legacy

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import com.example.audio.AudioEffectProcessor
import com.example.audio.FactorySampleGenerator
import com.example.data.db.SampleEntity
import com.example.samples.SampleRegistry
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.UUID
import java.util.zip.ZipInputStream

data class LegacyScanCandidate(
    val name: String,
    val relativePath: String,
    val cachedFile: File
)

data class LegacySampleScanResult(
    val detectedFormatHint: String,
    val totalSamplesDetected: Int,
    val importedSamples: List<SampleEntity>,
    val skippedDuplicateCount: Int,
    val failedSamples: List<String>,
    val unsupportedFiles: List<String>,
    val configCandidates: List<LegacyScanCandidate>
)

class LegacySampleManager(
    private val context: Context,
    private val sampleRegistry: SampleRegistry,
    private val legacySampleRegistry: LegacySampleRegistry
) {
    private val audioExtensions = setOf("wav", "mp3", "ogg")
    private val configExtensions = setOf("json", "xml", "db", "sqlite", "sqlite3", "cfg", "ini", "txt", "patch", "kit", "oct")

    suspend fun scanAndImportFolderUri(treeUri: Uri): LegacySampleScanResult {
        val workDir = File(context.cacheDir, "legacy_scan_${System.currentTimeMillis()}").apply { mkdirs() }
        val docId = DocumentsContract.getTreeDocumentId(treeUri)
        val rootDocUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId)

        val audioFiles = ArrayList<LegacyScanCandidate>()
        val configFiles = ArrayList<LegacyScanCandidate>()
        val unsupported = ArrayList<String>()

        traverseDocumentTree(treeUri, rootDocUri, "", workDir, audioFiles, configFiles, unsupported)

        val result = processCandidates(
            sourceFormatHint = "SAF Folder (${audioFiles.size} audio, ${configFiles.size} config)",
            audioCandidates = audioFiles,
            configCandidates = configFiles,
            unsupportedFiles = unsupported
        )
        // Clean only audio temp files; configCandidates are still needed by LegacyPatchImporter until migration finishes
        audioFiles.forEach { runCatching { it.cachedFile.delete() } }
        return result
    }

    suspend fun scanAndImportZipUri(zipUri: Uri): LegacySampleScanResult {
        val workDir = File(context.cacheDir, "legacy_zip_${System.currentTimeMillis()}").apply { mkdirs() }
        val audioFiles = ArrayList<LegacyScanCandidate>()
        val configFiles = ArrayList<LegacyScanCandidate>()
        val unsupported = ArrayList<String>()

        val input = context.contentResolver.openInputStream(zipUri)
            ?: return LegacySampleScanResult(
                detectedFormatHint = "Unreadable ZIP/Archive",
                totalSamplesDetected = 0,
                importedSamples = emptyList(),
                skippedDuplicateCount = 0,
                failedSamples = listOf("Could not open archive stream"),
                unsupportedFiles = emptyList(),
                configCandidates = emptyList()
            )

        input.use { stream ->
            ZipInputStream(stream).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val relPath = entry.name.replace('\\', '/').trimStart('/')
                        val fileName = relPath.substringAfterLast('/')
                        if (!fileName.startsWith(".")) {
                            val ext = fileName.substringAfterLast('.', "").lowercase()
                            when {
                                ext in audioExtensions -> {
                                    val cached = writeTempStream(workDir, relPath, zis)
                                    audioFiles.add(LegacyScanCandidate(fileName, relPath, cached))
                                }
                                ext in configExtensions -> {
                                    val cached = writeTempStream(workDir, relPath, zis)
                                    configFiles.add(LegacyScanCandidate(fileName, relPath, cached))
                                }
                                else -> unsupported.add(relPath)
                            }
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
        }

        val result = processCandidates(
            sourceFormatHint = "ZIP Archive (${audioFiles.size} audio, ${configFiles.size} config)",
            audioCandidates = audioFiles,
            configCandidates = configFiles,
            unsupportedFiles = unsupported
        )
        audioFiles.forEach { runCatching { it.cachedFile.delete() } }
        return result
    }

    suspend fun scanAndImportDirectory(dir: File): LegacySampleScanResult {
        val audioFiles = ArrayList<LegacyScanCandidate>()
        val configFiles = ArrayList<LegacyScanCandidate>()
        val unsupported = ArrayList<String>()

        if (dir.exists() && dir.isDirectory) {
            dir.walkTopDown().filter { it.isFile }.forEach { file ->
                val relPath = file.relativeTo(dir).path.replace('\\', '/')
                val ext = file.extension.lowercase()
                when {
                    ext in audioExtensions -> audioFiles.add(LegacyScanCandidate(file.name, relPath, file))
                    ext in configExtensions -> configFiles.add(LegacyScanCandidate(file.name, relPath, file))
                    else -> unsupported.add(relPath)
                }
            }
        }

        return processCandidates(
            sourceFormatHint = "Local Folder (${audioFiles.size} audio, ${configFiles.size} config)",
            audioCandidates = audioFiles,
            configCandidates = configFiles,
            unsupportedFiles = unsupported,
            copyInsteadOfMove = true
        )
    }

    private suspend fun processCandidates(
        sourceFormatHint: String,
        audioCandidates: List<LegacyScanCandidate>,
        configCandidates: List<LegacyScanCandidate>,
        unsupportedFiles: List<String>,
        copyInsteadOfMove: Boolean = false
    ): LegacySampleScanResult {
        legacySampleRegistry.rebuildIndex()
        val legacyDir = File(context.filesDir, "samples/legacy").apply { mkdirs() }
        val imported = ArrayList<SampleEntity>()
        val failed = ArrayList<String>()
        var duplicates = 0

        for (candidate in audioCandidates) {
            val file = candidate.cachedFile
            if (!file.exists() || file.length() == 0L) {
                failed.add("${candidate.relativePath} (empty or unreadable)")
                continue
            }
            val ext = candidate.name.substringAfterLast('.', "").uppercase()
            val decoded = AudioEffectProcessor.verifyAndInspectAudio(file, ext)
            if (!decoded.valid) {
                failed.add("${candidate.relativePath} (${decoded.errorMessage ?: "decode failed"})")
                continue
            }

            val hash = FactorySampleGenerator.sha256(file)
            val existing = sampleRegistry.findByContentHash(hash)
            if (existing != null && File(existing.storedPath).exists()) {
                duplicates++
                legacySampleRegistry.indexSample(existing, candidate.relativePath)
                continue
            }

            val sampleId = "smp_leg_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val safeName = candidate.name.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val destFile = File(legacyDir, "${sampleId}_$safeName")
            if (copyInsteadOfMove) {
                file.copyTo(destFile, overwrite = true)
            } else {
                if (!file.renameTo(destFile)) {
                    file.copyTo(destFile, overwrite = true)
                }
            }

            val entity = SampleEntity(
                sampleId = sampleId,
                originalFilename = candidate.name,
                displayName = candidate.name.substringBeforeLast('.').ifBlank { candidate.name },
                storedPath = destFile.absolutePath,
                sourceUri = null,
                format = ext,
                sourceType = "LEGACY_IMPORT",
                durationMs = decoded.durationMs,
                fileSizeBytes = destFile.length(),
                contentHash = hash,
                decodingVerified = true,
                errorMessage = null
            )
            sampleRegistry.registerSample(entity)
            legacySampleRegistry.indexSample(entity, candidate.relativePath)
            imported.add(entity)
        }

        return LegacySampleScanResult(
            detectedFormatHint = sourceFormatHint,
            totalSamplesDetected = audioCandidates.size,
            importedSamples = imported,
            skippedDuplicateCount = duplicates,
            failedSamples = failed,
            unsupportedFiles = unsupportedFiles,
            configCandidates = configCandidates
        )
    }

    private fun traverseDocumentTree(
        treeUri: Uri,
        parentDocUri: Uri,
        prefix: String,
        workDir: File,
        audioFiles: MutableList<LegacyScanCandidate>,
        configFiles: MutableList<LegacyScanCandidate>,
        unsupported: MutableList<String>
    ) {
        val parentDocId = DocumentsContract.getDocumentId(parentDocUri)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        context.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                val childId = cursor.getString(0)
                val name = cursor.getString(1) ?: continue
                val mime = cursor.getString(2) ?: ""
                val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                val relPath = if (prefix.isEmpty()) name else "$prefix/$name"

                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    traverseDocumentTree(treeUri, childUri, relPath, workDir, audioFiles, configFiles, unsupported)
                } else {
                    val ext = name.substringAfterLast('.', "").lowercase()
                    when {
                        ext in audioExtensions -> {
                            val cached = copyUriToTemp(childUri, workDir, relPath)
                            if (cached != null) audioFiles.add(LegacyScanCandidate(name, relPath, cached))
                            else unsupported.add("$relPath (read failed)")
                        }
                        ext in configExtensions -> {
                            val cached = copyUriToTemp(childUri, workDir, relPath)
                            if (cached != null) configFiles.add(LegacyScanCandidate(name, relPath, cached))
                            else unsupported.add("$relPath (read failed)")
                        }
                        else -> unsupported.add(relPath)
                    }
                }
            }
        }
    }

    private fun copyUriToTemp(uri: Uri, workDir: File, relPath: String): File? {
        return runCatching {
            val outFile = File(workDir, relPath.replace('/', '_'))
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(outFile).use { output -> input.copyTo(output) }
            } ?: return null
            outFile
        }.getOrNull()
    }

    private fun writeTempStream(workDir: File, relPath: String, stream: InputStream): File {
        val outFile = File(workDir, relPath.replace('/', '_'))
        val buf = ByteArray(8192)
        FileOutputStream(outFile).use { fos ->
            var read = stream.read(buf)
            while (read > 0) {
                fos.write(buf, 0, read)
                read = stream.read(buf)
            }
        }
        return outFile
    }
}
