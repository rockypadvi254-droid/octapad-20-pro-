package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.AudioEngineStatus
import com.example.data.AudioFxState
import com.example.data.BackupOperationReport
import com.example.data.LegacyMigrationReport
import com.example.data.MidiPadMapping
import com.example.data.MidiStatus
import com.example.data.PadUiModel
import com.example.data.db.SampleEntity
import com.example.samples.SampleImporter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ChassisCharcoal
import com.example.ui.theme.ControlBorder
import com.example.ui.theme.CoralRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PadNeonColors
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

private enum class SettingsTab(val title: String) {
    AUDIO_FX("AUDIO & FX"),
    LEGACY_IMPORT("OLD OCTAPAD"),
    BACKUP("BACKUP & RESTORE"),
    MIDI("USB MIDI"),
    SAMPLES_INFO("SAMPLES & INFO")
}

@Composable
fun SettingsScreen(
    masterVolume: Float,
    pads: List<PadUiModel>,
    fxState: AudioFxState,
    audioStatus: AudioEngineStatus,
    midiStatus: MidiStatus,
    midiMappings: List<MidiPadMapping>,
    samples: List<SampleEntity>,
    migrationReport: LegacyMigrationReport?,
    backupReport: BackupOperationReport?,
    isBusy: Boolean,
    onMasterVolumeChange: (Float) -> Unit,
    onPadVolumeChange: (padIndex: Int, volume: Float) -> Unit,
    onFxChange: (AudioFxState) -> Unit,
    onLegacyFolderSelected: (Uri, Boolean) -> Unit,
    onLegacyZipSelected: (Uri, Boolean) -> Unit,
    onExportBackup: (Uri) -> Unit,
    onImportBackup: (Uri, Boolean) -> Unit,
    onSaveMidiMappings: (List<MidiPadMapping>) -> Unit,
    onAddSample: (Uri) -> Unit,
    onPreviewSample: (String) -> Unit,
    onVerifySample: (String) -> Unit,
    onDeleteSample: (String) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onClose() }

    var activeTab by remember { mutableStateOf(SettingsTab.AUDIO_FX) }
    var preserveOriginalSlots by remember { mutableStateOf(true) }
    var overwriteOnRestore by remember { mutableStateOf(false) }

    val legacyFolderLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) onLegacyFolderSelected(uri, preserveOriginalSlots)
    }

    val legacyZipLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onLegacyZipSelected(uri, preserveOriginalSlots)
    }

    val backupExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        if (uri != null) onExportBackup(uri)
    }

    val backupImportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onImportBackup(uri, overwriteOnRestore)
    }

    val sampleAddLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) onAddSample(uri)
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = ChassisBlack
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Settings Header
            Surface(
                color = ChassisCharcoal,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, ControlBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onClose,
                        modifier = Modifier
                            .height(40.dp)
                            .testTag("settings_back_button"),
                        border = BorderStroke(1.dp, ElectricCyan),
                        contentPadding = PaddingValues(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to pads",
                            tint = ElectricCyan,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text("BACK TO PADS", color = ElectricCyan, style = MaterialTheme.typography.labelSmall)
                    }

                    Text(
                        text = "OCTAPAD 20 PRO  •  SETTINGS",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )

                    Spacer(Modifier.weight(1f))

                    if (isBusy) {
                        Text(
                            text = "PROCESSING...",
                            style = MaterialTheme.typography.labelMedium,
                            color = AmberGold
                        )
                    }
                }
            }

            // Tabbed Landscape Body
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Left Navigation Rail
                Surface(
                    modifier = Modifier
                        .width(176.dp)
                        .fillMaxHeight(),
                    color = ChassisCharcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ControlBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        SettingsTab.entries.forEach { tab ->
                            val selected = activeTab == tab
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .clip(RoundedCornerShape(7.dp))
                                    .background(if (selected) ElectricCyan.copy(alpha = 0.2f) else PanelSurface)
                                    .border(
                                        1.dp,
                                        if (selected) ElectricCyan else ControlBorder,
                                        RoundedCornerShape(7.dp)
                                    )
                                    .clickable { activeTab = tab }
                                    .padding(horizontal = 10.dp)
                                    .testTag("settings_tab_${tab.name.lowercase()}"),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                Text(
                                    text = tab.title,
                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                    color = if (selected) ElectricCyan else TextSecondary,
                                    maxLines = 1
                                )
                            }
                        }
                    }
                }

                // Right Content Panel
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight(),
                    color = ChassisCharcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ControlBorder)
                ) {
                    when (activeTab) {
                        SettingsTab.AUDIO_FX -> AudioAndFxTab(
                            masterVolume = masterVolume,
                            pads = pads,
                            fxState = fxState,
                            audioStatus = audioStatus,
                            onMasterVolumeChange = onMasterVolumeChange,
                            onPadVolumeChange = onPadVolumeChange,
                            onFxChange = onFxChange
                        )
                        SettingsTab.LEGACY_IMPORT -> LegacyImportTab(
                            preserveOriginalSlots = preserveOriginalSlots,
                            onPreserveToggle = { preserveOriginalSlots = it },
                            onSelectFolder = { legacyFolderLauncher.launch(null) },
                            onSelectZip = { legacyZipLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                            report = migrationReport
                        )
                        SettingsTab.BACKUP -> BackupRestoreTab(
                            overwriteOnRestore = overwriteOnRestore,
                            onOverwriteToggle = { overwriteOnRestore = it },
                            onExportClick = {
                                backupExportLauncher.launch("octapad20pro_backup_${System.currentTimeMillis()}.o20pro.zip")
                            },
                            onImportClick = {
                                backupImportLauncher.launch(arrayOf("application/zip", "application/json", "application/octet-stream", "*/*"))
                            },
                            backupReport = backupReport
                        )
                        SettingsTab.MIDI -> MidiSettingsTab(
                            midiStatus = midiStatus,
                            midiMappings = midiMappings,
                            onSaveMappings = onSaveMidiMappings
                        )
                        SettingsTab.SAMPLES_INFO -> SampleManagerAndInfoTab(
                            samples = samples,
                            audioStatus = audioStatus,
                            onAddSample = { sampleAddLauncher.launch(SampleImporter.SUPPORTED_MIME_TYPES) },
                            onPreviewSample = onPreviewSample,
                            onVerifySample = onVerifySample,
                            onDeleteSample = onDeleteSample
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioAndFxTab(
    masterVolume: Float,
    pads: List<PadUiModel>,
    fxState: AudioFxState,
    audioStatus: AudioEngineStatus,
    onMasterVolumeChange: (Float) -> Unit,
    onPadVolumeChange: (Int, Float) -> Unit,
    onFxChange: (AudioFxState) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Left Column: Audio Engine Status + Master & Individual Pad Volumes
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("AUDIO ENGINE & VOLUMES", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)

            Surface(
                color = PanelElevated,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ControlBorder)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Engine: ${if (audioStatus.isInitialized) "SoundPool Initialized" else "Offline"} • Focus: ${if (audioStatus.hasAudioFocus) "Granted" else "Unfocused"}",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (audioStatus.isInitialized) EmeraldGreen else CoralRed
                    )
                    Text(
                        text = "Loaded: ${audioStatus.loadedSamplesCount} • Loading: ${audioStatus.loadingSamplesCount} • Errors: ${audioStatus.failedSamplesCount} • Active Patch Ready: ${audioStatus.activePatchReady}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }

            // Master Volume
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(PanelSurface)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Master", style = MaterialTheme.typography.labelLarge, color = ElectricCyan, modifier = Modifier.width(68.dp))
                Slider(
                    value = masterVolume,
                    onValueChange = onMasterVolumeChange,
                    modifier = Modifier.weight(1f),
                    colors = SliderDefaults.colors(thumbColor = ElectricCyan, activeTrackColor = ElectricCyan)
                )
                Text("${(masterVolume * 100).roundToInt()}%", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
            }

            // Individual 8 Pad Volumes
            pads.forEach { pad ->
                val accent = PadNeonColors[(pad.padIndex - 1).coerceIn(0, 7)]
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(PanelSurface)
                        .padding(horizontal = 10.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("PAD ${pad.padIndex}", style = MaterialTheme.typography.labelMedium, color = accent, modifier = Modifier.width(56.dp))
                    Slider(
                        value = pad.volume,
                        onValueChange = { onPadVolumeChange(pad.padIndex, it) },
                        modifier = Modifier.weight(1f),
                        colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
                    )
                    Text("${(pad.volume * 100).roundToInt()}%", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                }
            }
        }

        // Right Column: Real DSP Effects (Reverb, Delay, Bass/Mid/Treble EQ)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("AUDIO EFFECTS (DSP + DELAY)", style = MaterialTheme.typography.titleMedium, color = AmberGold)

            // Reverb
            FxSectionCard(
                title = "Reverb (Schroeder DSP)",
                enabled = fxState.reverbEnabled,
                onToggle = { onFxChange(fxState.copy(reverbEnabled = it)) },
                accent = ElectricCyan
            ) {
                FxSliderLine("Wet Mix", "${(fxState.reverbMix * 100).roundToInt()}%", fxState.reverbMix, 0f..1f, ElectricCyan) {
                    onFxChange(fxState.copy(reverbMix = it))
                }
            }

            // Delay
            FxSectionCard(
                title = "Stereo Delay",
                enabled = fxState.delayEnabled,
                onToggle = { onFxChange(fxState.copy(delayEnabled = it)) },
                accent = AmberGold
            ) {
                FxSliderLine("Delay Time", "${fxState.delayTimeMs} ms", fxState.delayTimeMs.toFloat(), 80f..600f, AmberGold) {
                    onFxChange(fxState.copy(delayTimeMs = it.roundToInt()))
                }
                FxSliderLine("Feedback", "${(fxState.delayFeedback * 100).roundToInt()}%", fxState.delayFeedback, 0.05f..0.70f, AmberGold) {
                    onFxChange(fxState.copy(delayFeedback = it))
                }
            }

            // 3-Band EQ (Bass, Mid, Treble)
            FxSectionCard(
                title = "3-Band EQ (Bass / Mid / Treble)",
                enabled = fxState.eqEnabled,
                onToggle = { onFxChange(fxState.copy(eqEnabled = it)) },
                accent = EmeraldGreen
            ) {
                FxSliderLine("Bass (120Hz)", "${fxState.bassGainDb.roundToInt()} dB", fxState.bassGainDb, -12f..12f, EmeraldGreen) {
                    onFxChange(fxState.copy(bassGainDb = it))
                }
                FxSliderLine("Mid (1kHz)", "${fxState.midGainDb.roundToInt()} dB", fxState.midGainDb, -12f..12f, EmeraldGreen) {
                    onFxChange(fxState.copy(midGainDb = it))
                }
                FxSliderLine("Treble (5.5kHz)", "${fxState.trebleGainDb.roundToInt()} dB", fxState.trebleGainDb, -12f..12f, EmeraldGreen) {
                    onFxChange(fxState.copy(trebleGainDb = it))
                }
            }
        }
    }
}

@Composable
private fun FxSectionCard(
    title: String,
    enabled: Boolean,
    onToggle: (Boolean) -> Unit,
    accent: Color,
    content: @Composable () -> Unit
) {
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (enabled) accent else ControlBorder)
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, style = MaterialTheme.typography.labelLarge, color = if (enabled) accent else TextPrimary)
                Switch(
                    checked = enabled,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(checkedThumbColor = ChassisBlack, checkedTrackColor = accent)
                )
            }
            content()
        }
    }
}

@Composable
private fun FxSliderLine(
    label: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: Color,
    onChange: (Float) -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = TextSecondary, modifier = Modifier.width(96.dp))
        Slider(
            value = value,
            onValueChange = onChange,
            valueRange = range,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(thumbColor = accent, activeTrackColor = accent)
        )
        Text(valueLabel, style = MaterialTheme.typography.labelSmall, color = TextPrimary, modifier = Modifier.width(56.dp))
    }
}

@Composable
private fun LegacyImportTab(
    preserveOriginalSlots: Boolean,
    onPreserveToggle: (Boolean) -> Unit,
    onSelectFolder: () -> Unit,
    onSelectZip: () -> Unit,
    report: LegacyMigrationReport?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("OLD MOBILE OCTAPAD MIGRATION", style = MaterialTheme.typography.titleMedium, color = AmberGold)
        Text(
            text = "Uses Android Storage Access Framework (SAF) to inspect old Mobile Octapad folders, sample directories, ZIP archives, JSON, XML, SQLite databases, or INI patch configs. Original files are never altered; imported audio (WAV/MP3/OGG) is copied to private storage and verified.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = preserveOriginalSlots, onCheckedChange = onPreserveToggle)
            Text(
                text = "Preserve original bank & patch numbers (uncheck to place into free slots)",
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimary
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onSelectFolder,
                modifier = Modifier
                    .height(44.dp)
                    .testTag("legacy_select_folder_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ChassisBlack)
            ) {
                Icon(Icons.Filled.FolderOpen, contentDescription = "Select old folder", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text("SELECT OLD OCTAPAD FOLDER", fontWeight = FontWeight.Bold)
            }

            Button(
                onClick = onSelectZip,
                modifier = Modifier
                    .height(44.dp)
                    .testTag("legacy_select_zip_button"),
                colors = ButtonDefaults.buttonColors(containerColor = AmberGold, contentColor = ChassisBlack)
            ) {
                Text("IMPORT OLD PROJECT ZIP / BACKUP", fontWeight = FontWeight.Bold)
            }
        }

        if (report != null) {
            MigrationReportSummaryCard(report)
        }
    }
}

@Composable
fun MigrationReportSummaryCard(report: LegacyMigrationReport) {
    Surface(
        color = PanelElevated,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.6f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("MIGRATION REPORT • ${report.sourceDescription}", style = MaterialTheme.typography.labelLarge, color = ElectricCyan)
            Text("Detected format: ${report.detectedFormat}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(
                text = "Patches: ${report.importedPatchesCount}/${report.totalPatchesDetected} imported • ${report.failedPatchesCount} failed",
                style = MaterialTheme.typography.bodyMedium,
                color = TextPrimary
            )
            Text(
                text = "Samples: ${report.importedSamplesCount}/${report.totalSamplesDetected} imported (${report.skippedDuplicateSamplesCount} deduplicated) • Pad Assignments Restored: ${report.restoredPadAssignmentsCount}",
                style = MaterialTheme.typography.bodyMedium,
                color = EmeraldGreen
            )
            if (report.missingSamples.isNotEmpty()) {
                Text(
                    text = "Missing samples (${report.missingSamples.size}): ${report.missingSamples.joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = CoralRed
                )
            }
            if (report.unsupportedFiles.isNotEmpty()) {
                Text(
                    text = "Unsupported/Skipped (${report.unsupportedFiles.size}): ${report.unsupportedFiles.take(8).joinToString(", ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AmberGold
                )
            }
            if (report.warnings.isNotEmpty()) {
                Text(
                    text = "Warnings: ${report.warnings.joinToString(" | ")}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun BackupRestoreTab(
    overwriteOnRestore: Boolean,
    onOverwriteToggle: (Boolean) -> Unit,
    onExportClick: () -> Unit,
    onImportClick: () -> Unit,
    backupReport: BackupOperationReport?
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("BACKUP & RESTORE (.o20pro.zip v1)", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
        Text(
            text = "Exports all 200 patches (Bank A & B), pad settings, sample registry, MIDI mappings, FX settings, and custom/legacy audio files into a versioned ZIP archive. Also inspects external ZIP/JSON/XML/SQLite backups honestly and rejects undocumented proprietary hardware dumps with clear errors.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary
        )

        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = overwriteOnRestore, onCheckedChange = onOverwriteToggle)
            Text(
                text = "Overwrite customized patches on restore (uncheck to preserve existing custom patches)",
                style = MaterialTheme.typography.bodySmall,
                color = TextPrimary
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
                onClick = onExportClick,
                modifier = Modifier
                    .height(44.dp)
                    .testTag("export_backup_button"),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = ChassisBlack)
            ) {
                Text("EXPORT FULL BACKUP", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = onImportClick,
                modifier = Modifier
                    .height(44.dp)
                    .testTag("import_backup_button"),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ChassisBlack)
            ) {
                Text("IMPORT / EXTERNAL BACKUP", fontWeight = FontWeight.Bold)
            }
        }

        if (backupReport != null) {
            Surface(
                color = PanelElevated,
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, if (backupReport.success) EmeraldGreen else CoralRed)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = if (backupReport.success) "BACKUP SUCCESS" else "BACKUP NOTICE / UNSUPPORTED",
                        style = MaterialTheme.typography.labelLarge,
                        color = if (backupReport.success) EmeraldGreen else CoralRed
                    )
                    Text(backupReport.message, style = MaterialTheme.typography.bodyMedium, color = TextPrimary)
                    if (backupReport.formatDetected.isNotBlank()) {
                        Text("Format: ${backupReport.formatDetected}", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                    if (backupReport.missingSamples.isNotEmpty()) {
                        Text(
                            "Missing samples: ${backupReport.missingSamples.joinToString(", ")}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CoralRed
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MidiSettingsTab(
    midiStatus: MidiStatus,
    midiMappings: List<MidiPadMapping>,
    onSaveMappings: (List<MidiPadMapping>) -> Unit
) {
    val editable = remember(midiMappings) {
        mutableStateListOf<MidiPadMapping>().apply { addAll(midiMappings) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("USB MIDI INPUT & NOTE MAPPING", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                Text(
                    text = when {
                        !midiStatus.isHardwareSupported -> "Android MIDI API not supported on this device"
                        midiStatus.isConnected -> "Connected: ${midiStatus.connectedDeviceNames.joinToString()}"
                        else -> "No USB MIDI device connected (connect USB OTG MIDI controller)"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = if (midiStatus.isConnected) EmeraldGreen else TextSecondary
                )
            }
            Button(
                onClick = { onSaveMappings(editable.toList()) },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen, contentColor = ChassisBlack)
            ) {
                Text("SAVE MAPPINGS", fontWeight = FontWeight.Bold)
            }
        }

        if (midiStatus.lastReceivedNote != null) {
            Text(
                text = "Last MIDI Note In: ${midiStatus.lastReceivedNote} -> Triggered PAD ${midiStatus.lastTriggeredPad ?: "-"}",
                style = MaterialTheme.typography.labelMedium,
                color = AmberGold
            )
        }

        for (i in editable.indices) {
            val item = editable[i]
            val accent = PadNeonColors[(item.padIndex - 1).coerceIn(0, 7)]
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(7.dp))
                    .background(PanelSurface)
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("PAD ${item.padIndex}", style = MaterialTheme.typography.labelLarge, color = accent)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("MIDI Note: ${item.midiNote}", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                    OutlinedButton(
                        onClick = { editable[i] = item.copy(midiNote = (item.midiNote - 1).coerceAtLeast(0)) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(34.dp)
                    ) { Text("-") }
                    OutlinedButton(
                        onClick = { editable[i] = item.copy(midiNote = (item.midiNote + 1).coerceAtMost(127)) },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                        modifier = Modifier.height(34.dp)
                    ) { Text("+") }
                }
            }
        }
    }
}

@Composable
private fun SampleManagerAndInfoTab(
    samples: List<SampleEntity>,
    audioStatus: AudioEngineStatus,
    onAddSample: () -> Unit,
    onPreviewSample: (String) -> Unit,
    onVerifySample: (String) -> Unit,
    onDeleteSample: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("SAMPLE MANAGER (${samples.size} samples)", style = MaterialTheme.typography.titleMedium, color = ElectricCyan)
                Text(
                    text = "Landscape Mode: Locked (sensorLandscape) • Octapad 20 Pro v1.0 • Offline Ready",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Button(
                onClick = onAddSample,
                colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = ChassisBlack)
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Import sample", modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("ADD SAMPLE", fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            items(samples, key = { it.sampleId }) { sample ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(7.dp))
                        .background(PanelSurface)
                        .border(
                            1.dp,
                            if (sample.decodingVerified) ControlBorder else CoralRed,
                            RoundedCornerShape(7.dp)
                        )
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = sample.originalFilename,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = TextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${sample.format} • ${sample.durationMs}ms • ${sample.sourceType} • ${if (sample.decodingVerified) "Verified" else (sample.errorMessage ?: "Invalid")}",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (sample.decodingVerified) EmeraldGreen else CoralRed
                        )
                    }
                    IconButton(onClick = { onPreviewSample(sample.sampleId) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = "Preview", tint = ElectricCyan)
                    }
                    IconButton(onClick = { onVerifySample(sample.sampleId) }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Re-verify file", tint = AmberGold)
                    }
                    if (sample.sourceType != "FACTORY") {
                        IconButton(onClick = { onDeleteSample(sample.sampleId) }) {
                            Icon(Icons.Filled.Delete, contentDescription = "Delete custom sample", tint = CoralRed)
                        }
                    }
                }
            }
        }
    }
}
