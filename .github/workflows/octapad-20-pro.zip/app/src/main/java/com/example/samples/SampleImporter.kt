package com.example.samples

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.audio.AudioEffectProcessor
import com.example.audio.FactorySampleGenerator
import com.example.data.db.SampleEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

sealed class SampleImportResult {
    data class Success(val sample: SampleEntity, val wasDuplicate: Boolean = false) : SampleImportResult()
    data class Failure(val filename: String, val reason: String) : SampleImportResult()
}

class SampleImporter(
    private val context: Context,
    private val registry: SampleRegistry
) {
    companion object {
        val SUPPORTED_EXTENSIONS = setOf("wav", "mp3", "ogg")
        val SUPPORTED_MIME_TYPES = arrayOf(
            "audio/wav",
            "audio/x-wav",
            "audio/wave",
            "audio/mpeg",
            "audio/mp3",
            "audio/ogg",
            "application/ogg",
            "audio/*"
        )
    }

    suspend fun importFromUri(
        uri: Uri,
        sourceType: String = "USER_IMPORT"
    ): SampleImportResult = withContext(Dispatchers.IO) {
        val originalName = resolveDisplayName(uri) ?: "imported_sample_${System.currentTimeMillis()}"
        val ext = originalName.substringAfterLast('.', "").lowercase()
        val mime = context.contentResolver.getType(uri)?.lowercase() ?: ""

        val detectedFormat = detectSupportedFormat(ext, mime)
            ?: return@withContext SampleImportResult.Failure(
                filename = originalName,
                reason = "Unsupported file format ($ext / $mime). Only WAV, MP3, and OGG are supported."
            )

        val importDir = File(context.filesDir, "samples/imported").apply { mkdirs() }
        val safeBase = originalName.substringBeforeLast('.')
            .replace(Regex("[^A-Za-z0-9._-]"), "_")
            .take(40)
            .ifEmpty { "sample" }
        val tempFile = File(importDir, "tmp_${UUID.randomUUID()}.$ext")

        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: return@withContext SampleImportResult.Failure(
                    originalName,
                    "Unable to open selected file stream."
                )
            input.use { src ->
                FileOutputStream(tempFile).use { dst ->
                    src.copyTo(dst)
                }
            }

            if (!tempFile.exists() || tempFile.length() == 0L) {
                tempFile.delete()
                return@withContext SampleImportResult.Failure(originalName, "Imported file is empty (0 bytes).")
            }

            val hash = FactorySampleGenerator.sha256(tempFile)
            val existingByHash = registry.findByContentHash(hash)
            if (existingByHash != null && File(existingByHash.storedPath).exists()) {
                tempFile.delete()
                return@withContext SampleImportResult.Success(existingByHash, wasDuplicate = true)
            }

            val decoded = AudioEffectProcessor.verifyAndInspectAudio(tempFile, detectedFormat)
            if (!decoded.valid) {
                tempFile.delete()
                return@withContext SampleImportResult.Failure(
                    originalName,
                    decoded.errorMessage ?: "Damaged or undecodable $detectedFormat audio file."
                )
            }

            val sampleId = "smp_usr_${UUID.randomUUID().toString().replace("-", "").take(12)}"
            val finalFile = File(importDir, "${sampleId}_$safeBase.${detectedFormat.lowercase()}")
            if (!tempFile.renameTo(finalFile)) {
                tempFile.copyTo(finalFile, overwrite = true)
                tempFile.delete()
            }

            val entity = SampleEntity(
                sampleId = sampleId,
                originalFilename = originalName,
                displayName = originalName.substringBeforeLast('.').ifBlank { originalName },
                storedPath = finalFile.absolutePath,
                sourceUri = uri.toString(),
                format = detectedFormat,
                sourceType = sourceType,
                durationMs = decoded.durationMs,
                fileSizeBytes = finalFile.length(),
                contentHash = hash,
                decodingVerified = true,
                errorMessage = null
            )
            registry.registerSample(entity)
            SampleImportResult.Success(entity, wasDuplicate = false)
        } catch (t: Throwable) {
            tempFile.delete()
            SampleImportResult.Failure(originalName, t.message ?: "Failed to import audio sample.")
        }
    }

    private fun resolveDisplayName(uri: Uri): String? {
        if (uri.scheme == "file") {
            return uri.lastPathSegment
        }
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/')
    }

    fun detectSupportedFormat(ext: String, mime: String): String? {
        return when {
            ext == "wav" || mime.contains("wav") || mime.contains("wave") -> "WAV"
            ext == "mp3" || mime == "audio/mpeg" || mime.contains("mp3") -> "MP3"
            ext == "ogg" || mime.contains("ogg") -> "OGG"
            else -> null
        }
    }
}
