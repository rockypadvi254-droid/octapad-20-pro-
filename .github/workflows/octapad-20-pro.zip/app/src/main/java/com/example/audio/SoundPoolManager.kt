package com.example.audio

import android.media.AudioAttributes
import android.media.SoundPool
import com.example.data.SampleLoadingStatus
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

class SoundPoolManager(
    private val maxLoadedCacheSize: Int = 96
) {
    private var soundPool: SoundPool? = null
    private val keyToSoundId = ConcurrentHashMap<String, Int>()
    private val soundIdToKey = ConcurrentHashMap<Int, String>()
    private val keyStatus = ConcurrentHashMap<String, SampleLoadingStatus>()
    private val keyErrors = ConcurrentHashMap<String, String>()
    private val accessOrder = ConcurrentHashMap<String, Long>()
    private val listeners = CopyOnWriteArrayList<(String, SampleLoadingStatus, String?) -> Unit>()

    @Volatile
    var isInitialized: Boolean = false
        private set

    fun addStatusListener(listener: (String, SampleLoadingStatus, String?) -> Unit) {
        listeners.add(listener)
    }

    fun removeStatusListener(listener: (String, SampleLoadingStatus, String?) -> Unit) {
        listeners.remove(listener)
    }

    @Synchronized
    fun initialize() {
        if (soundPool != null && isInitialized) return
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val pool = SoundPool.Builder()
            .setMaxStreams(16)
            .setAudioAttributes(attrs)
            .build()

        pool.setOnLoadCompleteListener { _, sampleId, status ->
            val key = soundIdToKey[sampleId] ?: return@setOnLoadCompleteListener
            if (status == 0) {
                keyStatus[key] = SampleLoadingStatus.READY
                keyErrors.remove(key)
                notifyListeners(key, SampleLoadingStatus.READY, null)
            } else {
                keyStatus[key] = SampleLoadingStatus.ERROR
                val err = "SoundPool load error code $status"
                keyErrors[key] = err
                notifyListeners(key, SampleLoadingStatus.ERROR, err)
            }
        }
        soundPool = pool
        isInitialized = true
    }

    fun getStatus(cacheKey: String): SampleLoadingStatus {
        return keyStatus[cacheKey] ?: SampleLoadingStatus.UNLOADED
    }

    fun getError(cacheKey: String): String? = keyErrors[cacheKey]

    fun getLoadedCount(): Int = keyStatus.count { it.value == SampleLoadingStatus.READY }

    fun getLoadingCount(): Int = keyStatus.count { it.value == SampleLoadingStatus.LOADING }

    fun getErrorCount(): Int = keyStatus.count { it.value == SampleLoadingStatus.ERROR }

    fun loadSample(cacheKey: String, file: File, protectedKeys: Set<String> = emptySet()): SampleLoadingStatus {
        val pool = soundPool ?: run {
            initialize()
            soundPool
        } ?: return SampleLoadingStatus.ERROR

        if (!file.exists() || !file.canRead() || file.length() == 0L) {
            keyStatus[cacheKey] = SampleLoadingStatus.MISSING
            keyErrors[cacheKey] = "Sample file missing on disk"
            notifyListeners(cacheKey, SampleLoadingStatus.MISSING, "Sample file missing on disk")
            return SampleLoadingStatus.MISSING
        }

        val currentStatus = keyStatus[cacheKey]
        if (currentStatus == SampleLoadingStatus.READY || currentStatus == SampleLoadingStatus.LOADING) {
            accessOrder[cacheKey] = System.nanoTime()
            return currentStatus
        }

        evictIfNeeded(protectedKeys)

        return try {
            keyStatus[cacheKey] = SampleLoadingStatus.LOADING
            notifyListeners(cacheKey, SampleLoadingStatus.LOADING, null)
            val sid = pool.load(file.absolutePath, 1)
            if (sid <= 0) {
                keyStatus[cacheKey] = SampleLoadingStatus.ERROR
                val err = "SoundPool rejected sample file"
                keyErrors[cacheKey] = err
                notifyListeners(cacheKey, SampleLoadingStatus.ERROR, err)
                SampleLoadingStatus.ERROR
            } else {
                keyToSoundId[cacheKey] = sid
                soundIdToKey[sid] = cacheKey
                accessOrder[cacheKey] = System.nanoTime()
                // Status might already be updated synchronously in some Robolectric/OS implementations
                keyStatus[cacheKey] ?: SampleLoadingStatus.LOADING
            }
        } catch (t: Throwable) {
            keyStatus[cacheKey] = SampleLoadingStatus.ERROR
            val err = t.message ?: "SoundPool load exception"
            keyErrors[cacheKey] = err
            notifyListeners(cacheKey, SampleLoadingStatus.ERROR, err)
            SampleLoadingStatus.ERROR
        }
    }

    /**
     * Zero-allocation hot path for pad hits. Never plays an unloaded soundId.
     */
    fun play(
        cacheKey: String,
        leftVolume: Float,
        rightVolume: Float,
        pitchRate: Float,
        priority: Int = 1
    ): Int {
        val pool = soundPool ?: return 0
        if (keyStatus[cacheKey] != SampleLoadingStatus.READY) return 0
        val sid = keyToSoundId[cacheKey] ?: return 0
        accessOrder[cacheKey] = System.nanoTime()
        return pool.play(
            sid,
            leftVolume.coerceIn(0f, 1f),
            rightVolume.coerceIn(0f, 1f),
            priority,
            0,
            pitchRate.coerceIn(0.5f, 2.0f)
        )
    }

    fun stopStream(streamId: Int) {
        if (streamId > 0) {
            soundPool?.stop(streamId)
        }
    }

    fun setStreamVolume(streamId: Int, leftVolume: Float, rightVolume: Float) {
        if (streamId > 0) {
            soundPool?.setVolume(
                streamId,
                leftVolume.coerceIn(0f, 1f),
                rightVolume.coerceIn(0f, 1f)
            )
        }
    }

    fun unloadSample(cacheKey: String) {
        val sid = keyToSoundId.remove(cacheKey) ?: return
        soundIdToKey.remove(sid)
        keyStatus.remove(cacheKey)
        keyErrors.remove(cacheKey)
        accessOrder.remove(cacheKey)
        soundPool?.unload(sid)
    }

    private fun evictIfNeeded(protectedKeys: Set<String>) {
        if (keyToSoundId.size < maxLoadedCacheSize) return
        val candidates = accessOrder.entries
            .filter { it.key !in protectedKeys }
            .sortedBy { it.value }
        val toEvict = (keyToSoundId.size - maxLoadedCacheSize) + 8
        var evicted = 0
        for (entry in candidates) {
            if (evicted >= toEvict) break
            unloadSample(entry.key)
            evicted++
        }
    }

    private fun notifyListeners(key: String, status: SampleLoadingStatus, err: String?) {
        for (listener in listeners) {
            listener(key, status, err)
        }
    }

    @Synchronized
    fun release() {
        soundPool?.release()
        soundPool = null
        keyToSoundId.clear()
        soundIdToKey.clear()
        keyStatus.clear()
        keyErrors.clear()
        accessOrder.clear()
        isInitialized = false
    }
}
