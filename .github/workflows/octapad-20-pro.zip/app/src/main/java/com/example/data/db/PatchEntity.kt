package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "patches")
data class PatchEntity(
    @PrimaryKey val patchKey: String, // e.g. "A_1" .. "A_100", "B_1" .. "B_100"
    val bank: String,                 // "A" or "B"
    val patchNumber: Int,             // 1..100
    val name: String,
    val isFavorite: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_settings")
data class AppSettingsEntity(
    @PrimaryKey val id: Int = 1,
    val masterVolume: Float = 0.85f,
    val selectedBank: String = "A",
    val lastPatchNumberA: Int = 1,
    val lastPatchNumberB: Int = 1,
    val reverbEnabled: Boolean = false,
    val reverbMix: Float = 0.30f,
    val delayEnabled: Boolean = false,
    val delayTimeMs: Int = 220,
    val delayFeedback: Float = 0.35f,
    val eqEnabled: Boolean = false,
    val bassGainDb: Float = 0f,
    val midGainDb: Float = 0f,
    val trebleGainDb: Float = 0f
)

@Entity(tableName = "midi_mappings")
data class MidiMappingEntity(
    @PrimaryKey val padIndex: Int, // 1..8
    val midiNote: Int,
    val channel: Int = -1
)
