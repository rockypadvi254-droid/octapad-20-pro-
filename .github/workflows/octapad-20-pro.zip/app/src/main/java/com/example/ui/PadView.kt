package com.example.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.PadUiModel
import com.example.data.SampleLoadingStatus
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.CoralRed
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PadNeonColors
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlin.math.roundToInt

@Composable
fun PadView(
    pad: PadUiModel,
    hitSignalFlow: StateFlow<Long>,
    onPadTrigger: (padIndex: Int, velocity: Float) -> Unit,
    onRelinkMissingSample: (padIndex: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val neonColor = PadNeonColors[(pad.padIndex - 1).coerceIn(0, 7)]
    val hitTimestamp by hitSignalFlow.collectAsStateWithLifecycle()
    var isFlashing by remember { mutableStateOf(false) }

    LaunchedEffect(hitTimestamp) {
        if (hitTimestamp > 0L) {
            isFlashing = true
            delay(110L)
            isFlashing = false
        }
    }

    val borderColor by animateColorAsState(
        targetValue = when {
            !pad.enabled -> TextMuted.copy(alpha = 0.35f)
            isFlashing -> Color.White
            pad.sampleStatus == SampleLoadingStatus.MISSING || pad.sampleStatus == SampleLoadingStatus.ERROR -> CoralRed
            else -> neonColor
        },
        animationSpec = tween(durationMillis = if (isFlashing) 25 else 140),
        label = "pad_border_${pad.padIndex}"
    )

    val surfaceTop = if (isFlashing) neonColor.copy(alpha = 0.42f) else PanelElevated
    val surfaceBottom = if (isFlashing) neonColor.copy(alpha = 0.16f) else PanelSurface

    val statusColor = when (pad.sampleStatus) {
        SampleLoadingStatus.READY -> EmeraldGreen
        SampleLoadingStatus.LOADING -> AmberGold
        SampleLoadingStatus.MISSING, SampleLoadingStatus.ERROR -> CoralRed
        SampleLoadingStatus.UNLOADED -> TextMuted
    }

    Box(
        modifier = modifier
            .shadow(
                elevation = if (isFlashing) 14.dp else 4.dp,
                shape = RoundedCornerShape(14.dp),
                ambientColor = neonColor,
                spotColor = neonColor
            )
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(surfaceTop, surfaceBottom)
                )
            )
            .border(
                width = if (isFlashing) 3.dp else 2.dp,
                color = borderColor,
                shape = RoundedCornerShape(14.dp)
            )
            // Multi-touch instant trigger on pointer DOWN (zero tap disambiguation delay!)
            .pointerInput(pad.padIndex, pad.enabled) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    if (pad.enabled) {
                        onPadTrigger(pad.padIndex, 1.0f)
                    }
                }
            }
            .padding(10.dp)
            .testTag("pad_${pad.padIndex}")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: PAD 1..8 Label + Status LED + Volume %
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(if (pad.enabled) statusColor else TextMuted)
                    )
                    Text(
                        text = "PAD ${pad.padIndex}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontSize = 15.sp,
                            letterSpacing = 0.9.sp
                        ),
                        color = if (pad.enabled) neonColor else TextMuted
                    )
                }
                Text(
                    text = if (pad.enabled) "${(pad.volume * 100).roundToInt()}%" else "MUTED",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (pad.enabled) TextSecondary else CoralRed
                )
            }

            // Center / Bottom: Sample Assignment Name & Relink Action if Missing
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = pad.sampleName,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    ),
                    color = when {
                        !pad.enabled -> TextMuted
                        pad.missingSampleName != null || pad.sampleStatus == SampleLoadingStatus.ERROR -> CoralRed
                        else -> TextPrimary
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (pad.missingSampleName != null || pad.sampleStatus == SampleLoadingStatus.MISSING) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(5.dp))
                            .background(CoralRed.copy(alpha = 0.22f))
                            .border(1.dp, CoralRed, RoundedCornerShape(5.dp))
                            .clickable { onRelinkMissingSample(pad.padIndex) }
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                            .testTag("relink_pad_${pad.padIndex}")
                    ) {
                        Text(
                            text = "RELINK SAMPLE",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val pitchText = if (pad.pitch != 1.0f) "P:${"%.2f".format(pad.pitch)}x" else "P:1.0x"
                        val panText = when {
                            pad.pan < -0.05f -> "L${(-pad.pan * 100).roundToInt()}"
                            pad.pan > 0.05f -> "R${(pad.pan * 100).roundToInt()}"
                            else -> "C"
                        }
                        Text(
                            text = "$pitchText  $panText",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                            color = TextMuted
                        )
                        // Subtle inner strike indicator bar
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(3.dp))
                                .background(ChassisBlack.copy(alpha = 0.55f))
                                .padding(horizontal = 5.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = pad.sampleStatus.name,
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.5.sp),
                                color = statusColor
                            )
                        }
                    }
                }
            }
        }
    }
}
