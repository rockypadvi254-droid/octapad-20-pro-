package com.example.legacy

import android.database.sqlite.SQLiteDatabase
import android.util.Xml
import com.example.data.Bank
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.StringReader

data class LegacyPadSpec(
    val padIndex: Int, // 1..8
    val sampleRef: String?,
    val volume: Float = 0.85f,
    val pitch: Float = 1.0f,
    val pan: Float = 0.0f,
    val enabled: Boolean = true
)

data class LegacyPatchSpec(
    val sourceFile: String,
    val detectedFormat: String,
    val bank: Bank,
    val patchNumber: Int,
    val patchName: String,
    val isFavorite: Boolean = false,
    val pads: List<LegacyPadSpec>
)

data class LegacyPatchInspectionResult(
    val detectedFormats: Set<String>,
    val parsedPatches: List<LegacyPatchSpec>,
    val failedFiles: List<String>,
    val warnings: List<String>
)

class LegacyPatchImporter {

    fun inspectAndParseCandidates(candidates: List<LegacyScanCandidate>): LegacyPatchInspectionResult {
        val formats = LinkedHashSet<String>()
        val patches = ArrayList<LegacyPatchSpec>()
        val failed = ArrayList<String>()
        val warnings = ArrayList<String>()

        for (cand in candidates) {
            val file = cand.cachedFile
            if (!file.exists() || file.length() == 0L) {
                failed.add("${cand.relativePath}: empty file")
                continue
            }
            when (detectFileFormat(file, cand.name)) {
                FormatType.SQLITE -> {
                    formats.add("SQLite Database")
                    parseSqliteDatabase(file, cand.relativePath, patches, failed, warnings)
                }
                FormatType.JSON -> {
                    formats.add("JSON")
                    parseJsonFile(file, cand.relativePath, patches, failed, warnings)
                }
                FormatType.XML -> {
                    formats.add("XML")
                    parseXmlFile(file, cand.relativePath, patches, failed, warnings)
                }
                FormatType.INI_TEXT -> {
                    formats.add("Text/INI Config")
                    parseIniOrTextFile(file, cand.relativePath, patches, failed, warnings)
                }
                FormatType.UNSUPPORTED_BINARY -> {
                    formats.add("Unknown Binary")
                    failed.add("${cand.relativePath}: unrecognized binary format (cannot safely guess structure)")
                }
            }
        }

        return LegacyPatchInspectionResult(
            detectedFormats = formats,
            parsedPatches = patches,
            failedFiles = failed,
            warnings = warnings
        )
    }

    private enum class FormatType { JSON, XML, SQLITE, INI_TEXT, UNSUPPORTED_BINARY }

    private fun detectFileFormat(file: File, filename: String): FormatType {
        val header = ByteArray(32)
        val readCount = runCatching {
            file.inputStream().use { it.read(header) }
        }.getOrDefault(0)
        if (readCount <= 0) return FormatType.UNSUPPORTED_BINARY

        // SQLite 3 magic header: "SQLite format 3\u0000"
        val headStr = String(header, 0, minOf(readCount, 15), Charsets.US_ASCII)
        if (headStr == "SQLite format 3") {
            return FormatType.SQLITE
        }

        // Check if text-readable
        val sampleText = runCatching {
            file.bufferedReader().use { r ->
                val buf = CharArray(512)
                val n = r.read(buf)
                if (n > 0) String(buf, 0, n).trimStart() else ""
            }
        }.getOrDefault("")

        if (sampleText.startsWith("{") || sampleText.startsWith("[")) return FormatType.JSON
        if (sampleText.startsWith("<")) return FormatType.XML

        val ext = filename.substringAfterLast('.', "").lowercase()
        val printableRatio = sampleText.count { it == '\n' || it == '\r' || it == '\t' || it.code in 32..126 }
            .toFloat() / sampleText.length.coerceAtLeast(1)
        if (printableRatio > 0.85f && ext in setOf("cfg", "ini", "txt", "patch", "kit")) {
            return FormatType.INI_TEXT
        }

        return FormatType.UNSUPPORTED_BINARY
    }

    private fun parseJsonFile(
        file: File,
        sourcePath: String,
        outPatches: MutableList<LegacyPatchSpec>,
        failed: MutableList<String>,
        warnings: MutableList<String>
    ) {
        try {
            val text = file.readText().trim()
            if (text.startsWith("[")) {
                val arr = JSONArray(text)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    parseJsonPatchObject(obj, sourcePath, i + 1)?.let { outPatches.add(it) }
                }
            } else {
                val root = JSONObject(text)
                val patchesArr = root.optJSONArray("patches")
                    ?: root.optJSONArray("kits")
                    ?: root.optJSONArray("data")
                if (patchesArr != null) {
                    for (i in 0 until patchesArr.length()) {
                        val obj = patchesArr.optJSONObject(i) ?: continue
                        parseJsonPatchObject(obj, sourcePath, i + 1)?.let { outPatches.add(it) }
                    }
                } else {
                    // Single patch JSON
                    val single = parseJsonPatchObject(root, sourcePath, 1)
                    if (single != null) {
                        outPatches.add(single)
                    } else {
                        warnings.add("$sourcePath: JSON parsed but no patch/pad keys found")
                    }
                }
            }
        } catch (t: Throwable) {
            failed.add("$sourcePath: JSON parse error (${t.message})")
        }
    }

    private fun parseJsonPatchObject(obj: JSONObject, sourcePath: String, fallbackNum: Int): LegacyPatchSpec? {
        val rawName = obj.optString("name", "")
            .ifBlank { obj.optString("patchName", "") }
            .ifBlank { obj.optString("title", "") }
            .ifBlank { obj.optString("kitName", "") }
        val bankStr = obj.optString("bank", "A")
        val bank = Bank.fromCode(bankStr)
        val num = when {
            obj.has("patchNumber") -> obj.optInt("patchNumber", fallbackNum)
            obj.has("number") -> obj.optInt("number", fallbackNum)
            obj.has("id") && obj.optInt("id", 0) in 1..100 -> obj.optInt("id", fallbackNum)
            else -> fallbackNum
        }.coerceIn(1, 100)

        val padsArray = obj.optJSONArray("pads")
            ?: obj.optJSONArray("padAssignments")
            ?: obj.optJSONArray("samples")
            ?: obj.optJSONArray("channels")

        val padSpecs = ArrayList<LegacyPadSpec>(8)
        if (padsArray != null) {
            for (i in 0 until minOf(8, padsArray.length())) {
                val item = padsArray.opt(i)
                if (item is JSONObject) {
                    val padIndex = item.optInt("padIndex", item.optInt("pad", i + 1)).coerceIn(1, 8)
                    val sampleRef = item.optString("sampleRef", "")
                        .ifBlank { item.optString("sample", "") }
                        .ifBlank { item.optString("sampleName", "") }
                        .ifBlank { item.optString("originalFilename", "") }
                        .ifBlank { item.optString("file", "") }
                        .ifBlank { item.optString("path", "") }
                        .ifBlank { item.optString("audio", "") }
                        .ifBlank { null }
                    val vol = readNormalizedVolume(item.optDouble("volume", item.optDouble("vol", 0.85)))
                    val pitch = item.optDouble("pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f)
                    val pan = item.optDouble("pan", 0.0).toFloat().coerceIn(-1.0f, 1.0f)
                    val enabled = item.optBoolean("enabled", item.optBoolean("active", true))
                    padSpecs.add(LegacyPadSpec(padIndex, sampleRef, vol, pitch, pan, enabled))
                } else if (item is String) {
                    padSpecs.add(LegacyPadSpec(i + 1, item.ifBlank { null }))
                }
            }
        } else {
            // Check pad1..pad8 flat keys
            var foundFlat = false
            for (p in 1..8) {
                val ref = obj.optString("pad$p", "").ifBlank { obj.optString("pad_${p}_sample", "") }
                if (ref.isNotBlank()) foundFlat = true
                val vol = readNormalizedVolume(obj.optDouble("pad${p}_vol", obj.optDouble("vol$p", 0.85)))
                val pitch = obj.optDouble("pad${p}_pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f)
                val pan = obj.optDouble("pad${p}_pan", 0.0).toFloat().coerceIn(-1.0f, 1.0f)
                padSpecs.add(LegacyPadSpec(p, ref.ifBlank { null }, vol, pitch, pan, true))
            }
            if (!foundFlat && rawName.isBlank()) return null
        }

        if (padSpecs.isEmpty() && rawName.isBlank()) return null

        val padded = (1..8).map { idx ->
            padSpecs.firstOrNull { it.padIndex == idx } ?: LegacyPadSpec(idx, null)
        }
        return LegacyPatchSpec(
            sourceFile = sourcePath,
            detectedFormat = "JSON",
            bank = bank,
            patchNumber = num,
            patchName = rawName.ifBlank { "Imported Patch $num" },
            isFavorite = obj.optBoolean("isFavorite", obj.optBoolean("favorite", false)),
            pads = padded
        )
    }

    private fun parseSqliteDatabase(
        file: File,
        sourcePath: String,
        outPatches: MutableList<LegacyPatchSpec>,
        failed: MutableList<String>,
        warnings: MutableList<String>
    ) {
        var db: SQLiteDatabase? = null
        try {
            db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
            val tables = ArrayList<String>()
            db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' AND name NOT LIKE 'android_%'", null).use { c ->
                while (c.moveToNext()) {
                    tables.add(c.getString(0))
                }
            }
            if (tables.isEmpty()) {
                failed.add("$sourcePath: SQLite database contains no user tables")
                return
            }

            val patchTable = tables.firstOrNull { it.contains("patch", true) || it.contains("kit", true) }
            val padTable = tables.firstOrNull { it.contains("pad", true) || it.contains("assign", true) || it.contains("channel", true) }

            if (patchTable == null && padTable == null) {
                failed.add("$sourcePath: SQLite schema (${tables.joinToString()}) has no recognizable patch/pad tables")
                return
            }

            val patchCols = patchTable?.let { getTableColumns(db, it) } ?: emptySet()
            val padCols = padTable?.let { getTableColumns(db, it) } ?: emptySet()

            if (patchTable != null) {
                val patchesMap = LinkedHashMap<String, LegacyPatchSpec>()
                db.rawQuery("SELECT * FROM \"$patchTable\"", null).use { c ->
                    val nameCol = findCol(patchCols, "name", "patch_name", "patchname", "title", "kit_name")
                    val numCol = findCol(patchCols, "patch_number", "patchnumber", "number", "patch_no", "id")
                    val bankCol = findCol(patchCols, "bank", "bank_id", "bankname")
                    val keyCol = findCol(patchCols, "patch_key", "patchkey", "id")
                    val favCol = findCol(patchCols, "is_favorite", "isfavorite", "favorite")

                    var rowIdx = 1
                    while (c.moveToNext()) {
                        val name = nameCol?.let { getStringSafe(c, it) } ?: "Legacy Patch $rowIdx"
                        val num = (numCol?.let { getIntSafe(c, it) } ?: rowIdx).coerceIn(1, 100)
                        val bank = Bank.fromCode(bankCol?.let { getStringSafe(c, it) } ?: "A")
                        val fav = favCol?.let { getIntSafe(c, it) == 1 } ?: false
                        val key = keyCol?.let { getStringSafe(c, it) } ?: "${bank.code}_$num"

                        // Check if pads are inline columns (pad1..pad8)
                        val inlinePads = (1..8).map { p ->
                            val sCol = findCol(patchCols, "pad$p", "pad_${p}_sample", "sample$p", "sound$p")
                            val vCol = findCol(patchCols, "pad${p}_vol", "vol$p", "volume$p")
                            LegacyPadSpec(
                                padIndex = p,
                                sampleRef = sCol?.let { getStringSafe(c, it) },
                                volume = vCol?.let { readNormalizedVolume(getDoubleSafe(c, it)) } ?: 0.85f
                            )
                        }
                        patchesMap[key] = LegacyPatchSpec(
                            sourceFile = sourcePath,
                            detectedFormat = "SQLite ($patchTable)",
                            bank = bank,
                            patchNumber = num,
                            patchName = name,
                            isFavorite = fav,
                            pads = inlinePads
                        )
                        rowIdx++
                    }
                }

                if (padTable != null) {
                    val fkCol = findCol(padCols, "patch_key", "patchkey", "patch_id", "patchid", "kit_id")
                    val idxCol = findCol(padCols, "pad_index", "padindex", "pad", "pad_no", "channel")
                    val sampleCol = findCol(padCols, "sample_id", "sampleid", "sample", "sample_name", "sample_path", "file", "filename", "sound")
                    val volCol = findCol(padCols, "volume", "vol", "level")
                    val pitchCol = findCol(padCols, "pitch", "tune")
                    val panCol = findCol(padCols, "pan")
                    val enabledCol = findCol(padCols, "enabled", "active")

                    val padsByPatch = HashMap<String, MutableList<LegacyPadSpec>>()
                    db.rawQuery("SELECT * FROM \"$padTable\"", null).use { c ->
                        while (c.moveToNext()) {
                            val fk = fkCol?.let { getStringSafe(c, it) } ?: continue
                            val padIdx = (idxCol?.let { getIntSafe(c, it) } ?: 1).coerceIn(1, 8)
                            val spec = LegacyPadSpec(
                                padIndex = padIdx,
                                sampleRef = sampleCol?.let { getStringSafe(c, it) },
                                volume = volCol?.let { readNormalizedVolume(getDoubleSafe(c, it)) } ?: 0.85f,
                                pitch = pitchCol?.let { getDoubleSafe(c, it).toFloat().coerceIn(0.5f, 2.0f) } ?: 1.0f,
                                pan = panCol?.let { getDoubleSafe(c, it).toFloat().coerceIn(-1.0f, 1.0f) } ?: 0.0f,
                                enabled = enabledCol?.let { getIntSafe(c, it) != 0 } ?: true
                            )
                            padsByPatch.getOrPut(fk) { mutableListOf() }.add(spec)
                        }
                    }

                    for ((key, patch) in patchesMap) {
                        val linkedPads = padsByPatch[key]
                        if (!linkedPads.isNullOrEmpty()) {
                            val full = (1..8).map { idx ->
                                linkedPads.firstOrNull { it.padIndex == idx } ?: LegacyPadSpec(idx, null)
                            }
                            outPatches.add(patch.copy(pads = full))
                        } else {
                            outPatches.add(patch)
                        }
                    }
                } else {
                    outPatches.addAll(patchesMap.values)
                }
            } else {
                warnings.add("$sourcePath: Found $padTable without patch metadata table")
            }
        } catch (t: Throwable) {
            failed.add("$sourcePath: SQLite error (${t.message})")
        } finally {
            runCatching { db?.close() }
        }
    }

    private fun parseXmlFile(
        file: File,
        sourcePath: String,
        outPatches: MutableList<LegacyPatchSpec>,
        failed: MutableList<String>,
        warnings: MutableList<String>
    ) {
        try {
            val content = file.readText()
            val parser = Xml.newPullParser()
            parser.setInput(StringReader(content))

            var currentPatchName: String? = null
            var currentBank = Bank.A
            var currentNum = 1
            var currentPads = mutableListOf<LegacyPadSpec>()
            var patchCounter = 0

            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG) {
                    val tag = parser.name.lowercase()
                    if (tag == "patch" || tag == "kit") {
                        patchCounter++
                        currentPatchName = parser.getAttributeValue(null, "name")
                            ?: parser.getAttributeValue(null, "title")
                            ?: "XML Patch $patchCounter"
                        currentBank = Bank.fromCode(parser.getAttributeValue(null, "bank") ?: "A")
                        currentNum = (parser.getAttributeValue(null, "number")?.toIntOrNull()
                            ?: parser.getAttributeValue(null, "id")?.toIntOrNull()
                            ?: patchCounter).coerceIn(1, 100)
                        currentPads = mutableListOf()
                    } else if (tag == "pad" || tag == "channel") {
                        val idx = (parser.getAttributeValue(null, "index")?.toIntOrNull()
                            ?: parser.getAttributeValue(null, "id")?.toIntOrNull()
                            ?: (currentPads.size + 1)).coerceIn(1, 8)
                        val sample = parser.getAttributeValue(null, "sample")
                            ?: parser.getAttributeValue(null, "file")
                            ?: parser.getAttributeValue(null, "src")
                        val vol = readNormalizedVolume(
                            parser.getAttributeValue(null, "volume")?.toDoubleOrNull() ?: 0.85
                        )
                        val pitch = (parser.getAttributeValue(null, "pitch")?.toFloatOrNull() ?: 1.0f).coerceIn(0.5f, 2.0f)
                        val pan = (parser.getAttributeValue(null, "pan")?.toFloatOrNull() ?: 0.0f).coerceIn(-1.0f, 1.0f)
                        val enabled = parser.getAttributeValue(null, "enabled")?.toBooleanStrictOrNull() ?: true
                        currentPads.add(LegacyPadSpec(idx, sample?.ifBlank { null }, vol, pitch, pan, enabled))
                    }
                } else if (event == XmlPullParser.END_TAG) {
                    val tag = parser.name.lowercase()
                    if ((tag == "patch" || tag == "kit") && currentPatchName != null) {
                        val full = (1..8).map { idx ->
                            currentPads.firstOrNull { it.padIndex == idx } ?: LegacyPadSpec(idx, null)
                        }
                        outPatches.add(
                            LegacyPatchSpec(
                                sourceFile = sourcePath,
                                detectedFormat = "XML",
                                bank = currentBank,
                                patchNumber = currentNum,
                                patchName = currentPatchName,
                                pads = full
                            )
                        )
                        currentPatchName = null
                    }
                }
                event = parser.next()
            }

            if (patchCounter == 0 && currentPads.isNotEmpty()) {
                val full = (1..8).map { idx ->
                    currentPads.firstOrNull { it.padIndex == idx } ?: LegacyPadSpec(idx, null)
                }
                outPatches.add(
                    LegacyPatchSpec(
                        sourceFile = sourcePath,
                        detectedFormat = "XML",
                        bank = Bank.A,
                        patchNumber = 1,
                        patchName = file.nameWithoutExtension,
                        pads = full
                    )
                )
            } else if (patchCounter == 0) {
                warnings.add("$sourcePath: XML contained no <patch> or <pad> tags")
            }
        } catch (t: Throwable) {
            failed.add("$sourcePath: XML parse error (${t.message})")
        }
    }

    private fun parseIniOrTextFile(
        file: File,
        sourcePath: String,
        outPatches: MutableList<LegacyPatchSpec>,
        failed: MutableList<String>,
        warnings: MutableList<String>
    ) {
        try {
            val map = HashMap<String, String>()
            file.forEachLine { line ->
                val trimmed = line.trim()
                if (trimmed.isNotEmpty() && !trimmed.startsWith("#") && !trimmed.startsWith(";") && !trimmed.startsWith("[")) {
                    val eqIdx = trimmed.indexOf('=')
                    val colonIdx = trimmed.indexOf(':')
                    val sep = when {
                        eqIdx > 0 -> eqIdx
                        colonIdx > 0 -> colonIdx
                        else -> -1
                    }
                    if (sep > 0) {
                        val k = trimmed.substring(0, sep).trim().lowercase()
                        val v = trimmed.substring(sep + 1).trim()
                        map[k] = v
                    }
                }
            }
            if (map.isEmpty()) {
                warnings.add("$sourcePath: No key=value patch parameters found")
                return
            }

            val name = map["name"] ?: map["patchname"] ?: map["patch_name"] ?: file.nameWithoutExtension
            val bank = Bank.fromCode(map["bank"] ?: "A")
            val number = (map["number"] ?: map["patchnumber"] ?: map["patch_number"] ?: "1").toIntOrNull()?.coerceIn(1, 100) ?: 1

            var anyPadFound = false
            val pads = (1..8).map { p ->
                val sampleRef = map["pad$p"] ?: map["pad_${p}_sample"] ?: map["sample$p"] ?: map["sound$p"]
                if (!sampleRef.isNullOrBlank()) anyPadFound = true
                val vol = readNormalizedVolume((map["pad${p}_vol"] ?: map["vol$p"] ?: map["volume$p"])?.toDoubleOrNull() ?: 0.85)
                val pitch = (map["pad${p}_pitch"] ?: map["pitch$p"])?.toFloatOrNull()?.coerceIn(0.5f, 2.0f) ?: 1.0f
                val pan = (map["pad${p}_pan"] ?: map["pan$p"])?.toFloatOrNull()?.coerceIn(-1.0f, 1.0f) ?: 0.0f
                LegacyPadSpec(p, sampleRef?.ifBlank { null }, vol, pitch, pan, true)
            }
            if (!anyPadFound && map["name"] == null && map["patchname"] == null) {
                warnings.add("$sourcePath: Text file did not match Mobile Octapad patch keys")
                return
            }
            outPatches.add(
                LegacyPatchSpec(
                    sourceFile = sourcePath,
                    detectedFormat = "Text/INI Config",
                    bank = bank,
                    patchNumber = number,
                    patchName = name,
                    pads = pads
                )
            )
        } catch (t: Throwable) {
            failed.add("$sourcePath: Config parse error (${t.message})")
        }
    }

    private fun readNormalizedVolume(raw: Double): Float {
        if (raw.isNaN()) return 0.85f
        return when {
            raw > 1.0 && raw <= 100.0 -> (raw / 100.0).toFloat()
            raw > 100.0 && raw <= 127.0 -> (raw / 127.0).toFloat()
            else -> raw.toFloat()
        }.coerceIn(0f, 1f)
    }

    private fun getTableColumns(db: SQLiteDatabase, table: String): Set<String> {
        val cols = HashSet<String>()
        db.rawQuery("PRAGMA table_info(\"$table\")", null).use { c ->
            val nameIdx = c.getColumnIndex("name")
            while (c.moveToNext()) {
                if (nameIdx >= 0) cols.add(c.getString(nameIdx))
            }
        }
        return cols
    }

    private fun findCol(cols: Set<String>, vararg candidates: String): String? {
        for (cand in candidates) {
            cols.firstOrNull { it.equals(cand, ignoreCase = true) }?.let { return it }
        }
        return null
    }

    private fun getStringSafe(c: android.database.Cursor, colName: String): String? {
        val idx = c.getColumnIndex(colName)
        return if (idx >= 0 && !c.isNull(idx)) c.getString(idx) else null
    }

    private fun getIntSafe(c: android.database.Cursor, colName: String): Int? {
        val idx = c.getColumnIndex(colName)
        return if (idx >= 0 && !c.isNull(idx)) c.getInt(idx) else null
    }

    private fun getDoubleSafe(c: android.database.Cursor, colName: String): Double {
        val idx = c.getColumnIndex(colName)
        return if (idx >= 0 && !c.isNull(idx)) c.getDouble(idx) else 0.85
    }
}
