package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PatchEntity::class,
        PadAssignmentEntity::class,
        SampleEntity::class,
        AppSettingsEntity::class,
        MidiMappingEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PatchDatabase : RoomDatabase() {
    abstract fun patchDao(): PatchDao

    companion object {
        @Volatile
        private var INSTANCE: PatchDatabase? = null

        fun getInstance(context: Context): PatchDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    PatchDatabase::class.java,
                    "octapad20pro.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
