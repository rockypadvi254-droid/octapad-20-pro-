package com.example.data

import com.example.audio.FactorySampleGenerator
import com.example.data.db.AppSettingsEntity
import com.example.data.db.MidiMappingEntity
import com.example.data.db.PadAssignmentEntity
import com.example.data.db.PatchDao
import com.example.data.db.PatchEntity
import com.example.data.db.SampleEntity
import com.example.midi.MidiManager
import com.example.samples.SampleRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class PatchRepository(
    private val dao: PatchDao,
    private val sampleRegistry: SampleRegistry
) {
    val allSamplesFlow: Flow<List<SampleEntity>> = sampleRegistry.samplesFlow

    val settingsFlow: Flow<AppSettingsEntity> = dao.observeSettings().map { it ?: AppSettingsEntity() }

    val favoritePatchesFlow: Flow<List<PatchSummary>> = dao.observeFavoritePatches().map { list ->
        list.map { it.toSummary() }
    }

    val midiMappingsFlow: Flow<List<MidiPadMapping>> = dao.observeMidiMappings().map { list ->
        if (list.isEmpty()) MidiManager.defaultMappings()
        else list.map { MidiPadMapping(it.padIndex, it.midiNote, it.channel) }
    }

    fun observePatchesForBank(bank: Bank): Flow<List<PatchSummary>> {
        return dao.observePatchesByBank(bank.code).map { list ->
            list.map { it.toSummary() }
        }
    }

    fun observePatch(patchKey: String): Flow<PatchEntity?> = dao.observePatch(patchKey)

    fun observePadAssignments(patchKey: String): Flow<List<PadAssignmentEntity>> =
        dao.observePadAssignments(patchKey)

    suspend fun initializeDatabaseIfNeeded() = withContext(Dispatchers.IO) {
        sampleRegistry.initializeAndVerifyRegistry()

        if (dao.getPatchCount() == 0) {
            val (defaultPatches, defaultPads) = FactorySampleGenerator.generateDefault200Patches()
            dao.insertPatchesIgnore(defaultPatches)
            dao.insertPadAssignmentsIgnore(defaultPads)
        }
        if (dao.getSettingsSync() == null) {
            dao.upsertSettings(AppSettingsEntity())
        }
        if (dao.getMidiMappingsSync().isEmpty()) {
            dao.upsertMidiMappings(
                MidiManager.defaultMappings().map {
                    MidiMappingEntity(it.padIndex, it.midiNote, it.channel)
                }
            )
        }
    }

    suspend fun getPadAssignments(patchKey: String): List<PadAssignmentEntity> = withContext(Dispatchers.IO) {
        dao.getPadAssignmentsSync(patchKey)
    }

    suspend fun getPatch(patchKey: String): PatchEntity? = withContext(Dispatchers.IO) {
        dao.getPatchSync(patchKey)
    }

    suspend fun savePatch(
        bank: Bank,
        patchNumber: Int,
        name: String,
        isFavorite: Boolean,
        pads: List<PadAssignmentEntity>
    ) = withContext(Dispatchers.IO) {
        val key = formatPatchKey(bank, patchNumber)
        val patch = PatchEntity(
            patchKey = key,
            bank = bank.code,
            patchNumber = patchNumber,
            name = name.ifBlank { "Patch $patchNumber" },
            isFavorite = isFavorite,
            updatedAt = System.currentTimeMillis()
        )
        dao.savePatchWithPads(patch, pads.map { it.copy(patchKey = key) })
    }

    suspend fun copyPatch(
        sourceBank: Bank,
        sourceNumber: Int,
        targetBank: Bank,
        targetNumber: Int,
        targetName: String? = null
    ) = withContext(Dispatchers.IO) {
        val srcKey = formatPatchKey(sourceBank, sourceNumber)
        val dstKey = formatPatchKey(targetBank, targetNumber)
        dao.copyPatch(srcKey, dstKey, targetBank.code, targetNumber, targetName)
    }

    suspend fun clearPatch(bank: Bank, patchNumber: Int) = withContext(Dispatchers.IO) {
        val key = formatPatchKey(bank, patchNumber)
        dao.clearPatch(key, bank.code, patchNumber)
    }

    suspend fun toggleFavorite(bank: Bank, patchNumber: Int) = withContext(Dispatchers.IO) {
        val key = formatPatchKey(bank, patchNumber)
        val current = dao.getPatchSync(key) ?: return@withContext
        dao.setFavorite(key, !current.isFavorite)
    }

    suspend fun updateMasterVolume(volume: Float) = withContext(Dispatchers.IO) {
        val current = dao.getSettingsSync() ?: AppSettingsEntity()
        dao.upsertSettings(current.copy(masterVolume = volume.coerceIn(0f, 1f)))
    }

    suspend fun updateSelectedBankAndPatch(bank: Bank, patchNumber: Int) = withContext(Dispatchers.IO) {
        val current = dao.getSettingsSync() ?: AppSettingsEntity()
        val updated = if (bank == Bank.A) {
            current.copy(selectedBank = bank.code, lastPatchNumberA = patchNumber.coerceIn(1, 100))
        } else {
            current.copy(selectedBank = bank.code, lastPatchNumberB = patchNumber.coerceIn(1, 100))
        }
        dao.upsertSettings(updated)
    }

    suspend fun updatePadVolume(bank: Bank, patchNumber: Int, padIndex: Int, volume: Float) = withContext(Dispatchers.IO) {
        val key = formatPatchKey(bank, patchNumber)
        dao.updatePadVolume(key, padIndex, volume.coerceIn(0f, 1f))
    }

    suspend fun saveAudioFx(fx: AudioFxState) = withContext(Dispatchers.IO) {
        val current = dao.getSettingsSync() ?: AppSettingsEntity()
        dao.upsertSettings(
            current.copy(
                reverbEnabled = fx.reverbEnabled,
                reverbMix = fx.reverbMix.coerceIn(0f, 1f),
                delayEnabled = fx.delayEnabled,
                delayTimeMs = fx.delayTimeMs.coerceIn(60, 800),
                delayFeedback = fx.delayFeedback.coerceIn(0.05f, 0.72f),
                eqEnabled = fx.eqEnabled,
                bassGainDb = fx.bassGainDb.coerceIn(-12f, 12f),
                midGainDb = fx.midGainDb.coerceIn(-12f, 12f),
                trebleGainDb = fx.trebleGainDb.coerceIn(-12f, 12f)
            )
        )
    }

    suspend fun saveMidiMappings(mappings: List<MidiPadMapping>) = withContext(Dispatchers.IO) {
        dao.upsertMidiMappings(mappings.map { MidiMappingEntity(it.padIndex, it.midiNote, it.channel) })
    }

    suspend fun relinkMissingPadSample(
        bank: Bank,
        patchNumber: Int,
        padIndex: Int,
        newSampleId: String
    ) = withContext(Dispatchers.IO) {
        val key = formatPatchKey(bank, patchNumber)
        val pads = dao.getPadAssignmentsSync(key).toMutableList()
        val idx = pads.indexOfFirst { it.padIndex == padIndex }
        if (idx >= 0) {
            pads[idx] = pads[idx].copy(sampleId = newSampleId, missingSampleName = null)
            dao.upsertPadAssignments(pads)
        }
    }

    private fun PatchEntity.toSummary() = PatchSummary(
        patchKey = patchKey,
        bank = Bank.fromCode(bank),
        patchNumber = patchNumber,
        name = name,
        isFavorite = isFavorite
    )
}
