package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.AudioEngine
import com.example.audio.AudioEngineStatus
import com.example.data.AudioFxState
import com.example.data.BackupOperationReport
import com.example.data.Bank
import com.example.data.LegacyMigrationReport
import com.example.data.MidiPadMapping
import com.example.data.MidiStatus
import com.example.data.PadUiModel
import com.example.data.PatchRepository
import com.example.data.PatchSummary
import com.example.data.SampleLoadingStatus
import com.example.data.db.PadAssignmentEntity
import com.example.data.db.PatchDatabase
import com.example.data.db.SampleEntity
import com.example.data.formatPatchKey
import com.example.io.BackupManager
import com.example.legacy.LegacyDataMigration
import com.example.legacy.LegacyPatchImporter
import com.example.legacy.LegacySampleManager
import com.example.legacy.LegacySampleRegistry
import com.example.midi.MidiManager
import com.example.samples.SampleImportResult
import com.example.samples.SampleImporter
import com.example.samples.SampleRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

data class MainOctapadState(
    val isReady: Boolean = false,
    val selectedBank: Bank = Bank.A,
    val selectedPatchNumber: Int = 1,
    val currentPatchName: String = "Salpuri",
    val isCurrentFavorite: Boolean = false,
    val masterVolume: Float = 0.85f,
    val pads: List<PadUiModel> = (1..8).map { PadUiModel(it, null, "Loading...") },
    val statusBanner: String? = null
)

@OptIn(ExperimentalCoroutinesApi::class)
class PatchViewModel(application: Application) : AndroidViewModel(application) {

    private val database = PatchDatabase.getInstance(application)
    private val dao = database.patchDao()
    private val sampleRegistry = SampleRegistry(application, dao)
    private val repository = PatchRepository(dao, sampleRegistry)
    val audioEngine = AudioEngine(application)
    private val sampleImporter = SampleImporter(application, sampleRegistry)
    private val legacySampleRegistry = LegacySampleRegistry(sampleRegistry)
    private val legacySampleManager = LegacySampleManager(application, sampleRegistry, legacySampleRegistry)
    private val legacyPatchImporter = LegacyPatchImporter()
    val legacyDataMigration = LegacyDataMigration(dao, legacySampleManager, legacyPatchImporter, legacySampleRegistry)
    val backupManager = BackupManager(application, dao, sampleRegistry, legacyDataMigration)

    val midiManager = MidiManager(application) { padIndex, velocity ->
        triggerPadHit(padIndex, velocity)
    }

    // Per-pad hit timestamps to trigger glow without recomposing entire screen
    val padHitSignals: Array<MutableStateFlow<Long>> = Array(8) { MutableStateFlow(0L) }

    private val _selectedBank = MutableStateFlow(Bank.A)
    private val _selectedPatchNumber = MutableStateFlow(1)
    private val _isInitialized = MutableStateFlow(false)
    private val _statusBanner = MutableStateFlow<String?>(null)

    private val _migrationReport = MutableStateFlow<LegacyMigrationReport?>(null)
    val migrationReport: StateFlow<LegacyMigrationReport?> = _migrationReport.asStateFlow()

    private val _backupReport = MutableStateFlow<BackupOperationReport?>(null)
    val backupReport: StateFlow<BackupOperationReport?> = _backupReport.asStateFlow()

    private val _isBusy = MutableStateFlow(false)
    val isBusy: StateFlow<Boolean> = _isBusy.asStateFlow()

    val audioEngineStatus: StateFlow<AudioEngineStatus> = audioEngine.status
    val midiStatus: StateFlow<MidiStatus> = midiManager.midiStatus
    val allSamples: StateFlow<List<SampleEntity>> = repository.allSamplesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val favoritePatches: StateFlow<List<PatchSummary>> = repository.favoritePatchesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val midiMappings: StateFlow<List<MidiPadMapping>> = repository.midiMappingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MidiManager.defaultMappings())

    val bankPatches: StateFlow<List<PatchSummary>> = _selectedBank
        .flatMapLatest { bank -> repository.observePatchesForBank(bank) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fxState: StateFlow<AudioFxState> = repository.settingsFlow
        .map {
            AudioFxState(
                reverbEnabled = it.reverbEnabled,
                reverbMix = it.reverbMix,
                delayEnabled = it.delayEnabled,
                delayTimeMs = it.delayTimeMs,
                delayFeedback = it.delayFeedback,
                eqEnabled = it.eqEnabled,
                bassGainDb = it.bassGainDb,
                midGainDb = it.midGainDb,
                trebleGainDb = it.trebleGainDb
            )
        }
        .distinctUntilChanged()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AudioFxState())

    private val activePatchKeyFlow = combine(_selectedBank, _selectedPatchNumber) { bank, num ->
        formatPatchKey(bank, num)
    }

    private val activePatchEntityFlow = activePatchKeyFlow.flatMapLatest { key ->
        repository.observePatch(key)
    }

    private val activePadEntitiesFlow = activePatchKeyFlow.flatMapLatest { key ->
        repository.observePadAssignments(key)
    }

    val uiState: StateFlow<MainOctapadState> = combine(
        _isInitialized,
        _selectedBank,
        _selectedPatchNumber,
        activePatchEntityFlow,
        activePadEntitiesFlow,
        allSamples,
        audioEngine.sampleStatuses,
        audioEngine.sampleErrors,
        repository.settingsFlow,
        _statusBanner
    ) { values ->
        val ready = values[0] as Boolean
        val bank = values[1] as Bank
        val patchNum = values[2] as Int
        val patchEntity = values[3] as? com.example.data.db.PatchEntity
        @Suppress("UNCHECKED_CAST")
        val padEntities = values[4] as List<PadAssignmentEntity>
        @Suppress("UNCHECKED_CAST")
        val samples = values[5] as List<SampleEntity>
        @Suppress("UNCHECKED_CAST")
        val engineStatuses = values[6] as Map<String, SampleLoadingStatus>
        @Suppress("UNCHECKED_CAST")
        val engineErrors = values[7] as Map<String, String>
        val settings = values[8] as com.example.data.db.AppSettingsEntity
        val banner = values[9] as String?

        val sampleMap = samples.associateBy { it.sampleId }
        val padModels = (1..8).map { idx ->
            val entity = padEntities.firstOrNull { it.padIndex == idx }
            val sid = entity?.sampleId
            val sample = sid?.let { sampleMap[it] }
            val missingName = entity?.missingSampleName
            val status = when {
                missingName != null -> SampleLoadingStatus.MISSING
                sid == null -> SampleLoadingStatus.UNLOADED
                sample == null || !File(sample.storedPath).exists() -> SampleLoadingStatus.MISSING
                !sample.decodingVerified -> SampleLoadingStatus.ERROR
                else -> engineStatuses[sid] ?: SampleLoadingStatus.LOADING
            }
            val label = when {
                missingName != null -> "MISSING: $missingName"
                sample != null -> sample.displayName
                sid != null -> "MISSING: $sid"
                else -> "EMPTY"
            }
            val err = when {
                missingName != null -> "Missing sample '$missingName' — tap relink"
                sample != null && !sample.decodingVerified -> sample.errorMessage ?: "Audio decode failed"
                sid != null -> engineErrors[sid]
                else -> null
            }
            PadUiModel(
                padIndex = idx,
                sampleId = sid,
                sampleName = label,
                missingSampleName = missingName,
                sampleStatus = status,
                sampleError = err,
                volume = entity?.volume ?: 0.85f,
                pitch = entity?.pitch ?: 1.0f,
                pan = entity?.pan ?: 0.0f,
                enabled = entity?.enabled ?: true
            )
        }

        MainOctapadState(
            isReady = ready,
            selectedBank = bank,
            selectedPatchNumber = patchNum,
            currentPatchName = patchEntity?.name ?: "Patch $patchNum",
            isCurrentFavorite = patchEntity?.isFavorite ?: false,
            masterVolume = settings.masterVolume,
            pads = padModels,
            statusBanner = banner
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), MainOctapadState())

    private var savedPatchA = 1
    private var savedPatchB = 1

    init {
        audioEngine.initializeAudio()
        midiManager.startListening()

        viewModelScope.launch(Dispatchers.IO) {
            repository.initializeDatabaseIfNeeded()
            val settings = dao.getSettingsSync()
            if (settings != null) {
                savedPatchA = settings.lastPatchNumberA.coerceIn(1, 100)
                savedPatchB = settings.lastPatchNumberB.coerceIn(1, 100)
                val initialBank = Bank.fromCode(settings.selectedBank)
                _selectedBank.value = initialBank
                _selectedPatchNumber.value = if (initialBank == Bank.A) savedPatchA else savedPatchB
                audioEngine.setMasterVolume(settings.masterVolume)
            }
            _isInitialized.value = true
            preloadActivePatch()
        }

        // Sync MIDI mappings dynamically
        viewModelScope.launch {
            midiMappings.collect { midiManager.updateMappings(it) }
        }

        // Preload samples automatically whenever active patch pads or FX change
        viewModelScope.launch(Dispatchers.IO) {
            combine(uiState.map { it.pads }.distinctUntilChanged(), fxState) { pads, fx ->
                pads to fx
            }.collect { (pads, fx) ->
                if (_isInitialized.value) {
                    val files = sampleRegistry.buildSampleFileMap()
                    audioEngine.preloadSamples(pads, files, fx)
                }
            }
        }
    }

    private suspend fun preloadActivePatch() {
        val state = uiState.value
        val files = sampleRegistry.buildSampleFileMap()
        audioEngine.preloadSamples(state.pads, files, fxState.value)
    }

    /**
     * Zero-DB, zero-allocation hot pad hit path.
     */
    fun triggerPadHit(padIndex: Int, velocity: Float = 1.0f) {
        if (padIndex !in 1..8) return
        audioEngine.playPad(padIndex, velocity)
        padHitSignals[padIndex - 1].value = System.nanoTime()
    }

    fun selectBank(bank: Bank) {
        if (_selectedBank.value == bank) return
        if (_selectedBank.value == Bank.A) {
            savedPatchA = _selectedPatchNumber.value
        } else {
            savedPatchB = _selectedPatchNumber.value
        }
        val nextNum = if (bank == Bank.A) savedPatchA else savedPatchB
        _selectedBank.value = bank
        _selectedPatchNumber.value = nextNum
        viewModelScope.launch {
            repository.updateSelectedBankAndPatch(bank, nextNum)
        }
    }

    fun selectPatch(patchNumber: Int) {
        val clamped = patchNumber.coerceIn(1, 100)
        _selectedPatchNumber.value = clamped
        val bank = _selectedBank.value
        if (bank == Bank.A) savedPatchA = clamped else savedPatchB = clamped
        viewModelScope.launch {
            repository.updateSelectedBankAndPatch(bank, clamped)
        }
    }

    fun selectBankAndPatch(bank: Bank, patchNumber: Int) {
        val clamped = patchNumber.coerceIn(1, 100)
        if (bank == Bank.A) savedPatchA = clamped else savedPatchB = clamped
        _selectedBank.value = bank
        _selectedPatchNumber.value = clamped
        viewModelScope.launch {
            repository.updateSelectedBankAndPatch(bank, clamped)
        }
    }

    fun setMasterVolume(volume: Float) {
        val v = volume.coerceIn(0f, 1f)
        audioEngine.setMasterVolume(v)
        viewModelScope.launch {
            repository.updateMasterVolume(v)
        }
    }

    fun setPadVolumeQuick(padIndex: Int, volume: Float) {
        val v = volume.coerceIn(0f, 1f)
        audioEngine.setPadVolume(padIndex, v)
        val bank = _selectedBank.value
        val num = _selectedPatchNumber.value
        viewModelScope.launch {
            repository.updatePadVolume(bank, num, padIndex, v)
        }
    }

    fun saveCurrentPatchExplicit() {
        val st = uiState.value
        val key = formatPatchKey(st.selectedBank, st.selectedPatchNumber)
        viewModelScope.launch {
            val entities = st.pads.map {
                PadAssignmentEntity(
                    patchKey = key,
                    padIndex = it.padIndex,
                    sampleId = it.sampleId,
                    missingSampleName = it.missingSampleName,
                    volume = it.volume,
                    pitch = it.pitch,
                    pan = it.pan,
                    enabled = it.enabled
                )
            }
            repository.savePatch(st.selectedBank, st.selectedPatchNumber, st.currentPatchName, st.isCurrentFavorite, entities)
            showBanner("Saved ${st.selectedBank.label} Patch ${st.selectedPatchNumber}: ${st.currentPatchName}")
        }
    }

    fun reloadCurrentPatch() {
        viewModelScope.launch(Dispatchers.IO) {
            val st = uiState.value
            sampleRegistry.initializeAndVerifyRegistry()
            val files = sampleRegistry.buildSampleFileMap()
            audioEngine.preloadSamples(st.pads, files, fxState.value)
            showBanner("Loaded ${st.selectedBank.label} Patch ${st.selectedPatchNumber} (${st.currentPatchName})")
        }
    }

    fun saveEditedPatch(patchName: String, editedPads: List<PadUiModel>) {
        val st = uiState.value
        val key = formatPatchKey(st.selectedBank, st.selectedPatchNumber)
        viewModelScope.launch {
            val entities = editedPads.map {
                PadAssignmentEntity(
                    patchKey = key,
                    padIndex = it.padIndex,
                    sampleId = it.sampleId,
                    missingSampleName = it.missingSampleName,
                    volume = it.volume,
                    pitch = it.pitch,
                    pan = it.pan,
                    enabled = it.enabled
                )
            }
            repository.savePatch(st.selectedBank, st.selectedPatchNumber, patchName, st.isCurrentFavorite, entities)
            showBanner("Updated ${st.selectedBank.label} Patch ${st.selectedPatchNumber}: $patchName")
        }
    }

    fun copyCurrentPatchTo(targetBank: Bank, targetPatchNumber: Int) {
        val st = uiState.value
        viewModelScope.launch {
            repository.copyPatch(st.selectedBank, st.selectedPatchNumber, targetBank, targetPatchNumber)
            showBanner("Copied ${st.selectedBank.label} #${st.selectedPatchNumber} -> ${targetBank.label} #$targetPatchNumber")
        }
    }

    fun clearCurrentPatch() {
        val st = uiState.value
        viewModelScope.launch {
            repository.clearPatch(st.selectedBank, st.selectedPatchNumber)
            showBanner("Cleared ${st.selectedBank.label} Patch ${st.selectedPatchNumber}")
        }
    }

    fun toggleFavorite() {
        val st = uiState.value
        viewModelScope.launch {
            repository.toggleFavorite(st.selectedBank, st.selectedPatchNumber)
        }
    }

    fun updateAudioFx(newFx: AudioFxState) {
        audioEngine.updateFxState(newFx)
        viewModelScope.launch {
            repository.saveAudioFx(newFx)
        }
    }

    fun updateMidiMappings(mappings: List<MidiPadMapping>) {
        viewModelScope.launch {
            repository.saveMidiMappings(mappings)
            showBanner("Saved MIDI note mappings")
        }
    }

    fun previewSample(sampleId: String, volume: Float = 0.85f, pitch: Float = 1.0f) {
        viewModelScope.launch(Dispatchers.IO) {
            val sample = sampleRegistry.getSample(sampleId) ?: return@launch
            val file = File(sample.storedPath)
            if (file.exists()) {
                audioEngine.preloadAndPlaySingleSample(sampleId, file, volume, pitch)
            } else {
                showBanner("Cannot preview: sample file missing (${sample.originalFilename})")
            }
        }
    }

    fun importCustomSample(uri: Uri, onImported: ((SampleEntity) -> Unit)? = null) {
        viewModelScope.launch {
            _isBusy.value = true
            when (val res = sampleImporter.importFromUri(uri)) {
                is SampleImportResult.Success -> {
                    val tag = if (res.wasDuplicate) "Already in library" else "Imported"
                    showBanner("$tag: ${res.sample.originalFilename}")
                    onImported?.invoke(res.sample)
                }
                is SampleImportResult.Failure -> {
                    showBanner("Import failed (${res.filename}): ${res.reason}")
                }
            }
            _isBusy.value = false
        }
    }

    fun relinkMissingPadSample(padIndex: Int, sampleId: String) {
        val st = uiState.value
        viewModelScope.launch {
            repository.relinkMissingPadSample(st.selectedBank, st.selectedPatchNumber, padIndex, sampleId)
            showBanner("Relinked PAD $padIndex")
        }
    }

    fun deleteUserSample(sampleId: String) {
        viewModelScope.launch {
            val ok = sampleRegistry.removeSample(sampleId)
            showBanner(if (ok) "Removed custom sample" else "Factory samples cannot be deleted")
        }
    }

    fun verifySampleHealth(sampleId: String) {
        viewModelScope.launch {
            val verified = sampleRegistry.verifySingleSample(sampleId)
            if (verified != null) {
                showBanner(
                    if (verified.decodingVerified) "Verified OK: ${verified.originalFilename} (${verified.durationMs}ms)"
                    else "Sample error: ${verified.errorMessage}"
                )
            }
        }
    }

    fun runLegacyFolderMigration(treeUri: Uri, preserveOriginalSlots: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            val report = legacyDataMigration.migrateFromFolderUri(treeUri, preserveOriginalSlots)
            _migrationReport.value = report
            preloadActivePatch()
            _isBusy.value = false
        }
    }

    fun runLegacyZipMigration(zipUri: Uri, preserveOriginalSlots: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            val report = legacyDataMigration.migrateFromZipUri(zipUri, preserveOriginalSlots)
            _migrationReport.value = report
            preloadActivePatch()
            _isBusy.value = false
        }
    }

    fun clearMigrationReport() {
        _migrationReport.value = null
    }

    fun exportBackup(destUri: Uri) {
        viewModelScope.launch {
            _isBusy.value = true
            _backupReport.value = backupManager.exportBackup(destUri)
            _isBusy.value = false
        }
    }

    fun importBackup(srcUri: Uri, overwriteExisting: Boolean) {
        viewModelScope.launch {
            _isBusy.value = true
            _backupReport.value = backupManager.importBackupOrInspectExternal(srcUri, overwriteExisting)
            preloadActivePatch()
            _isBusy.value = false
        }
    }

    fun clearBackupReport() {
        _backupReport.value = null
    }

    fun showBanner(msg: String) {
        _statusBanner.value = msg
    }

    fun dismissBanner() {
        _statusBanner.value = null
    }

    fun onAppResumed() {
        audioEngine.initializeAudio()
        viewModelScope.launch(Dispatchers.IO) {
            preloadActivePatch()
        }
    }

    override fun onCleared() {
        super.onCleared()
        midiManager.stopListening()
        audioEngine.releaseAudio()
        audioEngine.shutdownExecutor()
    }
}
