package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "samples")
data class SampleEntity(
    @PrimaryKey val sampleId: String,
    val originalFilename: String,
    val displayName: String,
    val storedPath: String,
    val sourceUri: String? = null,
    val format: String,       // "WAV", "MP3", "OGG"
    val sourceType: String,   // "FACTORY", "USER_IMPORT", "LEGACY_IMPORT", "BACKUP_RESTORE"
    val durationMs: Long = 0L,
    val fileSizeBytes: Long = 0L,
    val contentHash: String = "",
    val decodingVerified: Boolean = false,
    val errorMessage: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
