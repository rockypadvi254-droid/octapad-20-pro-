package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PatchDao {
    @Query("SELECT COUNT(*) FROM patches")
    suspend fun getPatchCount(): Int

    @Query("SELECT * FROM patches WHERE bank = :bank ORDER BY patchNumber ASC")
    fun observePatchesByBank(bank: String): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches ORDER BY bank ASC, patchNumber ASC")
    fun observeAllPatches(): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches ORDER BY bank ASC, patchNumber ASC")
    suspend fun getAllPatchesSync(): List<PatchEntity>

    @Query("SELECT * FROM patches WHERE isFavorite = 1 ORDER BY bank ASC, patchNumber ASC")
    fun observeFavoritePatches(): Flow<List<PatchEntity>>

    @Query("SELECT * FROM patches WHERE patchKey = :patchKey")
    fun observePatch(patchKey: String): Flow<PatchEntity?>

    @Query("SELECT * FROM patches WHERE patchKey = :patchKey")
    suspend fun getPatchSync(patchKey: String): PatchEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPatch(patch: PatchEntity)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPatchesIgnore(patches: List<PatchEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPatches(patches: List<PatchEntity>)

    @Query("UPDATE patches SET isFavorite = :isFavorite, updatedAt = :updatedAt WHERE patchKey = :patchKey")
    suspend fun setFavorite(patchKey: String, isFavorite: Boolean, updatedAt: Long = System.currentTimeMillis())

    @Query("UPDATE patches SET name = :name, updatedAt = :updatedAt WHERE patchKey = :patchKey")
    suspend fun updatePatchName(patchKey: String, name: String, updatedAt: Long = System.currentTimeMillis())

    // Pad assignments
    @Query("SELECT * FROM pad_assignments WHERE patchKey = :patchKey ORDER BY padIndex ASC")
    fun observePadAssignments(patchKey: String): Flow<List<PadAssignmentEntity>>

    @Query("SELECT * FROM pad_assignments WHERE patchKey = :patchKey ORDER BY padIndex ASC")
    suspend fun getPadAssignmentsSync(patchKey: String): List<PadAssignmentEntity>

    @Query("SELECT * FROM pad_assignments ORDER BY patchKey ASC, padIndex ASC")
    suspend fun getAllPadAssignmentsSync(): List<PadAssignmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPadAssignments(assignments: List<PadAssignmentEntity>)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPadAssignmentsIgnore(assignments: List<PadAssignmentEntity>)

    @Query("UPDATE pad_assignments SET volume = :volume WHERE patchKey = :patchKey AND padIndex = :padIndex")
    suspend fun updatePadVolume(patchKey: String, padIndex: Int, volume: Float)

    @Transaction
    suspend fun savePatchWithPads(patch: PatchEntity, pads: List<PadAssignmentEntity>) {
        upsertPatch(patch)
        upsertPadAssignments(pads)
    }

    @Transaction
    suspend fun copyPatch(sourceKey: String, targetKey: String, targetBank: String, targetNumber: Int, newName: String? = null) {
        val src = getPatchSync(sourceKey) ?: return
        val srcPads = getPadAssignmentsSync(sourceKey)
        val copiedPatch = PatchEntity(
            patchKey = targetKey,
            bank = targetBank,
            patchNumber = targetNumber,
            name = newName ?: src.name,
            isFavorite = src.isFavorite,
            updatedAt = System.currentTimeMillis()
        )
        val copiedPads = srcPads.map { it.copy(patchKey = targetKey) }
        upsertPatch(copiedPatch)
        upsertPadAssignments(copiedPads)
    }

    @Transaction
    suspend fun clearPatch(patchKey: String, bank: String, patchNumber: Int) {
        upsertPatch(
            PatchEntity(
                patchKey = patchKey,
                bank = bank,
                patchNumber = patchNumber,
                name = "Empty Patch $patchNumber",
                isFavorite = false,
                updatedAt = System.currentTimeMillis()
            )
        )
        val emptyPads = (1..8).map { padIdx ->
            PadAssignmentEntity(
                patchKey = patchKey,
                padIndex = padIdx,
                sampleId = null,
                missingSampleName = null,
                volume = 0.85f,
                pitch = 1.0f,
                pan = 0.0f,
                enabled = true
            )
        }
        upsertPadAssignments(emptyPads)
    }

    // Samples
    @Query("SELECT * FROM samples ORDER BY sourceType ASC, displayName ASC")
    fun observeAllSamples(): Flow<List<SampleEntity>>

    @Query("SELECT * FROM samples")
    suspend fun getAllSamplesSync(): List<SampleEntity>

    @Query("SELECT * FROM samples WHERE sampleId = :sampleId")
    suspend fun getSampleSync(sampleId: String): SampleEntity?

    @Query("SELECT * FROM samples WHERE contentHash = :hash LIMIT 1")
    suspend fun getSampleByHashSync(hash: String): SampleEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSample(sample: SampleEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSamples(samples: List<SampleEntity>)

    @Query("DELETE FROM samples WHERE sampleId = :sampleId")
    suspend fun deleteSampleById(sampleId: String)

    // Settings
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun observeSettings(): Flow<AppSettingsEntity?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun getSettingsSync(): AppSettingsEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSettings(settings: AppSettingsEntity)

    // MIDI Mappings
    @Query("SELECT * FROM midi_mappings ORDER BY padIndex ASC")
    fun observeMidiMappings(): Flow<List<MidiMappingEntity>>

    @Query("SELECT * FROM midi_mappings ORDER BY padIndex ASC")
    suspend fun getMidiMappingsSync(): List<MidiMappingEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertMidiMappings(mappings: List<MidiMappingEntity>)
}
