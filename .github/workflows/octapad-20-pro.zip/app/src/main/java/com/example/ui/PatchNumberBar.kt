package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Bank
import com.example.data.PatchSummary
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ChassisCharcoal
import com.example.ui.theme.ControlBorder
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PatchNumberBar(
    selectedBank: Bank,
    selectedPatchNumber: Int,
    patches: List<PatchSummary>,
    onSelectPatch: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var favoritesOnly by remember { mutableStateOf(false) }
    val displayPatches = remember(patches, favoritesOnly) {
        if (favoritesOnly) patches.filter { it.isFavorite } else patches
    }
    val listState = rememberLazyListState()

    LaunchedEffect(selectedPatchNumber, selectedBank, favoritesOnly) {
        val idx = displayPatches.indexOfFirst { it.patchNumber == selectedPatchNumber }
        if (idx >= 0) {
            listState.animateScrollToItem((idx - 2).coerceAtLeast(0))
        }
    }

    val accent = if (selectedBank == Bank.A) ElectricCyan else AmberGold

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = ChassisCharcoal,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ControlBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Favorites filter toggle
            Row(
                modifier = Modifier
                    .height(38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(if (favoritesOnly) AmberGold.copy(alpha = 0.2f) else ChassisBlack)
                    .border(
                        1.dp,
                        if (favoritesOnly) AmberGold else ControlBorder,
                        RoundedCornerShape(6.dp)
                    )
                    .clickable { favoritesOnly = !favoritesOnly }
                    .padding(horizontal = 8.dp)
                    .testTag("favorites_filter_chip"),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = "Filter favorite patches",
                    tint = if (favoritesOnly) AmberGold else TextMuted,
                    modifier = Modifier.size(14.dp)
                )
                Text(
                    text = if (favoritesOnly) "FAVS" else "ALL 1-100",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = if (favoritesOnly) AmberGold else TextSecondary,
                    maxLines = 1
                )
            }

            if (displayPatches.isEmpty()) {
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "No favorite patches in ${selectedBank.label}. Tap star in LCD to bookmark.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                }
            } else {
                LazyRow(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("patch_number_bar"),
                    contentPadding = PaddingValues(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    items(
                        items = displayPatches,
                        key = { it.patchKey }
                    ) { patch ->
                        val isSelected = patch.patchNumber == selectedPatchNumber
                        Box(
                            modifier = Modifier
                                .height(38.dp)
                                .width(84.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(
                                    if (isSelected) accent.copy(alpha = 0.22f) else PanelSurface
                                )
                                .border(
                                    width = if (isSelected) 1.5.dp else 1.dp,
                                    color = if (isSelected) accent else ControlBorder,
                                    shape = RoundedCornerShape(6.dp)
                                )
                                .clickable { onSelectPatch(patch.patchNumber) }
                                .padding(horizontal = 6.dp, vertical = 3.dp)
                                .testTag("patch_chip_${patch.patchNumber}"),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        // Strictly 1..100 without leading zeros
                                        text = patch.patchNumber.toString(),
                                        style = MaterialTheme.typography.labelMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        ),
                                        color = if (isSelected) accent else TextPrimary
                                    )
                                    if (patch.isFavorite) {
                                        Icon(
                                            imageVector = Icons.Filled.Star,
                                            contentDescription = "Favorite patch",
                                            tint = AmberGold,
                                            modifier = Modifier.size(10.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = patch.name,
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                    color = if (isSelected) TextPrimary else TextSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
