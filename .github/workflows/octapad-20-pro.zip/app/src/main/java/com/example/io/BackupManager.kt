package com.example.io

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.audio.AudioEffectProcessor
import com.example.audio.FactorySampleGenerator
import com.example.data.BackupOperationReport
import com.example.data.Bank
import com.example.data.db.AppSettingsEntity
import com.example.data.db.MidiMappingEntity
import com.example.data.db.PadAssignmentEntity
import com.example.data.db.PatchDao
import com.example.data.db.PatchEntity
import com.example.data.db.SampleEntity
import com.example.legacy.LegacyDataMigration
import com.example.samples.SampleRegistry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BackupManager(
    private val context: Context,
    private val dao: PatchDao,
    private val sampleRegistry: SampleRegistry,
    private val legacyDataMigration: LegacyDataMigration
) {
    companion object {
        const val BACKUP_FORMAT_ID = "OCTAPAD_20_PRO_BACKUP"
        const val BACKUP_SCHEMA_VERSION = 1
    }

    suspend fun exportBackup(destUri: Uri): BackupOperationReport = withContext(Dispatchers.IO) {
        try {
            val patches = dao.getAllPatchesSync()
            val pads = dao.getAllPadAssignmentsSync()
            val samples = dao.getAllSamplesSync()
            val settings = dao.getSettingsSync() ?: AppSettingsEntity()
            val midiMappings = dao.getMidiMappingsSync()

            val padsByPatch = pads.groupBy { it.patchKey }

            val patchesArray = JSONArray()
            for (p in patches) {
                val pObj = JSONObject()
                pObj.put("patchKey", p.patchKey)
                pObj.put("bank", p.bank)
                pObj.put("patchNumber", p.patchNumber)
                pObj.put("name", p.name)
                pObj.put("isFavorite", p.isFavorite)
                pObj.put("updatedAt", p.updatedAt)

                val padsArr = JSONArray()
                val pPads = padsByPatch[p.patchKey].orEmpty().sortedBy { it.padIndex }
                for (pad in pPads) {
                    val padObj = JSONObject()
                    padObj.put("padIndex", pad.padIndex)
                    padObj.put("sampleId", pad.sampleId ?: JSONObject.NULL)
                    padObj.put("missingSampleName", pad.missingSampleName ?: JSONObject.NULL)
                    padObj.put("volume", pad.volume.toDouble())
                    padObj.put("pitch", pad.pitch.toDouble())
                    padObj.put("pan", pad.pan.toDouble())
                    padObj.put("enabled", pad.enabled)
                    padsArr.put(padObj)
                }
                pObj.put("pads", padsArr)
                patchesArray.put(pObj)
            }

            val samplesArray = JSONArray()
            val exportedSampleFiles = ArrayList<Pair<String, File>>()
            for (s in samples) {
                val file = File(s.storedPath)
                val zipRelPath = if (s.sourceType != "FACTORY" && file.exists()) {
                    "samples/${s.sampleId}_${s.originalFilename.replace(Regex("[^A-Za-z0-9._-]"), "_")}"
                } else {
                    ""
                }
                if (zipRelPath.isNotEmpty()) {
                    exportedSampleFiles.add(zipRelPath to file)
                }
                val sObj = JSONObject()
                sObj.put("sampleId", s.sampleId)
                sObj.put("originalFilename", s.originalFilename)
                sObj.put("displayName", s.displayName)
                sObj.put("format", s.format)
                sObj.put("sourceType", s.sourceType)
                sObj.put("durationMs", s.durationMs)
                sObj.put("contentHash", s.contentHash)
                sObj.put("archivePath", zipRelPath)
                samplesArray.put(sObj)
            }

            val settingsObj = JSONObject().apply {
                put("masterVolume", settings.masterVolume.toDouble())
                put("selectedBank", settings.selectedBank)
                put("lastPatchNumberA", settings.lastPatchNumberA)
                put("lastPatchNumberB", settings.lastPatchNumberB)
                put("reverbEnabled", settings.reverbEnabled)
                put("reverbMix", settings.reverbMix.toDouble())
                put("delayEnabled", settings.delayEnabled)
                put("delayTimeMs", settings.delayTimeMs)
                put("delayFeedback", settings.delayFeedback.toDouble())
                put("eqEnabled", settings.eqEnabled)
                put("bassGainDb", settings.bassGainDb.toDouble())
                put("midGainDb", settings.midGainDb.toDouble())
                put("trebleGainDb", settings.trebleGainDb.toDouble())
            }

            val midiArray = JSONArray()
            for (m in midiMappings) {
                midiArray.put(
                    JSONObject().apply {
                        put("padIndex", m.padIndex)
                        put("midiNote", m.midiNote)
                        put("channel", m.channel)
                    }
                )
            }

            val manifestObj = JSONObject().apply {
                put("format", BACKUP_FORMAT_ID)
                put("schemaVersion", BACKUP_SCHEMA_VERSION)
                put("appName", "Octapad 20 Pro")
                put("createdAt", System.currentTimeMillis())
                put("patchCount", patches.size)
                put("archivedSamplesCount", exportedSampleFiles.size)
            }

            val outStream = context.contentResolver.openOutputStream(destUri)
                ?: return@withContext BackupOperationReport(
                    success = false,
                    message = "Unable to open destination file for backup export."
                )

            outStream.use { os ->
                ZipOutputStream(os).use { zos ->
                    writeZipText(zos, "manifest.json", manifestObj.toString(2))
                    writeZipText(zos, "patches.json", patchesArray.toString(2))
                    writeZipText(zos, "samples_index.json", samplesArray.toString(2))
                    writeZipText(zos, "settings.json", settingsObj.toString(2))
                    writeZipText(zos, "midi_mappings.json", midiArray.toString(2))

                    val buf = ByteArray(8192)
                    for ((relPath, file) in exportedSampleFiles) {
                        zos.putNextEntry(ZipEntry(relPath))
                        file.inputStream().use { fis ->
                            var r = fis.read(buf)
                            while (r > 0) {
                                zos.write(buf, 0, r)
                                r = fis.read(buf)
                            }
                        }
                        zos.closeEntry()
                    }
                }
            }

            BackupOperationReport(
                success = true,
                message = "Versioned backup exported (${patches.size} patches, ${exportedSampleFiles.size} custom/legacy samples).",
                patchCount = patches.size,
                sampleCount = exportedSampleFiles.size,
                formatDetected = "$BACKUP_FORMAT_ID v$BACKUP_SCHEMA_VERSION"
            )
        } catch (t: Throwable) {
            BackupOperationReport(
                success = false,
                message = "Backup export failed: ${t.message ?: "Unknown error"}"
            )
        }
    }

    suspend fun importBackupOrInspectExternal(
        srcUri: Uri,
        overwriteExistingPatches: Boolean = false
    ): BackupOperationReport = withContext(Dispatchers.IO) {
        val filename = resolveFileName(srcUri) ?: "backup_file"
        val tempFile = File(context.cacheDir, "inspect_${System.currentTimeMillis()}_$filename")
        try {
            val input = context.contentResolver.openInputStream(srcUri)
                ?: return@withContext BackupOperationReport(false, "Cannot open selected backup file.")
            input.use { src ->
                FileOutputStream(tempFile).use { dst -> src.copyTo(dst) }
            }

            if (tempFile.length() < 4) {
                return@withContext BackupOperationReport(false, "Selected backup file is empty or unreadable.")
            }

            val magic = ByteArray(4)
            tempFile.inputStream().use { it.read(magic) }
            val isZip = magic[0] == 0x50.toByte() && magic[1] == 0x4B.toByte() // "PK"

            if (isZip) {
                return@withContext importZipBackup(tempFile, srcUri, overwriteExistingPatches)
            }

            // Check if it's JSON / XML / SQLite external backup
            val headText = runCatching { tempFile.bufferedReader().use { it.readLine()?.trim() ?: "" } }.getOrDefault("")
            val isSqlite = headText.startsWith("SQLite format 3")
            val isJsonOrXml = headText.startsWith("{") || headText.startsWith("[") || headText.startsWith("<")

            if (isSqlite || isJsonOrXml) {
                val report = legacyDataMigration.migrateFromZipOrSingleConfigCheck(tempFile, filename)
                if (report != null && report.importedPatchesCount > 0) {
                    return@withContext BackupOperationReport(
                        success = true,
                        message = "External backup converted (${report.importedPatchesCount} patches).",
                        patchCount = report.importedPatchesCount,
                        sampleCount = report.importedSamplesCount,
                        missingSamples = report.missingSamples,
                        formatDetected = report.detectedFormat
                    )
                }
            }

            // Honest rejection of unsupported proprietary binary formats (e.g., Roland SPD-30 / SYX / BIN)
            val ext = filename.substringAfterLast('.', "").uppercase().ifBlank { "BINARY" }
            BackupOperationReport(
                success = false,
                message = "Unsupported external backup format ($ext). Hardware binary dumps (such as proprietary Roland SPD-30 / .SYX / encrypted backups) cannot be safely converted without documented format specifications. Use .o20pro.zip backups or open JSON/XML/SQLite/ZIP sample backups.",
                formatDetected = "Unsupported ($ext)"
            )
        } catch (t: Throwable) {
            BackupOperationReport(false, "Backup inspection failed: ${t.message ?: "Invalid archive"}")
        } finally {
            runCatching { tempFile.delete() }
        }
    }

    private suspend fun importZipBackup(
        zipFile: File,
        originalUri: Uri,
        overwriteExistingPatches: Boolean
    ): BackupOperationReport {
        val extractDir = File(context.cacheDir, "restore_${System.currentTimeMillis()}").apply { mkdirs() }
        var hasManifest = false
        try {
            ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory) {
                        val safeRel = entry.name.replace("..", "").trimStart('/')
                        if (safeRel == "manifest.json") hasManifest = true
                        val outFile = File(extractDir, safeRel)
                        outFile.parentFile?.mkdirs()
                        FileOutputStream(outFile).use { fos ->
                            zis.copyTo(fos)
                        }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }

            if (!hasManifest) {
                // Treat as external / legacy ZIP backup!
                val legacyReport = legacyDataMigration.migrateFromZipUri(originalUri, preserveOriginalSlots = overwriteExistingPatches)
                return BackupOperationReport(
                    success = legacyReport.importedPatchesCount > 0 || legacyReport.importedSamplesCount > 0,
                    message = "External ZIP archive inspected: ${legacyReport.importedPatchesCount} patches, ${legacyReport.importedSamplesCount} samples imported.",
                    patchCount = legacyReport.importedPatchesCount,
                    sampleCount = legacyReport.importedSamplesCount,
                    missingSamples = legacyReport.missingSamples,
                    formatDetected = legacyReport.detectedFormat
                )
            }

            val manifestJson = JSONObject(File(extractDir, "manifest.json").readText())
            if (manifestJson.optString("format") != BACKUP_FORMAT_ID) {
                return BackupOperationReport(
                    success = false,
                    message = "Unrecognized backup manifest format: ${manifestJson.optString("format")}"
                )
            }
            val version = manifestJson.optInt("schemaVersion", 0)
            if (version > BACKUP_SCHEMA_VERSION) {
                return BackupOperationReport(
                    success = false,
                    message = "Backup schema version $version is newer than supported version $BACKUP_SCHEMA_VERSION."
                )
            }

            // 1. Restore samples & verify audio decoding
            val restoredSamplesMap = HashMap<String, SampleEntity>()
            val existingSamples = sampleRegistry.getAllSamples().associateBy { it.sampleId }
            val restoredDir = File(context.filesDir, "samples/restored").apply { mkdirs() }
            var restoredSampleCount = 0

            val samplesFile = File(extractDir, "samples_index.json")
            if (samplesFile.exists()) {
                val samplesArr = JSONArray(samplesFile.readText())
                for (i in 0 until samplesArr.length()) {
                    val sObj = samplesArr.getJSONObject(i)
                    val sampleId = sObj.getString("sampleId")
                    val archivePath = sObj.optString("archivePath", "")
                    val origName = sObj.optString("originalFilename", sampleId)
                    val format = sObj.optString("format", "WAV")
                    val sourceType = sObj.optString("sourceType", "BACKUP_RESTORE")

                    if (sourceType == "FACTORY" && existingSamples.containsKey(sampleId)) {
                        restoredSamplesMap[sampleId] = existingSamples[sampleId]!!
                        continue
                    }

                    if (archivePath.isNotBlank()) {
                        val extractedSample = File(extractDir, archivePath)
                        if (extractedSample.exists() && extractedSample.length() > 0L) {
                            val verified = AudioEffectProcessor.verifyAndInspectAudio(extractedSample, format)
                            if (verified.valid) {
                                val dest = File(restoredDir, "${sampleId}_${origName.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
                                extractedSample.copyTo(dest, overwrite = true)
                                val entity = SampleEntity(
                                    sampleId = sampleId,
                                    originalFilename = origName,
                                    displayName = sObj.optString("displayName", origName),
                                    storedPath = dest.absolutePath,
                                    format = format,
                                    sourceType = if (sourceType == "FACTORY") "FACTORY" else "BACKUP_RESTORE",
                                    durationMs = verified.durationMs,
                                    fileSizeBytes = dest.length(),
                                    contentHash = FactorySampleGenerator.sha256(dest),
                                    decodingVerified = true
                                )
                                sampleRegistry.registerSample(entity)
                                restoredSamplesMap[sampleId] = entity
                                restoredSampleCount++
                            }
                        }
                    } else {
                        existingSamples[sampleId]?.let { restoredSamplesMap[sampleId] = it }
                    }
                }
            }

            // 2. Restore patches & pad assignments
            val patchesFile = File(extractDir, "patches.json")
            val missingSampleNames = LinkedHashSet<String>()
            var restoredPatchesCount = 0
            if (patchesFile.exists()) {
                val patchesArr = JSONArray(patchesFile.readText())
                val existingPatches = dao.getAllPatchesSync().associateBy { it.patchKey }

                for (i in 0 until patchesArr.length()) {
                    val pObj = patchesArr.getJSONObject(i)
                    val patchKey = pObj.getString("patchKey")
                    val bank = Bank.fromCode(pObj.getString("bank"))
                    val num = pObj.getInt("patchNumber").coerceIn(1, 100)
                    val name = pObj.getString("name")
                    val isFav = pObj.optBoolean("isFavorite", false)

                    if (!overwriteExistingPatches) {
                        val cur = existingPatches[patchKey]
                        // Skip overwriting user-customized patches when in safe non-overwrite mode unless target is still untouched/empty
                        val isDefaultSlot = cur == null ||
                            cur.name.startsWith("Empty Patch", true) ||
                            cur.name.startsWith("Patch ", true) ||
                            cur.name.startsWith("Bank B ", true)
                        if (!isDefaultSlot && cur.name == name) {
                            // Identical slot, safe to update
                        } else if (!isDefaultSlot && name.startsWith("Patch ") && !cur.name.startsWith("Patch ")) {
                            continue
                        }
                    }

                    val patchEntity = PatchEntity(
                        patchKey = patchKey,
                        bank = bank.code,
                        patchNumber = num,
                        name = name,
                        isFavorite = isFav,
                        updatedAt = System.currentTimeMillis()
                    )

                    val padsArr = pObj.optJSONArray("pads") ?: JSONArray()
                    val padList = ArrayList<PadAssignmentEntity>(8)
                    for (j in 0 until padsArr.length()) {
                        val padObj = padsArr.getJSONObject(j)
                        val padIdx = padObj.getInt("padIndex").coerceIn(1, 8)
                        val rawSampleId = if (padObj.isNull("sampleId")) null else padObj.optString("sampleId", "").ifBlank { null }
                        val rawMissing = if (padObj.isNull("missingSampleName")) null else padObj.optString("missingSampleName", "").ifBlank { null }

                        val resolvedSample = rawSampleId?.let { sid ->
                            restoredSamplesMap[sid] ?: existingSamples[sid]
                        }
                        val validOnDisk = resolvedSample != null && File(resolvedSample.storedPath).exists()

                        val finalSampleId = if (validOnDisk) resolvedSample!!.sampleId else null
                        val finalMissing = when {
                            validOnDisk -> null
                            rawMissing != null -> rawMissing
                            rawSampleId != null -> rawSampleId
                            else -> null
                        }
                        if (finalMissing != null) missingSampleNames.add(finalMissing)

                        padList.add(
                            PadAssignmentEntity(
                                patchKey = patchKey,
                                padIndex = padIdx,
                                sampleId = finalSampleId,
                                missingSampleName = finalMissing,
                                volume = padObj.optDouble("volume", 0.85).toFloat().coerceIn(0f, 1f),
                                pitch = padObj.optDouble("pitch", 1.0).toFloat().coerceIn(0.5f, 2.0f),
                                pan = padObj.optDouble("pan", 0.0).toFloat().coerceIn(-1f, 1f),
                                enabled = padObj.optBoolean("enabled", true)
                            )
                        )
                    }
                    dao.savePatchWithPads(patchEntity, padList)
                    restoredPatchesCount++
                }
            }

            // 3. Restore settings & MIDI mappings
            val settingsFile = File(extractDir, "settings.json")
            if (settingsFile.exists()) {
                val s = JSONObject(settingsFile.readText())
                dao.upsertSettings(
                    AppSettingsEntity(
                        id = 1,
                        masterVolume = s.optDouble("masterVolume", 0.85).toFloat().coerceIn(0f, 1f),
                        selectedBank = s.optString("selectedBank", "A"),
                        lastPatchNumberA = s.optInt("lastPatchNumberA", 1).coerceIn(1, 100),
                        lastPatchNumberB = s.optInt("lastPatchNumberB", 1).coerceIn(1, 100),
                        reverbEnabled = s.optBoolean("reverbEnabled", false),
                        reverbMix = s.optDouble("reverbMix", 0.30).toFloat().coerceIn(0f, 1f),
                        delayEnabled = s.optBoolean("delayEnabled", false),
                        delayTimeMs = s.optInt("delayTimeMs", 220).coerceIn(60, 800),
                        delayFeedback = s.optDouble("delayFeedback", 0.35).toFloat().coerceIn(0.05f, 0.72f),
                        eqEnabled = s.optBoolean("eqEnabled", false),
                        bassGainDb = s.optDouble("bassGainDb", 0.0).toFloat().coerceIn(-12f, 12f),
                        midGainDb = s.optDouble("midGainDb", 0.0).toFloat().coerceIn(-12f, 12f),
                        trebleGainDb = s.optDouble("trebleGainDb", 0.0).toFloat().coerceIn(-12f, 12f)
                    )
                )
            }

            val midiFile = File(extractDir, "midi_mappings.json")
            if (midiFile.exists()) {
                val arr = JSONArray(midiFile.readText())
                val list = ArrayList<MidiMappingEntity>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    list.add(
                        MidiMappingEntity(
                            padIndex = m.getInt("padIndex").coerceIn(1, 8),
                            midiNote = m.getInt("midiNote").coerceIn(0, 127),
                            channel = m.optInt("channel", -1)
                        )
                    )
                }
                if (list.isNotEmpty()) dao.upsertMidiMappings(list)
            }

            return BackupOperationReport(
                success = true,
                message = "Restored $restoredPatchesCount patches and $restoredSampleCount samples from verified v$version backup.",
                patchCount = restoredPatchesCount,
                sampleCount = restoredSampleCount,
                missingSamples = missingSampleNames.toList(),
                formatDetected = "$BACKUP_FORMAT_ID v$version"
            )
        } finally {
            runCatching { extractDir.deleteRecursively() }
        }
    }

    private fun writeZipText(zos: ZipOutputStream, name: String, content: String) {
        zos.putNextEntry(ZipEntry(name))
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }

    private fun resolveFileName(uri: Uri): String? {
        if (uri.scheme == "file") return uri.lastPathSegment
        return runCatching {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment?.substringAfterLast('/')
    }
}

private suspend fun LegacyDataMigration.migrateFromZipOrSingleConfigCheck(
    tempFile: File,
    originalName: String
): com.example.data.LegacyMigrationReport? {
    val tmpDir = File(tempFile.parentFile, "single_cfg_${System.currentTimeMillis()}").apply { mkdirs() }
    val report = try {
        tempFile.copyTo(File(tmpDir, originalName), overwrite = true)
        migrateFromDirectory(tmpDir, preserveOriginalSlots = false)
    } finally {
        runCatching { tmpDir.deleteRecursively() }
    }
    return report
}
