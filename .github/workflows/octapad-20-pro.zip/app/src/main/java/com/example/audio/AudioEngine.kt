package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import com.example.data.AudioFxState
import com.example.data.PadUiModel
import com.example.data.SampleLoadingStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import kotlin.math.abs

data class AudioEngineStatus(
    val isInitialized: Boolean = false,
    val hasAudioFocus: Boolean = false,
    val loadedSamplesCount: Int = 0,
    val loadingSamplesCount: Int = 0,
    val failedSamplesCount: Int = 0,
    val activePatchReady: Boolean = false,
    val fxProcessingActive: Boolean = false
)

class AudioEngine(private val context: Context) {

    private val soundPoolManager = SoundPoolManager()
    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    private var audioFocusRequest: AudioFocusRequest? = null

    private val delayExecutor: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "octapad-delay-thread").apply { priority = Thread.MAX_PRIORITY }
    }

    // Active patch slot configuration in memory for zero-DB / zero-UI-block pad triggering
    private class PadPlayConfig(
        @Volatile var cacheKey: String = "",
        @Volatile var sampleId: String = "",
        @Volatile var volume: Float = 0.85f,
        @Volatile var pitch: Float = 1.0f,
        @Volatile var pan: Float = 0.0f,
        @Volatile var enabled: Boolean = true,
        @Volatile var lastStreamId: Int = 0
    )

    private val padConfigs = Array(8) { PadPlayConfig() }
    private val sampleIdToActiveCacheKey = ConcurrentHashMap<String, String>()

    @Volatile
    private var masterVolume: Float = 0.85f

    @Volatile
    private var fxState: AudioFxState = AudioFxState()

    @Volatile
    private var hasAudioFocus: Boolean = false

    private val _status = MutableStateFlow(AudioEngineStatus())
    val status: StateFlow<AudioEngineStatus> = _status.asStateFlow()

    private val _sampleStatuses = MutableStateFlow<Map<String, SampleLoadingStatus>>(emptyMap())
    val sampleStatuses: StateFlow<Map<String, SampleLoadingStatus>> = _sampleStatuses.asStateFlow()

    private val _sampleErrors = MutableStateFlow<Map<String, String>>(emptyMap())
    val sampleErrors: StateFlow<Map<String, String>> = _sampleErrors.asStateFlow()

    private val statusListener: (String, SampleLoadingStatus, String?) -> Unit = { cacheKey, st, err ->
        val sampleId = cacheKey.substringBefore("::")
        val updated = _sampleStatuses.value.toMutableMap()
        updated[sampleId] = st
        _sampleStatuses.value = updated

        val errs = _sampleErrors.value.toMutableMap()
        if (err != null) errs[sampleId] = err else errs.remove(sampleId)
        _sampleErrors.value = errs
        refreshEngineStatus()
    }

    private val focusChangeListener = AudioManager.OnAudioFocusChangeListener { focusChange ->
        when (focusChange) {
            AudioManager.AUDIOFOCUS_GAIN -> {
                hasAudioFocus = true
                if (!soundPoolManager.isInitialized) {
                    soundPoolManager.initialize()
                }
                refreshEngineStatus()
            }
            AudioManager.AUDIOFOCUS_LOSS,
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT -> {
                hasAudioFocus = false
                refreshEngineStatus()
            }
            AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK -> {
                // Keep playing gently without cutting off live drumming
            }
        }
    }

    fun initializeAudio() {
        soundPoolManager.removeStatusListener(statusListener)
        soundPoolManager.addStatusListener(statusListener)
        soundPoolManager.initialize()
        requestAudioFocus()
        refreshEngineStatus()
    }

    private fun requestAudioFocus() {
        val am = audioManager ?: run {
            hasAudioFocus = true
            return
        }
        val result = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setOnAudioFocusChangeListener(focusChangeListener)
                .build()
            audioFocusRequest = req
            am.requestAudioFocus(req)
        } else {
            @Suppress("DEPRECATION")
            am.requestAudioFocus(
                focusChangeListener,
                AudioManager.STREAM_MUSIC,
                AudioManager.AUDIOFOCUS_GAIN
            )
        }
        hasAudioFocus = (result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
    }

    private fun fxSignature(fx: AudioFxState): String {
        val hasDspFx = (fx.reverbEnabled && fx.reverbMix > 0.01f) ||
            (fx.eqEnabled && (abs(fx.bassGainDb) > 0.25f || abs(fx.midGainDb) > 0.25f || abs(fx.trebleGainDb) > 0.25f))
        return if (!hasDspFx) {
            "dry"
        } else {
            "fx_r${fx.reverbEnabled}_${(fx.reverbMix * 100).toInt()}_eq${fx.eqEnabled}_${fx.bassGainDb.toInt()}_${fx.midGainDb.toInt()}_${fx.trebleGainDb.toInt()}"
        }
    }

    /**
     * Preloads all samples needed by the active patch (off UI thread).
     * Never decodes or touches disk during playPad().
     */
    fun preloadSamples(
        pads: List<PadUiModel>,
        sampleFiles: Map<String, File>,
        currentFx: AudioFxState = fxState
    ) {
        if (!soundPoolManager.isInitialized) {
            initializeAudio()
        }
        fxState = currentFx
        val sig = fxSignature(currentFx)
        val fxActive = sig != "dry"
        val protectedKeys = mutableSetOf<String>()

        // Update pad configs first
        for (pad in pads) {
            val idx = pad.padIndex - 1
            if (idx !in 0..7) continue
            val cfg = padConfigs[idx]
            cfg.volume = pad.volume.coerceIn(0f, 1f)
            cfg.pitch = pad.pitch.coerceIn(0.5f, 2.0f)
            cfg.pan = pad.pan.coerceIn(-1f, 1f)
            cfg.enabled = pad.enabled

            val sid = pad.sampleId
            if (sid == null) {
                cfg.sampleId = ""
                cfg.cacheKey = ""
                continue
            }
            val srcFile = sampleFiles[sid]
            if (srcFile == null || !srcFile.exists()) {
                cfg.sampleId = sid
                cfg.cacheKey = ""
                val updated = _sampleStatuses.value.toMutableMap()
                updated[sid] = SampleLoadingStatus.MISSING
                _sampleStatuses.value = updated
                val errs = _sampleErrors.value.toMutableMap()
                errs[sid] = "Sample file not found"
                _sampleErrors.value = errs
                continue
            }

            val cacheKey = "$sid::$sig"
            protectedKeys.add(cacheKey)
            cfg.sampleId = sid
            cfg.cacheKey = cacheKey
            sampleIdToActiveCacheKey[sid] = cacheKey

            val targetFile = if (!fxActive) {
                srcFile
            } else {
                val fxDir = File(context.cacheDir, "fx_cache").apply { mkdirs() }
                val fxFile = File(fxDir, "${sid}_${sig}.wav")
                if (!fxFile.exists() || fxFile.length() < 44) {
                    val ok = AudioEffectProcessor.processSampleWithFx(srcFile, fxFile, currentFx)
                    if (ok && fxFile.exists()) fxFile else srcFile
                } else {
                    fxFile
                }
            }

            val existing = soundPoolManager.getStatus(cacheKey)
            if (existing == SampleLoadingStatus.READY) {
                val updated = _sampleStatuses.value.toMutableMap()
                updated[sid] = SampleLoadingStatus.READY
                _sampleStatuses.value = updated
            } else {
                soundPoolManager.loadSample(cacheKey, targetFile, protectedKeys)
            }
        }
        refreshEngineStatus(fxActive)
    }

    /**
     * Preload/preview a single sample file (e.g., from Patch Editor or Sample Importer).
     */
    fun preloadAndPlaySingleSample(sampleId: String, file: File, volume: Float = 0.85f, pitch: Float = 1.0f) {
        if (!soundPoolManager.isInitialized) initializeAudio()
        val cacheKey = "$sampleId::dry"
        val status = soundPoolManager.getStatus(cacheKey)
        if (status == SampleLoadingStatus.READY) {
            soundPoolManager.play(cacheKey, volume * masterVolume, volume * masterVolume, pitch, 1)
        } else {
            val loaded = soundPoolManager.loadSample(cacheKey, file)
            if (loaded == SampleLoadingStatus.READY) {
                soundPoolManager.play(cacheKey, volume * masterVolume, volume * masterVolume, pitch, 1)
            } else {
                // Schedule a short retry once SoundPool finishes async decode
                delayExecutor.schedule({
                    if (soundPoolManager.getStatus(cacheKey) == SampleLoadingStatus.READY) {
                        soundPoolManager.play(cacheKey, volume * masterVolume, volume * masterVolume, pitch, 1)
                    }
                }, 90, TimeUnit.MILLISECONDS)
            }
        }
    }

    /**
     * Real-time low-latency pad hit. No DB, no disk I/O, no decoding, no coroutines.
     */
    fun playPad(padIndex: Int, velocity: Float = 1.0f): Int {
        if (padIndex !in 1..8) return 0
        val cfg = padConfigs[padIndex - 1]
        if (!cfg.enabled) return 0
        val key = cfg.cacheKey
        if (key.isEmpty()) return 0

        val baseVol = (masterVolume * cfg.volume * velocity.coerceIn(0.05f, 1.0f)).coerceIn(0f, 1f)
        val pan = cfg.pan.coerceIn(-1f, 1f)
        val leftGain = if (pan > 0f) baseVol * (1f - pan) else baseVol
        val rightGain = if (pan < 0f) baseVol * (1f + pan) else baseVol

        val streamId = soundPoolManager.play(key, leftGain, rightGain, cfg.pitch, 1)
        if (streamId > 0) {
            cfg.lastStreamId = streamId
            val fx = fxState
            if (fx.delayEnabled && fx.delayFeedback > 0.02f) {
                scheduleDelayTaps(key, leftGain, rightGain, cfg.pitch, fx.delayTimeMs, fx.delayFeedback)
            }
        }
        return streamId
    }

    private fun scheduleDelayTaps(
        cacheKey: String,
        leftGain: Float,
        rightGain: Float,
        pitch: Float,
        delayTimeMs: Int,
        feedback: Float
    ) {
        val safeDelayMs = delayTimeMs.coerceIn(60, 800).toLong()
        val fb = feedback.coerceIn(0.05f, 0.72f)
        // 3 musical attenuated stereo ping-pong delay echoes
        for (tap in 1..3) {
            var attenuation = 1f
            repeat(tap) { attenuation *= fb }
            val tapLeft = (leftGain * attenuation * if (tap % 2 == 1) 0.75f else 1.0f).coerceIn(0f, 1f)
            val tapRight = (rightGain * attenuation * if (tap % 2 == 1) 1.0f else 0.75f).coerceIn(0f, 1f)
            if (tapLeft < 0.015f && tapRight < 0.015f) break
            delayExecutor.schedule({
                soundPoolManager.play(cacheKey, tapLeft, tapRight, pitch, 0)
            }, safeDelayMs * tap, TimeUnit.MILLISECONDS)
        }
    }

    fun stopPad(padIndex: Int) {
        if (padIndex !in 1..8) return
        val cfg = padConfigs[padIndex - 1]
        if (cfg.lastStreamId > 0) {
            soundPoolManager.stopStream(cfg.lastStreamId)
            cfg.lastStreamId = 0
        }
    }

    fun setPadVolume(padIndex: Int, volume: Float) {
        if (padIndex !in 1..8) return
        val clamped = volume.coerceIn(0f, 1f)
        val cfg = padConfigs[padIndex - 1]
        cfg.volume = clamped
        if (cfg.lastStreamId > 0) {
            val baseVol = masterVolume * clamped
            val pan = cfg.pan
            val left = if (pan > 0f) baseVol * (1f - pan) else baseVol
            val right = if (pan < 0f) baseVol * (1f + pan) else baseVol
            soundPoolManager.setStreamVolume(cfg.lastStreamId, left, right)
        }
    }

    fun setMasterVolume(volume: Float) {
        masterVolume = volume.coerceIn(0f, 1f)
        for (i in 0..7) {
            val cfg = padConfigs[i]
            if (cfg.lastStreamId > 0) {
                val baseVol = masterVolume * cfg.volume
                val pan = cfg.pan
                val left = if (pan > 0f) baseVol * (1f - pan) else baseVol
                val right = if (pan < 0f) baseVol * (1f + pan) else baseVol
                soundPoolManager.setStreamVolume(cfg.lastStreamId, left, right)
            }
        }
    }

    fun updateFxState(newFx: AudioFxState) {
        fxState = newFx
        refreshEngineStatus(fxSignature(newFx) != "dry")
    }

    fun getPadSampleStatus(sampleId: String?): SampleLoadingStatus {
        if (sampleId == null) return SampleLoadingStatus.UNLOADED
        return _sampleStatuses.value[sampleId] ?: SampleLoadingStatus.UNLOADED
    }

    private fun refreshEngineStatus(fxProcessing: Boolean = fxSignature(fxState) != "dry") {
        val allActiveReady = padConfigs.all { cfg ->
            !cfg.enabled || cfg.sampleId.isEmpty() ||
                (_sampleStatuses.value[cfg.sampleId] == SampleLoadingStatus.READY)
        }
        _status.value = AudioEngineStatus(
            isInitialized = soundPoolManager.isInitialized,
            hasAudioFocus = hasAudioFocus,
            loadedSamplesCount = soundPoolManager.getLoadedCount(),
            loadingSamplesCount = soundPoolManager.getLoadingCount(),
            failedSamplesCount = soundPoolManager.getErrorCount(),
            activePatchReady = allActiveReady,
            fxProcessingActive = fxProcessing
        )
    }

    fun releaseAudio() {
        soundPoolManager.removeStatusListener(statusListener)
        soundPoolManager.release()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            audioManager?.abandonAudioFocus(focusChangeListener)
        }
        hasAudioFocus = false
        _status.value = AudioEngineStatus()
    }

    fun shutdownExecutor() {
        runCatching { delayExecutor.shutdownNow() }
    }
}
