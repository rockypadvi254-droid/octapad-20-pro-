package com.example.audio

import android.content.Context
import com.example.data.Bank
import com.example.data.db.PadAssignmentEntity
import com.example.data.db.PatchEntity
import com.example.data.db.SampleEntity
import com.example.data.formatPatchKey
import java.io.File
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.tanh
import kotlin.random.Random

object FactorySampleGenerator {

    private const val SAMPLE_RATE = 44100

    data class FactorySampleSpec(
        val sampleId: String,
        val filename: String,
        val displayName: String,
        val synthType: SynthType
    )

    enum class SynthType {
        KICK_DJ,
        DHOL_BASS,
        DHOL_TREBLE,
        SNARE_CRISP,
        CLAP_FESTIVAL,
        HIHAT_CLOSED,
        HIHAT_OPEN,
        TOM_HIGH,
        TOM_LOW,
        TIMLI_THAP,
        MANDAL_BASS,
        MANJIRA_BELL,
        TABLA_NA,
        TABLA_GE,
        GHUNGROO_SHAKER,
        CRASH_CYMBAL
    }

    val FACTORY_SPECS = listOf(
        FactorySampleSpec("smp_fac_kick_dj", "DJ_Sub_Kick.wav", "DJ Sub Kick", SynthType.KICK_DJ),
        FactorySampleSpec("smp_fac_dhol_bass", "Dhol_Dagga_Bass.wav", "Dhol Dagga Bass", SynthType.DHOL_BASS),
        FactorySampleSpec("smp_fac_dhol_treble", "Dhol_Tasha_Slap.wav", "Dhol Tasha Slap", SynthType.DHOL_TREBLE),
        FactorySampleSpec("smp_fac_snare_crisp", "Snare_Crisp.wav", "Snare Crisp", SynthType.SNARE_CRISP),
        FactorySampleSpec("smp_fac_clap_festival", "Festival_Clap.wav", "Festival Clap", SynthType.CLAP_FESTIVAL),
        FactorySampleSpec("smp_fac_hihat_closed", "HiHat_Closed.wav", "HiHat Closed", SynthType.HIHAT_CLOSED),
        FactorySampleSpec("smp_fac_hihat_open", "HiHat_Open.wav", "HiHat Open", SynthType.HIHAT_OPEN),
        FactorySampleSpec("smp_fac_tom_high", "Tom_High.wav", "Tom High", SynthType.TOM_HIGH),
        FactorySampleSpec("smp_fac_tom_low", "Tom_Low.wav", "Tom Low", SynthType.TOM_LOW),
        FactorySampleSpec("smp_fac_timli_thap", "Timli_Folk_Thap.wav", "Timli Folk Thap", SynthType.TIMLI_THAP),
        FactorySampleSpec("smp_fac_mandal_bass", "Adivasi_Mandal_Bass.wav", "Mandal Bass", SynthType.MANDAL_BASS),
        FactorySampleSpec("smp_fac_manjira_bell", "Manjira_Bell.wav", "Manjira Bell", SynthType.MANJIRA_BELL),
        FactorySampleSpec("smp_fac_tabla_na", "Tabla_Na.wav", "Tabla Na", SynthType.TABLA_NA),
        FactorySampleSpec("smp_fac_tabla_ge", "Tabla_Ge.wav", "Tabla Ge", SynthType.TABLA_GE),
        FactorySampleSpec("smp_fac_ghungroo", "Ghungroo_Shaker.wav", "Ghungroo Shaker", SynthType.GHUNGROO_SHAKER),
        FactorySampleSpec("smp_fac_crash", "Crash_Cymbal.wav", "Crash Cymbal", SynthType.CRASH_CYMBAL)
    )

    fun ensureFactorySamplesExist(context: Context): List<SampleEntity> {
        val dir = File(context.filesDir, "samples/factory").apply { mkdirs() }
        return FACTORY_SPECS.map { spec ->
            val file = File(dir, spec.filename)
            if (!file.exists() || file.length() < 100) {
                val pcm = synthesize(spec.synthType)
                AudioEffectProcessor.writeWav16Bit(file, pcm, SAMPLE_RATE, 1)
            }
            val info = AudioEffectProcessor.verifyAndInspectAudio(file, "WAV")
            SampleEntity(
                sampleId = spec.sampleId,
                originalFilename = spec.filename,
                displayName = spec.displayName,
                storedPath = file.absolutePath,
                sourceUri = null,
                format = "WAV",
                sourceType = "FACTORY",
                durationMs = info.durationMs,
                fileSizeBytes = file.length(),
                contentHash = sha256(file),
                decodingVerified = info.valid,
                errorMessage = info.errorMessage
            )
        }
    }

    fun generateDefault200Patches(): Pair<List<PatchEntity>, List<PadAssignmentEntity>> {
        val patches = ArrayList<PatchEntity>(200)
        val assignments = ArrayList<PadAssignmentEntity>(1600)

        val bankANamed = mapOf(
            1 to "Salpuri",
            2 to "Timli Special",
            3 to "Gamit Special",
            4 to "Dhol Special",
            5 to "Adivasi Special",
            6 to "Festival Special",
            7 to "DJ Special",
            8 to "Custom Patch",
            9 to "Garba Groove",
            10 to "Navratri Dhol",
            11 to "Tabla Taal",
            12 to "Tasha Parade",
            13 to "Bhangra Beat",
            14 to "Electro Kit",
            15 to "Dakla Folk",
            16 to "Sanedo Live"
        )

        val bankBNamed = mapOf(
            1 to "Studio Acoustic",
            2 to "808 Trap Pro",
            3 to "EDM Festival",
            4 to "Dandiya Night",
            5 to "Folk Fusion",
            6 to "Percussion Solo",
            7 to "Club Bass",
            8 to "Custom Kit B",
            9 to "Latin Groove",
            10 to "Bhajan Tabla"
        )

        // Distinct 8-pad kits per archetype
        val kitSalpuri = listOf(
            "smp_fac_dhol_bass", "smp_fac_tabla_na", "smp_fac_manjira_bell", "smp_fac_ghungroo",
            "smp_fac_mandal_bass", "smp_fac_timli_thap", "smp_fac_clap_festival", "smp_fac_hihat_open"
        )
        val kitTimli = listOf(
            "smp_fac_mandal_bass", "smp_fac_timli_thap", "smp_fac_dhol_treble", "smp_fac_manjira_bell",
            "smp_fac_dhol_bass", "smp_fac_ghungroo", "smp_fac_hihat_closed", "smp_fac_crash"
        )
        val kitGamit = listOf(
            "smp_fac_dhol_bass", "smp_fac_timli_thap", "smp_fac_tabla_na", "smp_fac_ghungroo",
            "smp_fac_mandal_bass", "smp_fac_dhol_treble", "smp_fac_manjira_bell", "smp_fac_hihat_open"
        )
        val kitDhol = listOf(
            "smp_fac_dhol_bass", "smp_fac_dhol_treble", "smp_fac_tom_low", "smp_fac_crash",
            "smp_fac_kick_dj", "smp_fac_dhol_treble", "smp_fac_clap_festival", "smp_fac_manjira_bell"
        )
        val kitAdivasi = listOf(
            "smp_fac_mandal_bass", "smp_fac_timli_thap", "smp_fac_ghungroo", "smp_fac_manjira_bell",
            "smp_fac_dhol_bass", "smp_fac_tabla_ge", "smp_fac_dhol_treble", "smp_fac_hihat_closed"
        )
        val kitFestival = listOf(
            "smp_fac_kick_dj", "smp_fac_dhol_treble", "smp_fac_clap_festival", "smp_fac_crash",
            "smp_fac_dhol_bass", "smp_fac_snare_crisp", "smp_fac_hihat_closed", "smp_fac_manjira_bell"
        )
        val kitDj = listOf(
            "smp_fac_kick_dj", "smp_fac_snare_crisp", "smp_fac_hihat_closed", "smp_fac_hihat_open",
            "smp_fac_tom_low", "smp_fac_tom_high", "smp_fac_clap_festival", "smp_fac_crash"
        )
        val kitTabla = listOf(
            "smp_fac_tabla_ge", "smp_fac_tabla_na", "smp_fac_manjira_bell", "smp_fac_ghungroo",
            "smp_fac_dhol_bass", "smp_fac_timli_thap", "smp_fac_tom_high", "smp_fac_hihat_open"
        )

        val kits = listOf(kitSalpuri, kitTimli, kitGamit, kitDhol, kitAdivasi, kitFestival, kitDj, kitTabla)

        for (bank in listOf(Bank.A, Bank.B)) {
            for (num in 1..100) {
                val key = formatPatchKey(bank, num)
                val name = if (bank == Bank.A) {
                    bankANamed[num] ?: "Patch $num"
                } else {
                    bankBNamed[num] ?: "Bank B $num"
                }
                patches.add(
                    PatchEntity(
                        patchKey = key,
                        bank = bank.code,
                        patchNumber = num,
                        name = name,
                        isFavorite = (bank == Bank.A && num in 1..6),
                        updatedAt = System.currentTimeMillis()
                    )
                )
                val kit = if (bank == Bank.A) {
                    kits[(num - 1) % kits.size]
                } else {
                    kits[(num + 4) % kits.size]
                }
                for (padIdx in 1..8) {
                    val sampleId = kit[padIdx - 1]
                    val pan = when (padIdx) {
                        1, 5 -> -0.15f
                        2, 6 -> 0.0f
                        3, 7 -> 0.12f
                        else -> 0.25f
                    }
                    val pitchOffset = if (bank == Bank.B) 1.04f else 1.0f
                    assignments.add(
                        PadAssignmentEntity(
                            patchKey = key,
                            padIndex = padIdx,
                            sampleId = sampleId,
                            missingSampleName = null,
                            volume = 0.88f,
                            pitch = pitchOffset,
                            pan = pan,
                            enabled = true
                        )
                    )
                }
            }
        }
        return patches to assignments
    }

    private fun synthesize(type: SynthType): ShortArray {
        val rng = Random(type.ordinal * 997 + 42)
        return when (type) {
            SynthType.KICK_DJ -> renderSamples(0.42f) { t ->
                val freq = 42.0 + 115.0 * exp(-t * 28.0)
                val body = sin(2.0 * PI * freq * t) * exp(-t * 7.5)
                val click = (rng.nextDouble() * 2 - 1) * exp(-t * 180.0) * 0.3
                tanh((body * 1.45 + click) * 1.3)
            }
            SynthType.DHOL_BASS -> renderSamples(0.55f) { t ->
                val freq = 76.0 + 95.0 * exp(-t * 22.0)
                val fund = sin(2.0 * PI * freq * t) * exp(-t * 5.0)
                val harm = sin(2.0 * PI * freq * 1.52 * t) * exp(-t * 10.0) * 0.38
                val skin = (rng.nextDouble() * 2 - 1) * exp(-t * 95.0) * 0.22
                tanh((fund + harm + skin) * 1.4)
            }
            SynthType.DHOL_TREBLE -> renderSamples(0.28f) { t ->
                val f1 = 410.0 + 140.0 * exp(-t * 45.0)
                val tone = sin(2.0 * PI * f1 * t) * exp(-t * 14.0) * 0.75 +
                    sin(2.0 * PI * f1 * 1.78 * t) * exp(-t * 20.0) * 0.35
                val slap = (rng.nextDouble() * 2 - 1) * exp(-t * 55.0) * 0.45
                tanh((tone + slap) * 1.3)
            }
            SynthType.SNARE_CRISP -> renderSamples(0.32f) { t ->
                val body = sin(2.0 * PI * (185.0 + 60.0 * exp(-t * 40.0)) * t) * exp(-t * 16.0) * 0.65
                val wires = (rng.nextDouble() * 2 - 1) * exp(-t * 13.0) * 0.75
                tanh((body + wires) * 1.2)
            }
            SynthType.CLAP_FESTIVAL -> renderSamples(0.36f) { t ->
                val burst1 = if (t < 0.012) exp(-t * 140.0) else 0.0
                val burst2 = if (t in 0.012..0.025) exp(-(t - 0.012) * 140.0) else 0.0
                val burst3 = if (t in 0.025..0.038) exp(-(t - 0.025) * 140.0) else 0.0
                val tail = if (t >= 0.035) exp(-(t - 0.035) * 11.0) else 0.0
                val env = burst1 + burst2 + burst3 + tail * 0.85
                val noise = rng.nextDouble() * 2 - 1
                tanh(noise * env * 1.35)
            }
            SynthType.HIHAT_CLOSED -> renderSamples(0.11f) { t ->
                val metallic = metallicPartials(t, 1.0) * 0.45
                val noise = (rng.nextDouble() * 2 - 1) * 0.75
                (metallic + noise) * exp(-t * 48.0) * 0.85
            }
            SynthType.HIHAT_OPEN -> renderSamples(0.48f) { t ->
                val metallic = metallicPartials(t, 1.05) * 0.50
                val noise = (rng.nextDouble() * 2 - 1) * 0.65
                (metallic + noise) * exp(-t * 6.5) * 0.80
            }
            SynthType.TOM_HIGH -> renderSamples(0.36f) { t ->
                val freq = 148.0 + 130.0 * exp(-t * 24.0)
                sin(2.0 * PI * freq * t) * exp(-t * 9.0) * 0.92
            }
            SynthType.TOM_LOW -> renderSamples(0.45f) { t ->
                val freq = 78.0 + 85.0 * exp(-t * 18.0)
                sin(2.0 * PI * freq * t) * exp(-t * 6.5) * 0.95
            }
            SynthType.TIMLI_THAP -> renderSamples(0.24f) { t ->
                val freq = 320.0 + 240.0 * exp(-t * 50.0)
                val rim = sin(2.0 * PI * freq * t) * exp(-t * 18.0) * 0.85 +
                    sin(2.0 * PI * 920.0 * t) * exp(-t * 32.0) * 0.40
                val crack = (rng.nextDouble() * 2 - 1) * exp(-t * 85.0) * 0.4
                tanh((rim + crack) * 1.35)
            }
            SynthType.MANDAL_BASS -> renderSamples(0.50f) { t ->
                val freq = 66.0 + 75.0 * exp(-t * 20.0)
                val body = sin(2.0 * PI * freq * t) * exp(-t * 5.8) +
                    sin(2.0 * PI * freq * 2.02 * t) * exp(-t * 12.0) * 0.30
                tanh(body * 1.35)
            }
            SynthType.MANJIRA_BELL -> renderSamples(0.62f) { t ->
                val bell = sin(2.0 * PI * 2180.0 * t) * 0.45 +
                    sin(2.0 * PI * 3490.0 * t) * 0.35 +
                    sin(2.0 * PI * 4980.0 * t) * 0.25 +
                    sin(2.0 * PI * 6410.0 * t) * 0.15
                bell * exp(-t * 5.2) * 0.9
            }
            SynthType.TABLA_NA -> renderSamples(0.35f) { t ->
                val freq = 330.0 + 25.0 * exp(-t * 40.0)
                val harmonic = sin(2.0 * PI * freq * t) * 0.55 +
                    sin(2.0 * PI * freq * 2.0 * t) * 0.45 +
                    sin(2.0 * PI * freq * 3.0 * t) * 0.20
                val transient = (rng.nextDouble() * 2 - 1) * exp(-t * 120.0) * 0.25
                (harmonic * exp(-t * 10.5) + transient) * 0.9
            }
            SynthType.TABLA_GE -> renderSamples(0.58f) { t ->
                val mod = sin(2.0 * PI * 6.0 * t) * 14.0 * exp(-t * 4.0)
                val freq = 96.0 + 38.0 * exp(-t * 10.0) + mod
                val bass = sin(2.0 * PI * freq * t) * exp(-t * 4.6) +
                    sin(2.0 * PI * freq * 2.0 * t) * exp(-t * 9.0) * 0.25
                tanh(bass * 1.25)
            }
            SynthType.GHUNGROO_SHAKER -> renderSamples(0.22f) { t ->
                val env1 = exp(-t * 28.0)
                val env2 = if (t > 0.045) exp(-(t - 0.045) * 22.0) * 0.8 else 0.0
                val jingle = sin(2.0 * PI * 5400.0 * t) * 0.35 + sin(2.0 * PI * 7200.0 * t) * 0.25
                val sand = (rng.nextDouble() * 2 - 1) * 0.65
                (jingle + sand) * (env1 + env2) * 0.72
            }
            SynthType.CRASH_CYMBAL -> renderSamples(0.85f) { t ->
                val metallic = metallicPartials(t, 0.88) * 0.45
                val wash = (rng.nextDouble() * 2 - 1) * 0.55
                (metallic + wash) * exp(-t * 3.4) * 0.85
            }
        }
    }

    private fun metallicPartials(t: Double, scale: Double): Double {
        val freqs = doubleArrayOf(296.0, 412.0, 563.0, 745.0, 991.0, 1340.0)
        var sum = 0.0
        for (f in freqs) {
            sum += sin(2.0 * PI * f * scale * t)
        }
        return sum / freqs.size
    }

    private inline fun renderSamples(durationSec: Float, crossinline generator: (Double) -> Double): ShortArray {
        val count = (SAMPLE_RATE * durationSec).toInt().coerceAtLeast(1)
        val out = ShortArray(count)
        val fadeOutSamples = (SAMPLE_RATE * 0.015f).toInt().coerceAtLeast(1)
        for (i in 0 until count) {
            val t = i.toDouble() / SAMPLE_RATE
            var v = generator(t).coerceIn(-1.0, 1.0)
            if (i > count - fadeOutSamples) {
                val fade = (count - i).toDouble() / fadeOutSamples
                v *= fade
            }
            out[i] = (v * 32767.0).toInt().toShort()
        }
        return out
    }

    fun sha256(file: File): String {
        return runCatching {
            val md = MessageDigest.getInstance("SHA-256")
            file.inputStream().use { input ->
                val buf = ByteArray(8192)
                var read = input.read(buf)
                while (read > 0) {
                    md.update(buf, 0, read)
                    read = input.read(buf)
                }
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }.getOrDefault("")
    }
}
