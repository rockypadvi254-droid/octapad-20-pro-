package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val OctapadDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = ChassisBlack,
    primaryContainer = LcdBackground,
    onPrimaryContainer = LcdTextCyan,
    secondary = AmberGold,
    onSecondary = ChassisBlack,
    secondaryContainer = PanelElevated,
    onSecondaryContainer = LcdTextAmber,
    tertiary = EmeraldGreen,
    onTertiary = ChassisBlack,
    background = ChassisBlack,
    onBackground = TextPrimary,
    surface = ChassisCharcoal,
    onSurface = TextPrimary,
    surfaceVariant = PanelSurface,
    onSurfaceVariant = TextSecondary,
    outline = ControlBorder,
    error = CoralRed,
    onError = TextPrimary
)

@Composable
fun OctapadTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = OctapadDarkColorScheme,
        typography = OctapadTypography,
        content = content
    )
}
