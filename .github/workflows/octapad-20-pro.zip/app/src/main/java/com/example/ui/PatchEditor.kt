package com.example.ui

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Bank
import com.example.data.PadUiModel
import com.example.data.SampleLoadingStatus
import com.example.data.db.SampleEntity
import com.example.samples.SampleImporter
import com.example.ui.theme.AmberGold
import com.example.ui.theme.ChassisBlack
import com.example.ui.theme.ChassisCharcoal
import com.example.ui.theme.ControlBorder
import com.example.ui.theme.CoralRed
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.EmeraldGreen
import com.example.ui.theme.PadNeonColors
import com.example.ui.theme.PanelElevated
import com.example.ui.theme.PanelSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
fun PatchEditor(
    bank: Bank,
    patchNumber: Int,
    initialPatchName: String,
    initialPads: List<PadUiModel>,
    samples: List<SampleEntity>,
    onPreviewSample: (sampleId: String, volume: Float, pitch: Float) -> Unit,
    onImportCustomSample: (Uri, (SampleEntity) -> Unit) -> Unit,
    onSave: (patchName: String, editedPads: List<PadUiModel>) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onCancel() }

    var patchName by remember(bank, patchNumber) { mutableStateOf(initialPatchName) }
    val editedPads = remember(bank, patchNumber) {
        mutableStateListOf<PadUiModel>().apply { addAll(initialPads) }
    }
    var selectedPadIndex by remember { mutableIntStateOf(1) }
    var searchQuery by remember { mutableStateOf("") }

    val selectedPad = editedPads.firstOrNull { it.padIndex == selectedPadIndex } ?: editedPads.first()
    val padColor = PadNeonColors[(selectedPadIndex - 1).coerceIn(0, 7)]

    val samplePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            onImportCustomSample(uri) { imported ->
                val idx = editedPads.indexOfFirst { it.padIndex == selectedPadIndex }
                if (idx >= 0) {
                    editedPads[idx] = editedPads[idx].copy(
                        sampleId = imported.sampleId,
                        sampleName = imported.displayName,
                        missingSampleName = null,
                        sampleStatus = SampleLoadingStatus.READY
                    )
                }
            }
        }
    }

    val filteredSamples = remember(samples, searchQuery) {
        if (searchQuery.isBlank()) samples
        else samples.filter {
            it.displayName.contains(searchQuery, ignoreCase = true) ||
                it.originalFilename.contains(searchQuery, ignoreCase = true) ||
                it.sourceType.contains(searchQuery, ignoreCase = true)
        }
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = ChassisBlack
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Top Editor Header
            Surface(
                color = ChassisCharcoal,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, ControlBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Column {
                        Text(
                            text = "PATCH EDITOR  •  ${bank.label} PATCH $patchNumber",
                            style = MaterialTheme.typography.titleLarge,
                            color = AmberGold
                        )
                        Text(
                            text = "Isolated patch editing — changes affect only ${bank.code}-$patchNumber",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }

                    OutlinedTextField(
                        value = patchName,
                        onValueChange = { if (it.length <= 36) patchName = it },
                        singleLine = true,
                        label = { Text("Patch Name") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("editor_patch_name_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ElectricCyan,
                            unfocusedBorderColor = ControlBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedLabelColor = ElectricCyan,
                            unfocusedLabelColor = TextSecondary
                        )
                    )

                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("editor_cancel_button"),
                        border = BorderStroke(1.dp, CoralRed),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CoralRed)
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("CANCEL")
                    }

                    Button(
                        onClick = { onSave(patchName.trim().ifEmpty { "Patch $patchNumber" }, editedPads.toList()) },
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("editor_save_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldGreen,
                            contentColor = ChassisBlack
                        )
                    ) {
                        Icon(Icons.Filled.Check, contentDescription = "Save patch", modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("SAVE PATCH", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Main 3-Pane Editor Body: Left (8 Pad Selector), Middle (Pad Params), Right (Sample Browser & Import)
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Pane 1: 8 Pads Mini-Grid (4x2) + Quick Info
                Surface(
                    modifier = Modifier
                        .weight(0.32f)
                        .fillMaxHeight(),
                    color = ChassisCharcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ControlBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "SELECT PAD (1–8)",
                            style = MaterialTheme.typography.labelLarge,
                            color = ElectricCyan
                        )
                        Column(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            for (rowIdx in 0..1) {
                                Row(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    for (colIdx in 0..3) {
                                        val pNum = rowIdx * 4 + colIdx + 1
                                        val padItem = editedPads.first { it.padIndex == pNum }
                                        val isSel = pNum == selectedPadIndex
                                        val accent = PadNeonColors[pNum - 1]
                                        Box(
                                            modifier = Modifier
                                                .weight(1f)
                                                .fillMaxHeight()
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    if (isSel) accent.copy(alpha = 0.25f) else PanelSurface
                                                )
                                                .border(
                                                    width = if (isSel) 2.dp else 1.dp,
                                                    color = if (isSel) accent else ControlBorder,
                                                    shape = RoundedCornerShape(8.dp)
                                                )
                                                .clickable { selectedPadIndex = pNum }
                                                .padding(6.dp)
                                                .testTag("editor_pad_select_$pNum")
                                        ) {
                                            Column(
                                                modifier = Modifier.fillMaxSize(),
                                                verticalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = "PAD $pNum",
                                                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                                                    color = accent
                                                )
                                                Text(
                                                    text = padItem.sampleName,
                                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                                                    color = if (padItem.enabled) TextPrimary else TextMuted,
                                                    maxLines = 2,
                                                    overflow = TextOverflow.Ellipsis
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Pane 2: Selected Pad Parameters (Volume, Pitch, Pan, Enable/Disable, Preview)
                Surface(
                    modifier = Modifier
                        .weight(0.32f)
                        .fillMaxHeight(),
                    color = ChassisCharcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, padColor.copy(alpha = 0.6f))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "PAD ${selectedPad.padIndex} SETTINGS",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = padColor
                                )
                                Text(
                                    text = selectedPad.sampleName,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (selectedPad.enabled) "ON" else "OFF",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selectedPad.enabled) EmeraldGreen else CoralRed
                                )
                                Switch(
                                    checked = selectedPad.enabled,
                                    onCheckedChange = { enabled ->
                                        updatePad(editedPads, selectedPadIndex) { it.copy(enabled = enabled) }
                                    },
                                    modifier = Modifier.testTag("editor_pad_enable_switch"),
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = ChassisBlack,
                                        checkedTrackColor = EmeraldGreen
                                    )
                                )
                            }
                        }

                        // Volume
                        ParameterSliderRow(
                            label = "Pad Volume",
                            valueText = "${(selectedPad.volume * 100).roundToInt()}%",
                            value = selectedPad.volume,
                            range = 0f..1f,
                            accent = padColor,
                            testTag = "editor_pad_volume_slider"
                        ) { v ->
                            updatePad(editedPads, selectedPadIndex) { it.copy(volume = v) }
                        }

                        // Pitch
                        ParameterSliderRow(
                            label = "Pitch / Tune",
                            valueText = "${"%.2f".format(selectedPad.pitch)}x",
                            value = selectedPad.pitch,
                            range = 0.5f..2.0f,
                            accent = ElectricCyan,
                            testTag = "editor_pad_pitch_slider"
                        ) { p ->
                            updatePad(editedPads, selectedPadIndex) { it.copy(pitch = p) }
                        }

                        // Pan
                        val panLabel = when {
                            selectedPad.pan < -0.05f -> "L ${(-selectedPad.pan * 100).roundToInt()}"
                            selectedPad.pan > 0.05f -> "R ${(selectedPad.pan * 100).roundToInt()}"
                            else -> "CENTER"
                        }
                        ParameterSliderRow(
                            label = "Stereo Pan",
                            valueText = panLabel,
                            value = selectedPad.pan,
                            range = -1f..1f,
                            accent = AmberGold,
                            testTag = "editor_pad_pan_slider"
                        ) { pan ->
                            updatePad(editedPads, selectedPadIndex) { it.copy(pan = pan) }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    selectedPad.sampleId?.let { sid ->
                                        onPreviewSample(sid, selectedPad.volume, selectedPad.pitch)
                                    }
                                },
                                enabled = selectedPad.sampleId != null,
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("editor_preview_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = padColor,
                                    contentColor = ChassisBlack
                                )
                            ) {
                                Icon(Icons.Filled.PlayArrow, contentDescription = "Preview pad audio", modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("PREVIEW", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = {
                                    updatePad(editedPads, selectedPadIndex) {
                                        it.copy(pitch = 1.0f, pan = 0.0f, volume = 0.85f, enabled = true)
                                    }
                                },
                                modifier = Modifier.height(44.dp),
                                border = BorderStroke(1.dp, ControlBorder)
                            ) {
                                Text("RESET", color = TextSecondary)
                            }
                        }
                    }
                }

                // Pane 3: Sample Assignment Browser + Custom Sample Import (WAV/MP3/OGG)
                Surface(
                    modifier = Modifier
                        .weight(0.36f)
                        .fillMaxHeight(),
                    color = ChassisCharcoal,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, ControlBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ASSIGN SAMPLE",
                                style = MaterialTheme.typography.labelLarge,
                                color = ElectricCyan
                            )
                            Button(
                                onClick = { samplePickerLauncher.launch(SampleImporter.SUPPORTED_MIME_TYPES) },
                                modifier = Modifier
                                    .height(36.dp)
                                    .testTag("editor_add_sample_button"),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = ElectricCyan,
                                    contentColor = ChassisBlack
                                )
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = "Add custom sample", modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("ADD SAMPLE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            singleLine = true,
                            placeholder = { Text("Filter samples (WAV, MP3, OGG)...") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = ControlBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )

                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            items(
                                items = filteredSamples,
                                key = { it.sampleId }
                            ) { sample ->
                                val isAssigned = selectedPad.sampleId == sample.sampleId
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(7.dp))
                                        .background(if (isAssigned) padColor.copy(alpha = 0.18f) else PanelSurface)
                                        .border(
                                            1.dp,
                                            if (isAssigned) padColor else ControlBorder,
                                            RoundedCornerShape(7.dp)
                                        )
                                        .clickable {
                                            updatePad(editedPads, selectedPadIndex) {
                                                it.copy(
                                                    sampleId = sample.sampleId,
                                                    sampleName = sample.displayName,
                                                    missingSampleName = null,
                                                    sampleStatus = if (sample.decodingVerified) SampleLoadingStatus.READY else SampleLoadingStatus.ERROR
                                                )
                                            }
                                        }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = sample.displayName,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                            color = if (isAssigned) padColor else TextPrimary,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${sample.format} • ${sample.durationMs}ms • ${sample.sourceType}",
                                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.5.sp),
                                            color = if (sample.decodingVerified) TextSecondary else CoralRed,
                                            maxLines = 1
                                        )
                                    }
                                    IconButton(
                                        onClick = { onPreviewSample(sample.sampleId, selectedPad.volume, selectedPad.pitch) },
                                        modifier = Modifier.size(34.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.PlayArrow,
                                            contentDescription = "Preview ${sample.displayName}",
                                            tint = ElectricCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ParameterSliderRow(
    label: String,
    valueText: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    accent: androidx.compose.ui.graphics.Color,
    testTag: String,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(PanelElevated)
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
            Text(text = valueText, style = MaterialTheme.typography.labelMedium, color = accent)
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            modifier = Modifier
                .fillMaxWidth()
                .testTag(testTag),
            colors = SliderDefaults.colors(
                thumbColor = accent,
                activeTrackColor = accent,
                inactiveTrackColor = ControlBorder
            )
        )
    }
}

private inline fun updatePad(
    list: MutableList<PadUiModel>,
    padIndex: Int,
    transform: (PadUiModel) -> PadUiModel
) {
    val idx = list.indexOfFirst { it.padIndex == padIndex }
    if (idx >= 0) {
        list[idx] = transform(list[idx])
    }
}
