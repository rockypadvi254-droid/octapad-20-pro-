package com.example.samples

import android.content.Context
import com.example.audio.AudioEffectProcessor
import com.example.audio.FactorySampleGenerator
import com.example.data.db.PatchDao
import com.example.data.db.SampleEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.io.File

class SampleRegistry(
    private val context: Context,
    private val dao: PatchDao
) {
    val samplesFlow: Flow<List<SampleEntity>> = dao.observeAllSamples()

    suspend fun initializeAndVerifyRegistry(): List<SampleEntity> = withContext(Dispatchers.IO) {
        val factorySamples = FactorySampleGenerator.ensureFactorySamplesExist(context)
        val existing = dao.getAllSamplesSync().associateBy { it.sampleId }

        // Ensure all factory samples exist in DB
        val toUpsert = ArrayList<SampleEntity>()
        for (fac in factorySamples) {
            if (existing[fac.sampleId] == null || !File(existing[fac.sampleId]!!.storedPath).exists()) {
                toUpsert.add(fac)
            }
        }

        // Verify all non-factory samples still exist on disk & remain valid
        for (sample in existing.values) {
            if (sample.sourceType == "FACTORY") continue
            val file = File(sample.storedPath)
            if (!file.exists() || file.length() == 0L) {
                if (sample.decodingVerified || sample.errorMessage == null) {
                    toUpsert.add(
                        sample.copy(
                            decodingVerified = false,
                            errorMessage = "Sample file missing from private storage: ${sample.originalFilename}"
                        )
                    )
                }
            } else if (!sample.decodingVerified) {
                val info = AudioEffectProcessor.verifyAndInspectAudio(file, sample.format)
                toUpsert.add(
                    sample.copy(
                        decodingVerified = info.valid,
                        durationMs = if (info.durationMs > 0) info.durationMs else sample.durationMs,
                        errorMessage = info.errorMessage
                    )
                )
            }
        }

        if (toUpsert.isNotEmpty()) {
            dao.upsertSamples(toUpsert)
        }
        dao.getAllSamplesSync()
    }

    suspend fun getAllSamples(): List<SampleEntity> = withContext(Dispatchers.IO) {
        dao.getAllSamplesSync()
    }

    suspend fun getSample(sampleId: String): SampleEntity? = withContext(Dispatchers.IO) {
        dao.getSampleSync(sampleId)
    }

    suspend fun findByContentHash(hash: String): SampleEntity? = withContext(Dispatchers.IO) {
        if (hash.isBlank()) null else dao.getSampleByHashSync(hash)
    }

    suspend fun registerSample(sample: SampleEntity) = withContext(Dispatchers.IO) {
        dao.upsertSample(sample)
    }

    suspend fun registerSamples(samples: List<SampleEntity>) = withContext(Dispatchers.IO) {
        if (samples.isNotEmpty()) {
            dao.upsertSamples(samples)
        }
    }

    suspend fun buildSampleFileMap(): Map<String, File> = withContext(Dispatchers.IO) {
        val all = dao.getAllSamplesSync()
        val map = HashMap<String, File>(all.size)
        for (s in all) {
            val f = File(s.storedPath)
            if (f.exists() && f.length() > 0L) {
                map[s.sampleId] = f
            }
        }
        map
    }

    suspend fun verifySingleSample(sampleId: String): SampleEntity? = withContext(Dispatchers.IO) {
        val sample = dao.getSampleSync(sampleId) ?: return@withContext null
        val file = File(sample.storedPath)
        val updated = if (!file.exists() || file.length() == 0L) {
            sample.copy(
                decodingVerified = false,
                errorMessage = "File missing: ${sample.originalFilename}"
            )
        } else {
            val info = AudioEffectProcessor.verifyAndInspectAudio(file, sample.format)
            sample.copy(
                decodingVerified = info.valid,
                durationMs = if (info.durationMs > 0) info.durationMs else sample.durationMs,
                errorMessage = info.errorMessage
            )
        }
        dao.upsertSample(updated)
        updated
    }

    suspend fun removeSample(sampleId: String): Boolean = withContext(Dispatchers.IO) {
        val sample = dao.getSampleSync(sampleId) ?: return@withContext false
        if (sample.sourceType == "FACTORY") return@withContext false
        runCatching { File(sample.storedPath).delete() }
        dao.deleteSampleById(sampleId)
        true
    }
}
