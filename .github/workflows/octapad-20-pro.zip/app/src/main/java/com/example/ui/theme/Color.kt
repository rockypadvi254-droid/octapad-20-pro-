package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hardware Chassis & Surface Colors
val ChassisBlack = Color(0xFF07090D)
val ChassisCharcoal = Color(0xFF10141C)
val PanelSurface = Color(0xFF161C27)
val PanelElevated = Color(0xFF1E2634)
val ControlBorder = Color(0xFF2B3648)
val LcdBackground = Color(0xFF06131A)
val LcdBorder = Color(0xFF144252)

// Neon Hardware Accents
val ElectricCyan = Color(0xFF00E5FF)
val AmberGold = Color(0xFFFFB300)
val CoralRed = Color(0xFFFF4D6D)
val EmeraldGreen = Color(0xFF00E676)
val VioletPulse = Color(0xFFB388FF)
val OrangeFlame = Color(0xFFFF6D00)
val SkyBlue = Color(0xFF40C4FF)
val MagentaNeon = Color(0xFFFF4081)

// Text Colors
val TextPrimary = Color(0xFFF3F7FC)
val TextSecondary = Color(0xFF9AA8BC)
val TextMuted = Color(0xFF607087)
val LcdTextCyan = Color(0xFF3EF0FF)
val LcdTextAmber = Color(0xFFFFC947)

// Pad Glow Palette (8 distinct vibrant borders matching hardware Octapad)
val PadNeonColors = listOf(
    ElectricCyan,   // PAD 1
    AmberGold,      // PAD 2
    CoralRed,       // PAD 3
    EmeraldGreen,   // PAD 4
    SkyBlue,        // PAD 5
    OrangeFlame,    // PAD 6
    MagentaNeon,    // PAD 7
    VioletPulse     // PAD 8
)
