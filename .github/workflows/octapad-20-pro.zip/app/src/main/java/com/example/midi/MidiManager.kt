package com.example.midi

import android.content.Context
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager as AndroidMidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.example.data.MidiPadMapping
import com.example.data.MidiStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.ConcurrentHashMap

class MidiManager(
    private val context: Context,
    private val onPadTriggered: (padIndex: Int, velocity: Float) -> Unit
) {
    private val androidMidiManager: AndroidMidiManager? =
        if (context.packageManager.hasSystemFeature(PackageManager.FEATURE_MIDI)) {
            context.getSystemService(Context.MIDI_SERVICE) as? AndroidMidiManager
        } else null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val openDevices = ConcurrentHashMap<Int, MidiDevice>()
    private val openPorts = ConcurrentHashMap<Int, MutableList<MidiOutputPort>>()
    private val deviceNames = ConcurrentHashMap<Int, String>()

    @Volatile
    private var padMappings: List<MidiPadMapping> = defaultMappings()

    private val _midiStatus = MutableStateFlow(
        MidiStatus(
            isHardwareSupported = androidMidiManager != null,
            connectedDeviceCount = 0
        )
    )
    val midiStatus: StateFlow<MidiStatus> = _midiStatus.asStateFlow()

    private val deviceCallback = object : AndroidMidiManager.DeviceCallback() {
        override fun onDeviceAdded(device: MidiDeviceInfo) {
            connectDeviceIfHasOutput(device)
        }

        override fun onDeviceRemoved(device: MidiDeviceInfo) {
            disconnectDevice(device.id)
        }
    }

    fun startListening() {
        val mgr = androidMidiManager ?: run {
            _midiStatus.value = MidiStatus(isHardwareSupported = false, connectedDeviceCount = 0)
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mgr.registerDeviceCallback(
                AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM,
                { runnable -> mainHandler.post(runnable) },
                deviceCallback
            )
            mgr.getDevicesForTransport(AndroidMidiManager.TRANSPORT_MIDI_BYTE_STREAM).forEach {
                connectDeviceIfHasOutput(it)
            }
        } else {
            @Suppress("DEPRECATION")
            mgr.registerDeviceCallback(deviceCallback, mainHandler)
            @Suppress("DEPRECATION")
            mgr.devices.forEach { connectDeviceIfHasOutput(it) }
        }
        publishStatus()
    }

    fun updateMappings(mappings: List<MidiPadMapping>) {
        padMappings = mappings
    }

    private fun connectDeviceIfHasOutput(info: MidiDeviceInfo) {
        if (info.outputPortCount <= 0) return
        val mgr = androidMidiManager ?: return
        if (openDevices.containsKey(info.id)) return

        val name = info.properties.getString(MidiDeviceInfo.PROPERTY_NAME)
            ?: info.properties.getString(MidiDeviceInfo.PROPERTY_PRODUCT)
            ?: "USB MIDI Device #${info.id}"

        mgr.openDevice(info, { device ->
            if (device == null) return@openDevice
            openDevices[info.id] = device
            deviceNames[info.id] = name
            val ports = mutableListOf<MidiOutputPort>()
            for (portInfo in info.ports) {
                if (portInfo.type == MidiDeviceInfo.PortInfo.TYPE_OUTPUT) {
                    val outPort = device.openOutputPort(portInfo.portNumber)
                    if (outPort != null) {
                        outPort.connect(MidiNoteReceiver())
                        ports.add(outPort)
                    }
                }
            }
            openPorts[info.id] = ports
            publishStatus()
        }, mainHandler)
    }

    private fun disconnectDevice(deviceId: Int) {
        openPorts.remove(deviceId)?.forEach { runCatching { it.close() } }
        openDevices.remove(deviceId)?.let { runCatching { it.close() } }
        deviceNames.remove(deviceId)
        publishStatus()
    }

    private fun publishStatus(lastNote: Int? = _midiStatus.value.lastReceivedNote, lastPad: Int? = _midiStatus.value.lastTriggeredPad) {
        val names = deviceNames.values.toList()
        _midiStatus.value = MidiStatus(
            isHardwareSupported = androidMidiManager != null,
            connectedDeviceCount = names.size,
            connectedDeviceNames = names,
            lastReceivedNote = lastNote,
            lastTriggeredPad = lastPad,
            lastActivityMs = System.currentTimeMillis()
        )
    }

    fun processRawMidiBytes(msg: ByteArray, offset: Int, count: Int) {
        var i = offset
        val end = minOf(msg.size, offset + count)
        var runningStatus = 0
        while (i < end) {
            val b = msg[i].toInt() and 0xFF
            if ((b and 0x80) != 0) {
                if (b >= 0xF8) {
                    // System real-time single byte
                    i++
                    continue
                }
                runningStatus = b
                i++
            }
            val statusType = runningStatus and 0xF0
            val channel = runningStatus and 0x0F
            when (statusType) {
                0x90 -> { // Note On
                    if (i + 1 < end) {
                        val note = msg[i].toInt() and 0x7F
                        val vel = msg[i + 1].toInt() and 0x7F
                        i += 2
                        if (vel > 0) {
                            handleNoteOn(channel, note, vel)
                        }
                    } else {
                        break
                    }
                }
                0x80, 0xA0, 0xB0, 0xE0 -> { // 2-data-byte channel voice messages
                    i += 2
                }
                0xC0, 0xD0 -> { // 1-data-byte channel voice messages
                    i += 1
                }
                else -> {
                    i++
                }
            }
        }
    }

    private fun handleNoteOn(channel: Int, note: Int, velocity: Int) {
        val matching = padMappings.filter {
            it.midiNote == note && (it.channel < 0 || it.channel == channel)
        }
        val velNorm = (velocity / 127f).coerceIn(0.08f, 1.0f)
        var triggeredPad: Int? = null
        for (m in matching) {
            onPadTriggered(m.padIndex, velNorm)
            triggeredPad = m.padIndex
        }
        publishStatus(lastNote = note, lastPad = triggeredPad)
    }

    fun stopListening() {
        val mgr = androidMidiManager
        if (mgr != null) {
            runCatching { mgr.unregisterDeviceCallback(deviceCallback) }
        }
        openPorts.values.flatten().forEach { runCatching { it.close() } }
        openPorts.clear()
        openDevices.values.forEach { runCatching { it.close() } }
        openDevices.clear()
        deviceNames.clear()
        publishStatus()
    }

    private inner class MidiNoteReceiver : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            processRawMidiBytes(msg, offset, count)
        }
    }

    companion object {
        fun defaultMappings(): List<MidiPadMapping> = listOf(
            MidiPadMapping(1, 36, -1), // Kick
            MidiPadMapping(2, 38, -1), // Snare
            MidiPadMapping(3, 42, -1), // Closed HH
            MidiPadMapping(4, 46, -1), // Open HH
            MidiPadMapping(5, 45, -1), // Low Tom
            MidiPadMapping(6, 48, -1), // Hi Tom
            MidiPadMapping(7, 39, -1), // Clap
            MidiPadMapping(8, 49, -1)  // Crash
        )
    }
}
